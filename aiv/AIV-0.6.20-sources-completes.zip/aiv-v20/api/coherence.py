"""Small stateless HTTPS endpoint for Journal Local AIV coherence refresh.

Runtime intentionally uses only Python stdlib and the deterministic local engine.
Request bodies are not persisted by this code.
"""
from http.server import BaseHTTPRequestHandler
from pathlib import Path
import importlib.util
import io
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
ENGINE_PATH = ROOT / "tools" / "generate_verdicts.py"
MAX_BODY = 1024 * 1024
MAX_APPS = 1000


def _load_engine():
    spec = importlib.util.spec_from_file_location("aiv_generate_verdicts", ENGINE_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("coherence engine unavailable")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod


def evaluate_payload(payload):
    if not isinstance(payload, dict):
        raise ValueError("JSON object required")
    raw_apps = payload.get("apps")
    if not isinstance(raw_apps, list):
        raise ValueError("apps list required")
    if len(raw_apps) > MAX_APPS:
        raise ValueError("too many apps")
    engine = _load_engine()
    apps = []
    for row in raw_apps:
        if not isinstance(row, dict):
            continue
        package = str(row.get("package") or row.get("package_name") or "").strip()
        if not package or len(package) > 255:
            continue
        raw_permissions = row.get("permissions", [])
        if not isinstance(raw_permissions, list):
            raw_permissions = []
        # The HTTP body already has a size limit. Large system manifests must
        # not make the entire phone inventory fail or lose permissions.
        permissions = [str(x)[:255] for x in raw_permissions if isinstance(x, str) and x.strip()]
        apps.append(engine.AppInfo(package=package, permissions=permissions))
    results = [engine.evaluate_local(app) for app in apps]
    out = {
        "schema": engine.SCHEMA,
        "engine": engine.ENGINE,
        "generated_at_ms": engine.now_ms(),
        "notice": "Indice de cohérence observée; ce n'est pas un verdict de sécurité.",
        "policy": {
            "suspicious": engine.P_SUSPICIOUS,
            "critical": engine.P_CRITICAL,
            "cluster": engine.P_CLUSTER,
            "many": engine.P_MANY,
            "never": engine.P_NEVER,
        },
        "apps": [],
    }
    from dataclasses import asdict
    for r in sorted(results, key=lambda x: x.package):
        out["apps"].append({
            "package": r.package,
            "category": r.category,
            "score_local": r.score_local,
            "score_llm": None,
            "source": "local",
            "fingerprint_sha256": r.fingerprint,
            "incoherences_local": [asdict(x) for x in r.incoherences_local],
            "incoherences_llm": [],
            "trackers_exodus": [],
            "permissions_exodus": [],
            "evaluated_local_ms": r.evaluated_local_ms,
            "evaluated_llm_ms": 0,
        })
    return out


class handler(BaseHTTPRequestHandler):
    def _json(self, code, body):
        data = json.dumps(body, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        self._json(200, {"ok": True, "service": "aiv-coherence", "schema": "aiv-coherence-verdicts/2"})

    def do_POST(self):
        try:
            n = int(self.headers.get("Content-Length", "0"))
            if n <= 0 or n > MAX_BODY:
                raise ValueError("invalid body size")
            payload = json.loads(self.rfile.read(n).decode("utf-8"))
            self._json(200, evaluate_payload(payload))
        except (ValueError, json.JSONDecodeError, UnicodeDecodeError) as exc:
            self._json(400, {"error": str(exc)})
        except Exception:
            self._json(500, {"error": "coherence engine failure"})

    def log_message(self, fmt, *args):
        # Do not log request bodies. Platform access logs may still record metadata.
        return
