# Journal Local AIV 0.6.5 — réintégration sans perte

- Base : 0.6.4 refresh sources.
- Réintègre explicitement l’accès aux fonctions 0.5 sans retirer les ajouts 0.6.x.
- Mode Utilisateur : barre compacte **Accueil / Menu**.
- Menu : Applications, Journal, Anomalies, Décisions AIV, Référentiels, Diagnostic, Bixby, Sources.
- Mode TI : navigation technique complète inchangée.
- Applications conserve **Actualiser l’inventaire**, **Importer le rapport**, **Exporter les dossiers**.
- L’export d’autorisations reste `journal-autorisations.json`.
- Aucune nouvelle permission Android.
