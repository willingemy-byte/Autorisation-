# Actualiser — flux de cohérence AIV 0.6.4

Le bouton **Actualiser** est une action explicite de l’utilisateur.

1. Android relance l’inventaire local `PackageManager`.
2. L’APK fabrique une requête minimale contenant uniquement le nom de paquet et les noms de permissions demandées/déclarées.
3. L’APK envoie ce JSON à l’URL HTTPS configurée. Aucun PAT GitHub, secret OpenAI ou autre clé n’est embarqué dans l’APK.
4. `api/coherence.py` exécute le moteur déterministe `tools/generate_verdicts.py` et retourne `aiv-coherence-verdicts/2`.
5. Android valide le schéma, écrit atomiquement le dernier résultat dans son stockage privé puis met à jour l’accueil.
6. En cas d’échec réseau/service, le dernier résultat connu reste conservé.

La présence d’une permission ne prouve pas qu’elle a été utilisée. L’indice est un **indice de cohérence observée**, pas un verdict de sécurité.

Le mode **TI · démo** reste simulé et n’envoie pas de données de parc.
