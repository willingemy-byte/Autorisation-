# Architecture Flux — AIV 0.6.13

La vue Flux est une **projection de lecture bornée** de `journal.sqlite`. Elle ne crée aucune seconde capture ni seconde base de trafic. `EventStore.flowPage()` lit seulement des événements existants des catégories `trafic` et `dns`, regroupe au plus 50 flux par `flow_correlation_id` et borne chaque lecture à 2 500 événements réseau.

Source d’identité : `NetworkCaptureService`. `flow_correlation_id` est aléatoire, local au journal et jamais injecté dans les paquets. `native_flow_id` est l’identité interne du relais.

Attribution : UID réservé, partagé ou package non unique reste `NON_ATTRIBUABLE`. Les candidats retournés par Android sont conservés comme contexte, pas comme preuve d’auteur.

Limites : aucune lecture du contenu TLS, limites ECH/QUIC/SNI explicitement affichées. Les compteurs `tx/rx` sont des instantanés cumulatifs du flux et la projection conserve le maximum observé; elle ne les additionne pas entre événements.

Performance : la requête utilise l’index `events_category`, un plafond de lecture et aucune boucle de rafraîchissement agressive. La vue est rafraîchie à l’ouverture ou sur action utilisateur.
