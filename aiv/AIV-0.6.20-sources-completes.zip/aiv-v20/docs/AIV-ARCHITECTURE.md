# AIV : MAIN, WATCHER, JOURNAL — extension de Journal Local 0.5.0

État au 14 septembre 2026 : APK 0.6.1-aiv compilé avec SDK 35 et ECJ 3.40.0; bibliothèques natives inchangées reprises de l’APK 0.6.0 signé et épinglé (compilation native antérieure NDK r27d), signé avec la clé originale 0.5.0; aucun test sur téléphone ou émulateur Android. Ce document décrit le code livré, y compris ses limites, et non des capacités supposées d’Android.

## 1. Base retrouvée et décisions de compatibilité

La base est `journal-local-sources.zip`, complétée par `journal-local-0.5-changements.zip`; les 18 empreintes du manifeste transmis `CHANGEMENTS-SHA256.json` correspondent aux fichiers du correctif. L’APK transmis `journal-local-7.apk` est identique à `journal-local.apk` retrouvé, SHA-256 `33a0d54570660a9d54eda5bba68bb68624234fcd316c28b4dcd937b0e4b1096d`. Ce contrôle établit l’identité des fichiers retrouvés; il ne refait pas la compilation historique ni ne démontre une correspondance reproductible binaire/source.

| Demande ou contradiction | Choix du code et justification |
|---|---|
| SQLite version 1 conservée / extension AIV 2→3 | `PRAGMA user_version=1` et `SQLiteOpenHelper(...,1)` restent inchangés; `aiv_state.schema_version=3` versionne l’extension sans déclencher le `onUpgrade` existant qui refuse les migrations. |
| WorkManager / aucune nouvelle dépendance | WorkManager n’est pas présent; aucun import `androidx.work` n’est ajouté, afin de conserver la compilation locale sans dépendance. |
| Synchronisation périodique / aucune requête automatique | `ReferenceSync` importe un snapshot choisi avec le sélecteur Android; aucun planificateur ni client HTTP n’est introduit. |
| AppOps pour toutes les apps / aucune permission privilégiée | Les opérations des autres applications restent `OTHER_APPS_NOT_ACCESSIBLE`, afin de ne pas transformer une API inaccessible en observations inventées. |
| DENIED après un événement / blocage réel | `decisions.enforcement=NOT_ENFORCED` est imposé, car l’analyse d’un flux déjà observé n’empêche pas son exécution passée. |
| Registre immuable / téléphone local contrôlé par son propriétaire | Le code est append-only et détecte les altérations internes; une tête signée conservée ailleurs est nécessaire pour reconnaître certaines suppressions ou réécritures complètes. |
| Signature de chaque ligne / signature globale | `signature` reste NULL dans les lignes; l’export signé couvre toutes les lignes et leur ordre pour éviter un appel matériel Keystore par événement. |

Les modules `AnomalyMonitor`, `PermissionAudit`, `DiagnosticStore`, la capture Java/C et les relais natifs ne sont pas réécrits. `EventStore` reçoit uniquement la migration additive, la configuration de durabilité; la notification AIV par événement est supprimée en 0.6.1. `MainActivity` reçoit les commandes et le pont de lecture AIV.

## 2. Modules et frontière d’autorité

```mermaid
flowchart TD
  C["Collecteurs existants"] --> E["EventStore : événements durables"]
  E --> M["MAIN : règles déterministes"]
  P["PermissionAudit : relevé complet"] --> M
  R["Référentiels locaux"] --> M
  M --> J["JOURNAL : événement et décision chaînés"]
  J --> W["WATCHER : suivi et présentation"]
  W --> M
  J --> X["Export signé : action utilisateur"]
```

WATCHER appelle uniquement l’entrée fixe `drain(16, budget)`, sans code généré ni modification de règle. L’activation est explicite. Chaque travail dispose de bornes coopératives de temps et de lignes; aucun broadcast par événement ne précipite le prochain lot.

**Limite zero-trust :** ces classes partagent actuellement le même APK, UID, processus et accès SQLite; ce découpage n’est pas une isolation de sécurité contre une compromission du processus. Mettre WATCHER dans `android:process=":watcher"` ne changerait pas les droits du même UID. Un WATCHER réellement isolé demanderait un service isolé sans accès aux fichiers avec protocole Binder restreint, ou un autre APK/UID; ce n’est pas inclus dans cette extension. Le Watcher livré est déterministe et n’exécute pas d’IA ou de plugins.

### Flux exact et reprise

1. Le collecteur appelle `EventStore.add`, qui insère l’événement source dans SQLite; cette instruction est une transaction SQLite autonome.
2. La collecte se poursuit indépendamment; elle ne lance pas WATCHER. L’utilisateur active l’analyse dans Décisions.
3. WATCHER vérifie d’abord un préfixe figé de la chaîne par pages de 128 lignes maximum, sans transaction d’écriture sur l’historique complet.
4. MAIN ouvre une courte transaction sur **journal.sqlite**, lit au plus 16 événements après le checkpoint et charge les règles et l’inventaire utile une seule fois par lot/paquet.
5. Il scelle la projection EVENT, calcule les prédicats, insère la décision et scelle la projection DECISION.
6. Le checkpoint et les deux projections sont validés ensemble. Une annulation constatée avant la validation annule tout le lot.
7. Le service alterne analyse et statistiques incrémentales (64 décisions maximum). La tranche de 40 ms est coopérative; la pause suivante vaut au moins 1 seconde et neuf fois la durée mesurée du travail précédent. Le thread utilise la priorité d’arrière-plan.
8. Le lecteur interroge AIV uniquement dans Décisions/Référentiels visibles, au plus toutes les 10 secondes en rafraîchissement périodique. Les rafraîchissements demandés par l’utilisateur restent immédiats. Les listes de décisions n’incluent pas les raisons volumineuses; le détail les conserve.


**Fenêtre explicitement assumée :** un événement source peut être durable mais pas encore chaîné si le service est arrêté ou interrompu; il reste affiché comme en attente, et l’export signé refuse de présenter un historique incomplet comme complet. L’ancien export brut reste utilisable. Le checkpoint, les deux entrées de chaîne et la décision sont atomiques; une interruption les annule ensemble, puis le même événement est repris. Une migration historique est un scellement au moment de la mise à jour, pas une preuve de l’état antérieur des données.

L’UI propose **Activer l’analyse AIV**, **Arrêter AIV** et une vérification seule. Le démarrage du collecteur ou du VPN n’active plus AIV. **Tout arrêter** arrête les trois services. Le service utilise `START_NOT_STICKY` et rejette les redémarrages sans action explicite, y compris ceux d’une ancienne instance. Notification et arrêt restent disponibles. L’arrêt annule le travail de façon coopérative entre opérations SQLite et préserve la reprise transactionnelle. Un appel SQLite isolé peut prendre plus longtemps que la tranche visée. Aucun redémarrage automatique après force-stop ou boot n’est ajouté.

## 3. Coexistence SQLite et DDL

Le DDL exécutable complet est `app/src/main/assets/aiv-schema.sql`; chaque ligne contient une instruction complète, y compris les triggers. Le migrateur examine d’abord `PRAGMA table_info(events)` et exécute seulement les colonnes absentes :

```sql
ALTER TABLE events ADD COLUMN hash_prev TEXT;
ALTER TABLE events ADD COLUMN hash_self TEXT;
```

Ces ALTER, les nouvelles tables, les index, les triggers, les règles initiales et l’état initial sont dans une même transaction. Il n’y a ni `DROP`, ni effacement de l’historique, ni augmentation de `user_version`. `legacy_ceiling` fige le plus grand ID existant à l’installation AIV. `checkpoint=0` déclenche le backfill borné lors de l’activation du service.

| Base / tables | Rôle et atomicité |
|---|---|
| journal.sqlite : events | Source existante; les colonnes de contenu deviennent non modifiables; les empreintes peuvent être posées une seule fois. |
| journal.sqlite : decisions, journal_chain, aiv_state | Autorité commune dans une seule transaction pour éviter un faux commit atomique entre bases WAL distinctes. |
| journal.sqlite : main_rules | Versions append-only; dernières versions sélectionnées par nom, y compris désactivation versionnée. |
| journal.sqlite : reference_apps, sync_state | Snapshot par source et curseur remplacés dans une transaction; l’ancien snapshot survit à un import interrompu. |
| journal.sqlite : event_audit, audit_appmap, audit_state | Index/projections existants conservés; AIV ne change pas leurs schémas et n’utilise pas un index en cours comme preuve d’absence d’app. |
| permission-audit.sqlite | Dernier relevé terminé et immuable capturé une fois par lot; permissions utiles mises en cache par paquet, sans transaction d’écriture sur cette base. |
| journal.sqlite : aiv_app_stats, aiv_stats_state | Compteurs dérivés et checkpoint mis à jour atomiquement par petits lots; statistiques partielles affichées comme telles. |
| analysis.sqlite | Analyse par lots existante conservée; ses résultats ne deviennent pas automatiquement des règles MAIN. |
| diagnostics.sqlite | Imports/corrélations existants conservés; proximité UID/PID/heure ne devient pas automatiquement attribution certaine. |

WAL est conservé, les clés étrangères AIV sont activées, `synchronous=FULL` est demandé; les garanties matérielles de flush dépendent toujours du stockage et d’Android. Les échecs AIV restent dans `AivStore.error`; le source déjà enregistré n’est pas supprimé. Une erreur de migration annule la migration et conserve les données, mais empêche l’ouverture tant que sa cause n’est pas résolue.

Les IDs SQLite sont l’ordre d’écriture; l’horloge murale peut reculer sans réordonner la chaîne. `UNIQUE(event_id)` dans decisions et `UNIQUE(event_id,kind)` dans journal_chain empêchent les doublons de reprise. Les triggers interdisent les UPDATE/DELETE sur décisions, chaîne et règles. Ils ne protègent pas d’un attaquant qui contrôle le fichier SQLite ou peut supprimer les triggers.

## 4. Règles de cohérence

Les six règles sont initialement activées. Priorité décroissante; en cas d’égalité, nom croissant, puis version décroissante. Toutes les règles, y compris désactivées, et leurs résultats `YES / NO / UNKNOWN` sont conservés dans `reason.rules`; le premier résultat YES choisit le verdict. Sans correspondance : WATCH si une règle active manque d’observations, sinon ALLOW. ALLOW signifie uniquement « aucune règle active correspondante », pas « application sûre ».

| Règle | Priorité | Verdict | Conditions réellement appliquées |
|---|---:|---|---|
| R1 | 200 | WATCH | INTERNET déclarée dans un inventaire applicable et `details.remote_ip` absente de `expected_ips` saisies/importées explicitement par l’utilisateur. Un catalogue général sans IP attendues laisse UNKNOWN. |
| R2 | 100 | WATCH | READ_CONTACTS, synchronisation attendue, fenêtre complète et absence observée de sync. Le noyau sait évaluer ce cas, mais l’adaptateur Android livré ne fournit pas de preuve de fenêtre complète et laisse UNKNOWN. |
| R3 | 500 | DENIED | UID dont l’appId est 1000, app système, action CAMERA/MICROPHONE et absence visible attestée. L’adaptateur n’a pas ces observations globales; il ne fabrique pas de DENIED à partir de l’UID seul. |
| R4 | 400 | DENIED | Trafic attribué à un paquet unique absent d’un inventaire applicable; UID non résolu/partagé, inventaire absent, trop récent ou périmé → UNKNOWN. |
| R5 | 300 | WATCH | `tx_bytes > threshold` et destination hors whitelist utilisateur configurée. Le seuil initial est 10 Mio par flux; les compteurs cumulatifs ne sont jamais additionnés entre snapshots. |
| R6 | 600 | DENIED | SNI égal à un domaine surveillé ou à un de ses sous-domaines; `evil-example.org` ne correspond pas à `example.org`. Liste initiale vide. |

Un inventaire est applicable seulement s’il est terminé avant l’événement, a moins de 24 heures à cet instant, et si le paquet est attribuable sans UID partagé; ce choix conservateur évite d’appliquer le relevé courant comme fait historique. Il ne prouve pas que PackageManager a exposé tous les paquets/profils. R4 reste une politique personnelle d’inventaire, jamais une accusation d’app malveillante.

L’inventaire stocke permissions **déclarées**, pas une preuve de leur usage ni systématiquement de leur octroi. READ_CONTACTS n’implique pas qu’une synchronisation doive exister : R2 exige donc une attente explicite. Le VPN ne révèle ni l’accès aux contacts, ni caméra/micro, ni le but d’une requête TLS. SNI/ECH/QUIC conservent les limites du collecteur existant.

L’éditeur JSON est limité à R1–R6, avec taille et listes bornées; `condition` n’est jamais du SQL/JavaScript exécutable. Une modification est confirmée localement, écrit une nouvelle version de règle et un événement `aiv-policy` atomiquement, puis prend effet sur les prochains événements évalués, y compris un éventuel backlog. Les décisions passées ne sont jamais recalculées/écrasées.

Exemple de configuration R6 :

```json
{"name":"R6","decision":"DENIED","priority":600,"enabled":true,"condition":{"type":"R6","domains":["example.org"],"threshold":10485760,"whitelist":[],"whitelist_configured":false}}
```

## 5. Chaînage, signatures et confiance

`ChainStore` est Java pur. La concaténation naïve `hash_prev + payload + timestamp` est remplacée par un encodage délimité pour éviter les ambiguïtés et protéger aussi l’ordre :

```text
hash_self = SHA256(
  ASCII("AIV-CHAIN-1\0") || HEX_DECODE(hash_prev) ||
  INT64_BE(sequence) || INT64_BE(timestamp_ms) ||
  INT32_BE(length_utf8(payload)) || UTF8(payload)
)
```

`payload` utilise `pack` : chaque champ est `longueur_UTF8:valeur`; NULL est `-1:` et chaîne vide `0:`. Aucun tri JSON ou réencodage n’est nécessaire à la vérification : les octets de la chaîne JSON source sont figés comme champ texte.

- EVENT lie kind, ID, timestamp, app, action, destination, transport, category, payload et search_text, dans cet ordre.
- DECISION lie kind, ID décision, ID événement, règle choisie, verdict, reason, timestamp et enforcement.
- `reason` contient l’empreinte de l’événement, les versions/conditions évaluées, les observations utiles et leur provenance.
- L’empreinte d’une ligne events/decisions est une projection de sa ligne dans la chaîne commune; le prédécesseur d’un événement peut donc être une décision.
- Vérifier localement compare chaîne, ordre, projections sources, tête, cardinalité et checkpoint; une chaîne signalée BROKEN suspend MAIN et n’est jamais « réparée » par recalcul silencieux.

`PinVault` crée une clé EC P-256 dans Android Keystore, sans authentification utilisateur requise pour chaque signature. StrongBox est demandé sous API 28+, avec repli sur Keystore standard si `StrongBoxUnavailableException`; le niveau réel est publié selon `KeyInfo` (StrongBox, TEE, logiciel ou inconnu). Le repli standard n’est pas automatiquement qualifié TEE. Une erreur sur une clé existante ne déclenche pas de rotation silencieuse. La clé privée d’export n’est jamais exportée.

**Cette clé Keystore est distincte de la clé de signature APK.** La clé APK doit rester celle de la 0.5; le build refuse désormais de créer une clé de remplacement et vérifie le certificat attendu avant signature.

### Format d’export JSONL signé

1. HEADER : format, date, genesis, nombre de records, tête, checkpoint, statut de signature, clé publique SPKI et son ID SHA-256, niveau Keystore.
2. RECORD : une ligne pour chaque entrée `journal_chain`, avec son payload exact et ses liens.
3. FOOTER : SHA-256 des octets UTF-8 de HEADER+RECORD, chaque LF compris, et signature DER ECDSA.

Le message signé est `ASCII("AIV-EXPORT-1\n" + sha256_hex_du_corps)`, algorithme `SHA256withECDSA`. La signature protège donc aussi la clé annoncée, le statut, le nombre et la tête présents dans le header. Elle est autovérifiée avant publication locale. Le fichier est préparé en `.part`, flush/fsync, puis renommé; seul le fichier complet est envoyé au document choisi par l’utilisateur. La copie SAF externe n’est pas atomique : en cas d’interruption, le snapshot local complet reste réexportable et le vérificateur rejette une copie tronquée.

Si le Keystore est indisponible **à l’ouverture**, l’export porte `UNSIGNED_KEYSTORE_UNAVAILABLE` et `algorithm=NONE`; si la signature échoue après préparation d’un export annoncé signé, l’export est annulé plutôt que maquillé. Sans signature, intégrité interne et authenticité sont distinctes. La colonne `signature` de chaque ligne est NULL; la fiche l’annonce explicitement.

Vérification indépendante, sans réseau ni bibliothèque Python tierce :

```bash
python3 tools/verify_aiv_export.py journal-aiv-signe.jsonl --key-sha256 EMPREINTE_SPKI_CONNUE
```

Le pin est l’empreinte publique Keystore de cet appareil, obtenue et conservée par un canal déjà fiable; ce n’est pas le certificat APK. Code retour 0 = chaîne/export valides et clé épinglée; 2 = valide mais clé non épinglée ou export non signé; 1 = échec. Accepter la clé incluse sans pin prouve seulement que le fichier est signé par cette clé, pas qu’elle provient du téléphone attendu. Conserver séparément des exports/têtes précédents est nécessaire pour détecter des régressions entre snapshots; le vérificateur livré vérifie un snapshot et ne tient pas lui-même un registre d’ancres.

### Limites de performances explicites

L’analyse AIV est en pause par défaut; la collecte reste indépendante. La vérification courante avance sur un préfixe capturé sans verrou d’écriture prolongé. Les deux comptages finaux utilisent des index étroits mais peuvent encore parcourir beaucoup de lignes. Les compteurs d’affichage sont incrémentaux et leur retard est annoncé; les différences d’ID ne sont jamais présentées comme un nombre exact d’événements.

L’export signé explicite conserve une vérification complète et un snapshot transactionnel : il peut retarder les écrivains sur un gros journal. Il est exécuté à priorité d’arrière-plan et refuse immédiatement un journal dont la reprise AIV n’est pas terminée. La durabilité `synchronous=FULL`, les données et les autres collecteurs sont conservés. Les limites de travail ne constituent pas une promesse de consommation CPU maximale pour l’application entière. Aucun gain CPU, batterie ou fluidité n’a été mesuré sur le Samsung. Voir `VALIDATION.md` pour les tests exécutés sur hôte.

## 6. Référentiels et absence de transfert

`ReferenceSync.java` est un importateur offline complet avec validation, transaction, journal d’import et curseur; **ce n’est pas un Worker WorkManager ni un client des API Bayton/Exodus**. Le dernier snapshot valide reste disponible si un import échoue. `source` est une provenance déclarée, pas une signature authentifiant Bayton ou Exodus; l’UI affiche `IMPORTED_LOCAL_UNVERIFIED_SOURCE`.

Les chemins proposés `/api/mcp/sysapps/list-devices`, `get-device-apps`, `search` n’ont pas pu être validés via les sources accessibles. Aucun contrat HTTP, méthode, paramètre ou pagination n’est inventé. Ils ne sont pas appelés par l’APK. Pour un futur connecteur, il faut vérifier le contrat officiel, privilégier un catalogue global fixe et ne jamais envoyer paquets installés, UID, journaux, adresses, modèle détecté ou identifiants. Aucun import de données externes ne doit déclencher une modification de règles.

Format normalisé importable, exemple de politique locale avec adresse réservée à la documentation :

```json
{"schema":"aiv-reference/1","source":"user","cursor":"snapshot-1","apps":[{"package_name":"example.app","declared_permissions":["android.permission.INTERNET"],"certificates":[],"expected_ips":["192.0.2.10"]}]}
```

Les sources `bayton` et `exodus` sont autorisées pour les snapshots normalisés, mais `expected_ips` est réservé à `user`; une liste publique de packages n’est pas une autorisation réseau. L’import est borné à 16 Mio, 20 000 fiches, 32 768 caractères par fiche et 100 IP attendues par app. Les téléchargements/conversions depuis leurs formats natifs ne sont pas implémentés.

## 7. Interface intégrée

- **Décisions** : ALLOW/WATCH/DENIED, filtre, pagination descendante par ID (50), première/page suivante, fiche de l’événement, raison, chaîne et portée de signature.
- **Journal** : la fiche de chaque événement possède un volet Intégrité AIV, avec hashes ou attente de scellement; les sources originales restent lisibles.
- **Référentiels** : dernière importation, nombre de fiches, source, statut, bouton d’import et actualisation.
- **Indicateur global** : compteur de signalements et ratios par libellé d’application, limités aux 100 premiers; WATCH pour manque d’observation est inclus et cette convention est affichée.
- **Vérification** : états NOT_CHECKED, VERIFYING_N_OF_TOTAL, PAUSED, VALID_AT_N ou BROKEN, ce dernier en rouge; aucune signature individuelle verte n’est simulée.

Les ratios sont regroupés par le champ `events.app` existant (libellé/UID partagé), pas par identité cryptographique unique; des libellés identiques peuvent fusionner, et des observations répétées d’un flux comptent comme plusieurs événements. Ce n’est ni un pourcentage de bienveillance ni une probabilité d’intention. Un score d’intention n’est pas déduit de ces compteurs.

Les chaînes externes et JSON sont affichés avec `textContent`, sans `innerHTML`. La WebView conserve son blocage réseau, les iframes interdites, les permissions refusées et le pont limité au lecteur embarqué. La confirmation d’une modification de règle est une action native locale, pas une requête de permission de travail dans cette conversation.

## 8. Mise à jour et validation

Le manifeste candidat porte package `fr.erick.journallocal`, versionCode 7, versionName `0.6.1-aiv`, minSdk 26 et targetSdk 35. Aucune permission Android supplémentaire; un service spécial non exporté utilise la permission déjà présente.

Pour compiler dans l’environnement déjà équipé, utiliser le `build.py` existant avec ses paramètres; il ne télécharge rien :

```bash
python3 build.py --android-jar /SDK/platforms/android-35/android.jar \
  --build-tools /SDK/build-tools/35.0.0 --ecj /outils/ecj-3.40.0.jar \
  --ndk /SDK/ndk/r27d --signing-dir /prive/journal-local-signing
python3 tests/verify_package.py --build-tools /SDK/build-tools/35.0.0 --old-apk /reference/journal-local-0.5.apk
```

Le chemin NDK est à adapter au répertoire r27d réellement installé; aucune nouvelle version n’est téléchargée. Ne pas désinstaller 0.5 avant la mise à jour. Ne pas signer avec une autre clé. Le certificat attendu, repris du rapport 0.5, est SHA-256 `4a14b9e2cf3869fa9faf2317cba96e948145e4dba32240f9547380c040deba7b`. La validation APK finale a comparé directement la signature à l’APK 0.6.0. Le `.p12` et `password.txt` restent hors de cette archive et d’un éventuel dépôt public.

Le maintien du schéma version 1 n’autorise pas à promettre un downgrade APK supporté par Android : le système impose normalement un versionCode croissant. Une ancienne app capable d’ouvrir la base pourrait encore lire les colonnes originales, mais ses tentatives de modification/suppression des événements seraient bloquées par les nouveaux triggers.

Voir `VALIDATION.md` pour les commandes réellement exécutées et leurs limites. La compilation ECJ/API 35, D8, l’assemblage, la signature originale et les contrôles du paquet sont réussis. La 0.6.1 reprend les bibliothèques natives vérifiées de la 0.6.0 avec contrôle de leurs empreintes et de tous les fichiers source natifs; `--reuse-native-apk-06` permet de reproduire ce chemin. Restent les validations sur appareil : installation en mise à jour, migration d’une copie réaliste, interruption/force-stop, Keystore matériel et capture concurrente.

## 9. Références techniques consultées

- [Types de services au premier plan](https://developer.android.com/develop/background-work/services/fgs/service-types) : nécessité de déclarer un type et sa permission appropriée.
- [Restrictions de démarrage en arrière-plan](https://developer.android.com/develop/background-work/services/fgs/restrictions-bg-start) : le démarrage depuis une activité visible évite de supposer un droit permanent de relance.
- [Android Keystore](https://developer.android.com/privacy-and-security/keystore) : protection des clés et distinction matériel/logiciel.
- [AppOpsManager](https://developer.android.com/reference/android/app/AppOpsManager) : les capacités accessibles doivent être distinguées de l’observation universelle des apps.
- [Catalogue Bayton](https://sysapps.bayton.org/) : site retrouvé; les trois chemins MCP proposés ne sont pas validés comme contrat d’intégration.

AIV expose les écarts entre déclaratif, comportement observable et règles personnelles; il ne prétend pas détecter les intentions.
