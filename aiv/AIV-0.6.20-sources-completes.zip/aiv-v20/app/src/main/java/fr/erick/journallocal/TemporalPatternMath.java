package fr.erick.journallocal;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Pure interval math used by the on-demand temporal correlation view. */
final class TemporalPatternMath {
    static final class Interval {
        final long start,end;
        Interval(long start,long end){this.start=start;this.end=Math.max(start,end);}
    }
    static final class Metrics {
        int pairedAfter;
        int pairedBefore;
        int outsideAfter;
        long medianAfterMs=-1;
    }
    static List<Interval> collapse(List<Interval> input,long gapMs){
        ArrayList<Interval> sorted=new ArrayList<>(input);
        Collections.sort(sorted,Comparator.comparingLong(a->a.start));
        ArrayList<Interval> out=new ArrayList<>();
        for(Interval next:sorted){
            if(out.isEmpty()){out.add(next);continue;}
            Interval last=out.get(out.size()-1);
            if(next.start<=last.end+gapMs)out.set(out.size()-1,new Interval(last.start,Math.max(last.end,next.end)));
            else out.add(next);
        }
        return out;
    }
    static long relationMs(Interval trigger,Interval candidate){
        if(candidate.start>=trigger.end)return candidate.start-trigger.end;
        if(candidate.end<=trigger.start)return candidate.end-trigger.start;
        return 0;
    }
    static Metrics metrics(List<Interval> triggers,List<Interval> candidates,long windowMs){
        Metrics out=new Metrics();ArrayList<Long> delays=new ArrayList<>();
        boolean[] matchedCandidate=new boolean[candidates.size()];
        for(Interval trigger:triggers){
            boolean after=false,before=false;long bestDelay=Long.MAX_VALUE;
            for(int i=0;i<candidates.size();i++){
                Interval candidate=candidates.get(i);
                if(candidate.start>=trigger.end&&candidate.start<=trigger.end+windowMs){after=true;matchedCandidate[i]=true;bestDelay=Math.min(bestDelay,candidate.start-trigger.end);}
                if(candidate.end<=trigger.start&&candidate.end>=trigger.start-windowMs)before=true;
            }
            if(after){out.pairedAfter++;delays.add(bestDelay);}if(before)out.pairedBefore++;
        }
        for(boolean matched:matchedCandidate)if(!matched)out.outsideAfter++;
        if(!delays.isEmpty()){Collections.sort(delays);int m=delays.size()/2;out.medianAfterMs=delays.size()%2==1?delays.get(m):(delays.get(m-1)+delays.get(m))/2;}
        return out;
    }
    private TemporalPatternMath(){}
}
