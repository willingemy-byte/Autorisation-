package fr.erick.journallocal;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** On-demand, descriptive temporal correlations over already-recorded network metadata. */
public final class TemporalPatterns {
    private static final long BASELINE_MS=24L*60L*60L*1000L;
    private static final long WINDOW_MS=60L*1000L;
    private static final long ACTOR_BURST_GAP_MS=30L*1000L;
    private static final long SAME_SIGNATURE_GAP_MS=5L*1000L;
    private static final int MAX_CANDIDATES=12;
    private static final int MAX_BASELINE_ROWS=100000;
    private static final int MAX_WINDOW_ROWS=5000;

    private static final class FlowAcc {
        String actor,flowId,remoteIp,tlsSni="";int port=-1;long start=Long.MAX_VALUE,end=0;
        final LinkedHashSet<String> dns=new LinkedHashSet<>();
    }
    private static final class Episode {
        String actor,endpoint,type,key;long start,end;
        TemporalPatternMath.Interval interval(){return new TemporalPatternMath.Interval(start,end);}
    }
    private static final class ActivityPoint {String actor;long timestamp;}
    private static final class Loaded {
        final ArrayList<Episode> episodes=new ArrayList<>();final ArrayList<ActivityPoint> activity=new ArrayList<>();int rows;boolean truncated;long earliest=Long.MAX_VALUE;
    }
    private static String normHost(String value){
        if(value==null)return "";String out=value.trim().toLowerCase(Locale.ROOT);while(out.endsWith("."))out=out.substring(0,out.length()-1);return out;
    }
    private static String sqlPlaceholders(int n){StringBuilder b=new StringBuilder();for(int i=0;i<n;i++){if(i>0)b.append(',');b.append('?');}return b.toString();}
    private static Loaded load(SQLiteDatabase db,long from,long to,Set<String> actors,int maxRows)throws Exception{
        Loaded result=new Loaded();StringBuilder sql=new StringBuilder("SELECT id,timestamp_ms,app,payload FROM events WHERE timestamp_ms>=? AND timestamp_ms<=? AND category IN ('trafic','dns')");
        ArrayList<String> args=new ArrayList<>();args.add(String.valueOf(from));args.add(String.valueOf(to));
        if(actors!=null&&!actors.isEmpty()){sql.append(" AND app IN (").append(sqlPlaceholders(actors.size())).append(')');for(String actor:actors)args.add(actor);}
        sql.append(" ORDER BY timestamp_ms DESC,id DESC LIMIT ?");args.add(String.valueOf(maxRows+1));
        LinkedHashMap<String,FlowAcc> flows=new LinkedHashMap<>();
        try(Cursor c=db.rawQuery(sql.toString(),args.toArray(new String[0]))){
            while(c.moveToNext()){
                result.rows++;if(result.rows>maxRows){result.truncated=true;break;}
                long id=c.getLong(0),ts=c.getLong(1);result.earliest=Math.min(result.earliest,ts);String actor=c.getString(2);ActivityPoint point=new ActivityPoint();point.actor=actor;point.timestamp=ts;result.activity.add(point);JSONObject e=new JSONObject(c.getString(3)),d=e.optJSONObject("details");if(d==null)continue;
                String flow=d.optString("flow_correlation_id","");if(flow.isEmpty())flow="event-"+id;String mapKey=actor+'\u0000'+flow;
                FlowAcc f=flows.get(mapKey);if(f==null){f=new FlowAcc();f.actor=actor;f.flowId=flow;flows.put(mapKey,f);}
                long observedStart=d.optLong("first_observed_ms",ts),observedEnd=d.optLong("last_packet_ms",ts);if(observedStart<=0)observedStart=ts;if(observedEnd<=0)observedEnd=ts;f.start=Math.min(f.start,Math.min(ts,observedStart));f.end=Math.max(f.end,Math.max(ts,observedEnd));String remote=normHost(d.optString("remote_ip",""));if(!remote.isEmpty())f.remoteIp=remote;int port=d.optInt("port",-1);if(port>=0)f.port=port;
                String tls=normHost(d.optString("tls_sni",""));if(!tls.isEmpty())f.tlsSni=tls;
                if("dns".equals(e.optString("category"))){String q=normHost(d.optString("question",e.optString("destination","")));if(!q.isEmpty())f.dns.add(q);}
            }
        }
        for(FlowAcc f:flows.values()){
            if(!f.dns.isEmpty())for(String q:f.dns)result.episodes.add(episode(f,"dns",q));
            else if(!f.tlsSni.isEmpty())result.episodes.add(episode(f,"tls",f.tlsSni));
            else if(f.remoteIp!=null&&!f.remoteIp.isEmpty())result.episodes.add(episode(f,"ip",f.remoteIp+(f.port>=0?":"+f.port:"")));
        }
        Collections.sort(result.episodes,Comparator.comparingLong(a->a.start));return result;
    }
    private static Episode episode(FlowAcc f,String type,String endpoint){Episode e=new Episode();e.actor=f.actor;e.endpoint=endpoint;e.type=type;e.start=f.start;e.end=f.end;e.key=f.actor+'\u0000'+endpoint;return e;}
    private static ArrayList<TemporalPatternMath.Interval> actorBursts(Loaded loaded,String actor){
        ArrayList<TemporalPatternMath.Interval> raw=new ArrayList<>();for(ActivityPoint p:loaded.activity)if(actor.equals(p.actor))raw.add(new TemporalPatternMath.Interval(p.timestamp,p.timestamp));return new ArrayList<>(TemporalPatternMath.collapse(raw,ACTOR_BURST_GAP_MS));
    }
    private static TemporalPatternMath.Interval selectedBurst(List<TemporalPatternMath.Interval> bursts,long timestamp){
        TemporalPatternMath.Interval best=null;long distance=Long.MAX_VALUE;
        for(TemporalPatternMath.Interval b:bursts){long d=timestamp<b.start?b.start-timestamp:timestamp>b.end?timestamp-b.end:0;if(d<distance){distance=d;best=b;}}
        return best==null?new TemporalPatternMath.Interval(timestamp,timestamp):best;
    }
    private static ArrayList<TemporalPatternMath.Interval> occurrences(List<Episode> episodes,String key){
        ArrayList<TemporalPatternMath.Interval> raw=new ArrayList<>();for(Episode e:episodes)if(key.equals(e.key))raw.add(e.interval());return new ArrayList<>(TemporalPatternMath.collapse(raw,SAME_SIGNATURE_GAP_MS));
    }
    private static String relationLabel(long delta){return delta>0?"apres":delta<0?"avant":"chevauche";}

    public static JSONObject analyze(Context context,long eventId)throws Exception{
        SQLiteDatabase db=EventStore.get(context).getReadableDatabase();long anchorMs;String anchorActor,anchorCategory;
        try(Cursor c=db.rawQuery("SELECT timestamp_ms,app,category FROM events WHERE id=?",new String[]{String.valueOf(eventId)})){
            if(!c.moveToFirst())throw new IllegalArgumentException("Événement introuvable");anchorMs=c.getLong(0);anchorActor=c.getString(1);anchorCategory=c.getString(2);
        }
        long baselineStart=anchorMs-BASELINE_MS,baselineEnd=anchorMs+WINDOW_MS;
        LinkedHashSet<String> anchorOnly=new LinkedHashSet<>();anchorOnly.add(anchorActor);
        Loaded anchorLoaded=load(db,baselineStart,baselineEnd,anchorOnly,MAX_BASELINE_ROWS);
        ArrayList<TemporalPatternMath.Interval> triggerBursts=actorBursts(anchorLoaded,anchorActor);TemporalPatternMath.Interval currentBurst=selectedBurst(triggerBursts,anchorMs);

        Loaded current=load(db,currentBurst.start-WINDOW_MS,currentBurst.end+WINDOW_MS,null,MAX_WINDOW_ROWS);
        LinkedHashMap<String,Episode> nearest=new LinkedHashMap<>();
        for(Episode e:current.episodes){if(anchorActor.equals(e.actor))continue;long delta=TemporalPatternMath.relationMs(currentBurst,e.interval());if(Math.abs(delta)>WINDOW_MS)continue;Episode prev=nearest.get(e.key);if(prev==null||Math.abs(TemporalPatternMath.relationMs(currentBurst,e.interval()))<Math.abs(TemporalPatternMath.relationMs(currentBurst,prev.interval())))nearest.put(e.key,e);}
        ArrayList<Episode> candidates=new ArrayList<>(nearest.values());Collections.sort(candidates,(a,b)->Long.compare(Math.abs(TemporalPatternMath.relationMs(currentBurst,a.interval())),Math.abs(TemporalPatternMath.relationMs(currentBurst,b.interval()))));
        if(candidates.size()>MAX_CANDIDATES)candidates=new ArrayList<>(candidates.subList(0,MAX_CANDIDATES));

        LinkedHashSet<String> relevantActors=new LinkedHashSet<>();relevantActors.add(anchorActor);for(Episode e:candidates)relevantActors.add(e.actor);
        Loaded baseline=load(db,baselineStart,baselineEnd,relevantActors,MAX_BASELINE_ROWS);
        triggerBursts=actorBursts(baseline,anchorActor);currentBurst=selectedBurst(triggerBursts,anchorMs);

        JSONArray rows=new JSONArray();
        for(Episode candidate:candidates){
            ArrayList<TemporalPatternMath.Interval> occ=occurrences(baseline.episodes,candidate.key);TemporalPatternMath.Metrics m=TemporalPatternMath.metrics(triggerBursts,occ,WINDOW_MS);long delta=TemporalPatternMath.relationMs(currentBurst,candidate.interval());
            LinkedHashSet<String> evidenceTypes=new LinkedHashSet<>();for(Episode e:baseline.episodes)if(candidate.key.equals(e.key))evidenceTypes.add(e.type.toUpperCase(Locale.ROOT));JSONArray evidence=new JSONArray();for(String type:evidenceTypes)evidence.put(type);
            rows.put(EventStore.object("actor",candidate.actor,"endpoint",candidate.endpoint,"signature_key",candidate.key,"evidence_types",evidence,"current_relation",relationLabel(delta),"current_delta_ms",delta,"current_start_ms",candidate.start,"current_end_ms",candidate.end,
                "occurrences_baseline",occ.size(),"trigger_bursts_baseline",triggerBursts.size(),"paired_after_window",m.pairedAfter,"paired_before_window",m.pairedBefore,"outside_after_windows",m.outsideAfter,"median_after_delay_ms",m.medianAfterMs,
                "paired_after_ratio",triggerBursts.isEmpty()?JSONObject.NULL:((double)m.pairedAfter/(double)triggerBursts.size())));
        }
        long actualStart=baseline.earliest==Long.MAX_VALUE?baselineStart:baseline.earliest;
        return EventStore.object("schema","journal-temporal-pattern/1","anchor_event_id",eventId,"anchor_actor",anchorActor,"anchor_category",anchorCategory,"anchor_timestamp_ms",anchorMs,
            "anchor_burst_start_ms",currentBurst.start,"anchor_burst_end_ms",currentBurst.end,"window_ms_each_side",WINDOW_MS,"trigger_burst_gap_ms",ACTOR_BURST_GAP_MS,"signature_merge_gap_ms",SAME_SIGNATURE_GAP_MS,
            "baseline_requested_ms",BASELINE_MS,"baseline_actual_start_ms",actualStart,"baseline_end_ms",baselineEnd,"baseline_rows_loaded",baseline.rows,"baseline_truncated",baseline.truncated||anchorLoaded.truncated,
            "trigger_bursts_baseline",triggerBursts.size(),"candidates",rows,"interpretation","Corrélation temporelle descriptive seulement : proximité et répétition ne démontrent pas à elles seules qu’un acteur a déclenché l’autre.",
            "scope","Calcul local sur les métadonnées réseau déjà journalisées; aucun contenu TLS n’est lu et aucun nouvel événement réseau n’est créé.");
    }
    private TemporalPatterns(){}
}
