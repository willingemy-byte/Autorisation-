# AIV 0.6.15 — journal stable et référence locale

Version Android 0.6.15, code 21, paquet `fr.erick.journallocal`. Mise à jour signée avec le même certificat que les versions précédentes. Installer par-dessus l’application existante pour conserver les données.

## Utilisation

- Accueil → Actualiser, ou Autorisations → Actualiser l’inventaire : relève les permissions et alimente directement la référence locale estimée. Aucun JSON à recréer ni à importer pour le calcul des pénalités.
- Menu → Référentiel local → Actualiser l’inventaire et la référence : même opération. Le statut précise le dernier relevé terminé. L’export de la référence actuelle contient un seul état par paquet.
- Journal → Actualiser le journal : recharge la liste à la demande et revient à la première page en conservant les filtres. Les événements restent collectés en arrière-plan. Aucun rafraîchissement périodique de la liste ou de son détail.
- Autorisations → Exporter le dernier inventaire : seulement le dernier relevé et les dossiers/réglages courants. Exporter tout l’historique conserve l’ancienne possibilité d’export intégral, potentiellement volumineux.
- Barème AIV : la case « Référence locale estimée quand aucune observation n’est renseignée » permet de désactiver le calcul estimé. La propriété JSON correspondante est `derived_reference`.

## Ce que signifie la référence automatique

Le fichier fourni, `aiv-reference-v6-system-android.json`, couvre 523 paquets. Ses propres notes le décrivent comme une calibration dérivée, non comme une extraction indépendante de Google Play ou une lecture des réglages. L’APK embarque ses choix par paquet et permission, sous forme compacte.

Pour chaque permission du dernier inventaire :

1. Si son nom et son niveau de protection correspondent à la calibration, reprendre son classement visible/candidat moins visible.
2. Pour une permission nouvelle ou dont le niveau a changé, classer comme exposable une permission `android.permission.*` de niveau de base normal ou dangereux. Les autres restent candidates moins visibles. Cette règle de repli est une convention du modèle, pas une preuve de l’interface Android.
3. Dédupliquer les noms, retirer automatiquement du calcul les permissions absentes du relevé courant, recalculer R, V et H.

La référence principale estimée porte explicitement la mention « estimation » dans la liste et les fiches. La couche « Toutes les autorisations » reste inconnue tant qu’une observation distincte n’est pas fournie. Les nombres saisis manuellement restent prioritaires, même quand leur version est périmée : ils sont alors signalés non évaluables plutôt que remplacés silencieusement. Un écart nul estimé ne prouve pas la transparence de l’application. Les multiplicateurs des niveaux 2 à 5 continuent à demander leurs règles ou observations; ils ne sont pas déduits du seul niveau de protection Android.

Le barème par défaut autorise la référence dérivée afin de fonctionner dès l’actualisation. La moyenne conserve le dénominateur des seules applications avec H > 0. Elle peut donc mélanger observations et estimations; l’accueil indique combien de fiches utilisent une estimation. Désactiver `derived_reference` pour ne calculer que sur les observations renseignées.

Les références dérivées importées avec `reference_basis` commençant par `derived_` et `permission_meta` peuvent remplacer la calibration embarquée pour les paquets concernés. Le référentiel courant exporté comporte ces champs et peut être réimporté. Les anciens catalogues et observations sont conservés. La limite par fiche à l’import passe à 256 Kio pour accepter notamment la fiche Système Android du fichier fourni; le fichier complet reste limité à 16 Mio. Le nom de paquet `android` est accepté.

## Stockage et périmètre

Aucun envoi vers Drive, Supabase ou cette conversation n’est effectué par l’APK. Tout est calculé sur le téléphone. Le référentiel courant est produit depuis le dernier inventaire, sans recopier tous les anciens relevés. L’historique déjà enregistré est préservé; cette version ne compacte pas la base privée et les inventaires historiques continuent à y être conservés. C’est l’export courant qui cesse de grossir avec le nombre de relevés.

Le rafraîchissement manuel concerne le journal. D’autres panneaux techniques peuvent encore actualiser leurs propres statuts. Les changements de filtre, de page et les commandes explicites du journal déclenchent toujours les lectures nécessaires.

## Vérification

Compilation Java et native pour arm64-v8a et x86_64; APK signé et vérifié. Tests du modèle de pénalité, priorité des références manuelles, versions périmées, désactivation de la référence dérivée, séparation des deux vues. Tests d’interface avec pont Android simulé : liste et nœuds DOM stables malgré l’arrivée de nouveaux événements, champ de recherche et détail ouverts conservés, actualisation manuelle, réglages et calculs. Tests de compatibilité de l’accueil et de l’attribution des événements.

L’APK V13 fourni contient encore un rafraîchissement de trois secondes pour le segment actif, mais pas pour les segments historiques. La V15 supprime ce rafraîchissement de la liste du journal. Le fichier de test historique `native-reader.cjs` attend encore l’ancienne actualisation automatique; le nouveau contrat est vérifié par `journal-stability.cjs`.

Pas de validation sur un téléphone Samsung physique ni sur un émulateur dans cette session. La réception réelle des autorisations et l’installation doivent être confirmées sur l’appareil.
