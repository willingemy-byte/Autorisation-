# Source canonique AIV 0.6.12 — versionCode 18

Export des fichiers source effectifs du run Railway 20260916T230335Z-88b63ae4, service aiv-android-builder-v1. Aucun changement au code applicatif. Les anciens documents 0.6.9/0.6.11 inclus décrivent leur version historique.

Utiliser le moteur et la procédure dans AIV-RAILWAY-BRIDGE.zip. SOURCE-SHA256.json contient les empreintes de cette archive. Les anciens rapports de build, caches, binaires, variables et secrets ont été exclus. Les 123 fichiers exportés sont traçables dans verification/source-export.json et source-export-evidence.zip du pont. Le fichier de hashes ancien est conservé dans history du pont.

L'export comprend le code Java/C, les assets, toutes les sources tierces avec licences, les tests, les générateurs d'interface, build.py, bootstrap-clean-build.sh et les définitions de la chaîne de compilation.
