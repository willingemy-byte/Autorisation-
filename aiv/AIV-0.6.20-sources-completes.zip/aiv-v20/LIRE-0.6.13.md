# Journal Local AIV 0.6.13 — guide rapide

## Ce qui change
La 0.6.13 rend visible la corrélation des flux déjà produite par le VPN local de Journal Local. Elle ne crée pas un second moteur réseau et n’insère aucun identifiant dans les paquets Internet.

## Accueil et score CB
L’accueil conserve l’indice 0–100. Vert: 85–100; jaune: 70–84; orange: 50–69; rouge: moins de 50. Les applications sans catégorie/score exploitable restent visibles comme non évaluées mais sont exclues de la moyenne. Le nombre total, le nombre évalué, les non évaluées, les anomalies et les événements réseau non attribuables sont affichés séparément. Un score est un indice de cohérence observée, jamais une preuve de sécurité ou de malveillance.

## Android / Système / Utilisateur
Les trois groupes sont exclusifs. **Android** contient les identités réservées, partagées ou non attribuables. **Système** contient les applications préinstallées identifiées par un package unique. **Utilisateur** contient les applications installées par l’utilisateur identifiées par un package unique. Une liste de packages candidats pour un UID partagé n’est pas une preuve d’auteur.

## Flux
Ouvrir **Menu → Flux**, ou ouvrir une application puis **Voir les flux réseau de cette application**, ou ouvrir un événement réseau puis **Voir le flux complet**. Chaque fiche de flux peut montrer, si disponible: acteur, groupe, UID, protocole, IP/port distant, premier paquet sortant, premier retour entrant, octets/paquets envoyés et reçus, état ouvert/fermé, DNS, SNI TLS et l’identifiant local `flow_correlation_id`.

La vue regroupe des événements déjà présents dans `journal.sqlite`; elle ne duplique pas le trafic. Le `flow_correlation_id` est local et n’est jamais injecté dans Internet. TLS n’est pas déchiffré. QUIC, ECH et les limites Android/VPN peuvent masquer certaines métadonnées.

## Applications et permissions
**Menu → Applications** ouvre l’inventaire PackageManager. Une permission déclarée montre une capacité déclarée, pas son utilisation. Une référence Play n’est comparée que si sa provenance et la correspondance de version sont suffisantes; sinon l’interface la présente comme incomplète plutôt que comme preuve.

## Référentiels
La section est libellée **Importer des référentiels**. Bayton et Exodus ne sont pas connectés automatiquement dans cette version. L’import attendu reste un JSON local normalisé `aiv-reference/1`, avec sa provenance affichée.

## Exposition imposée
Lorsqu’AIV dispose réellement des données nécessaires, une capacité sensible non réellement désinstallable et non réellement révocable peut être présentée comme exposition imposée. Cela reste distinct de la présence d’une permission et de son utilisation effective.

## Vue TI
La vue TI reste une **simulation**. Ses appareils et alertes ne représentent pas un parc réel. Les actions de démonstration recalculent l’état simulé uniquement.

## Données et performance
Le journal, l’inventaire, l’analyse, les flux et les référentiels sont locaux par défaut. L’inventaire minimal paquet + permissions ne sort que si l’utilisateur configure explicitement un moteur HTTPS et lance Actualiser. La vue Flux est bornée; les statistiques de transparence sont mises en cache 15 secondes pour éviter un gros recalcul à chaque rafraîchissement.

## Test humain conseillé sur le Samsung
Après installation: ouvrir Accueil, vérifier les trois groupes et leurs comptes; activer les connexions apps; utiliser une application réseau; ouvrir Flux et confirmer qu’un flux affiche un premier sortant puis, lorsqu’observé, un premier retour; ouvrir une app et vérifier le bouton vers ses flux; vérifier qu’UID 1000/UID partagé restent non attribuables; vérifier la fluidité avec le journal existant.
