# AIV 0.6.20 — motifs temporels mesurables

Cette version ajoute une analyse **à la demande** des répétitions temporelles autour d’un événement réseau déjà journalisé. Elle ne crée pas de nouveau trafic et ne lit aucun contenu TLS.

## Mesurer les motifs temporels

Dans le détail d’un événement `trafic` ou `dns`, le bouton **Mesurer les motifs temporels** :

- prend l’acteur de l’événement comme déclencheur observé;
- regroupe ses flux proches en épisodes d’activité (écart maximal 30 s);
- cherche les autres acteurs réseau dans une fenêtre de ±60 s autour de l’épisode sélectionné;
- privilégie, pour identifier une destination, la question DNS observée, puis le SNI TLS, puis l’IP:port;
- fusionne les répétitions techniques d’une même signature sur 5 s;
- mesure sur les dernières 24 h combien d’épisodes du déclencheur sont suivis de la même signature dans les 60 s;
- compte aussi les occurrences de cette signature qui se produisent hors de ces fenêtres;
- affiche le délai de l’occurrence actuelle et le délai médian des répétitions après-déclencheur;
- conserve explicitement la distinction entre **proximité/répétition** et **causalité**.

La mesure utilise `first_observed_ms` / `last_packet_ms` quand ils existent afin qu’une vieille connexion simplement fermée près du déclencheur ne soit pas présentée comme une nouvelle connexion. Les événements techniques d’un même `flow_correlation_id` sont dédupliqués avant les comptes.

## Export

Le résultat courant peut être exporté sous `journal-motif-temporel.json`, schéma `journal-temporal-pattern/1`. L’export contient les paramètres de fenêtre, la période réellement couverte, les compteurs bruts et l’indicateur `baseline_truncated` si le plafond de 100 000 lignes réseau a été atteint. Dans ce cas, les compteurs sont à traiter comme des minimums de la période demandée.

## Limites

- Une corrélation temporelle répétée ne démontre pas, à elle seule, que l’acteur A déclenche l’acteur B.
- Les acteurs reposent sur l’attribution UID déjà journalisée; un UID partagé ou inconnu conserve ses limites.
- Une destination DNS/SNI/IP est une métadonnée réseau, pas le contenu du message.
- Le calcul est local et lancé explicitement depuis le détail; il ne tourne pas en continu en arrière-plan.
- Le calcul demande au plus les 100 000 lignes réseau les plus récentes de la période et signale toute troncature.

## Validation

Les mathématiques de regroupement et de fenêtre disposent de tests hôte Java 8. La syntaxe JavaScript du lecteur est vérifiée séparément. Une compilation Android complète et un essai sur le téléphone restent nécessaires avant installation comme mise à jour.
