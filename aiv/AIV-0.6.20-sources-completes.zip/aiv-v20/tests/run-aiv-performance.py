#!/usr/bin/env python3
"""Actual production writer/verifier/stats with SQLite JDBC + Android JSON semantics.
Requires separately supplied test dependencies; downloads nothing; does not test Android lifecycle.
"""
from pathlib import Path
import argparse,subprocess,os
p=argparse.ArgumentParser();p.add_argument('--deps',type=Path,required=True);a=p.parse_args()
r=Path(__file__).resolve().parents[1];out=r/'build/host-aiv-performance';out.mkdir(parents=True,exist_ok=True)
names=['sqlite-jdbc.jar','android-json.jar','slf4j-api.jar','slf4j-nop.jar'];cp=os.pathsep.join(str(a.deps/n) for n in names)
src=r/'app/src/main/java/fr/erick/journallocal';production=['ChainStore','CoherenceRules','WorkBudget','AivQueries','AivStore','MainEngine','AivStats','AivVerifier']
files=list((r/'tests/aiv-host').rglob('*.java'))+[src/(n+'.java') for n in production]+[r/'tests/AivPerformanceTest.java']
subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','--release','8','-cp',cp,'-d',str(out),*map(str,files)],check=True)
subprocess.run(['java','-cp',str(out)+os.pathsep+cp,'fr.erick.journallocal.AivPerformanceTest',str(r/'app/src/main/assets')],check=True)
