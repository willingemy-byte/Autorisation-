const assert=require('node:assert/strict'),M=require('../tools/penalty-model');
const app=(name='test.a',n=70,uid=10001)=>({package_name:name,uid,profile_id:Math.floor(uid/100000),uid_packages:[name],version_code:1,permissions:Array.from({length:n},(_,i)=>({name:'p.'+i}))});
const finding=(id,levels,extra={})=>({id,levels,hidden:true,version_code:1,source:'Capture test',reason:'Capacité documentée pour ce test',observed_at:'2026-09-23',...extra});
const visibility=count=>({count,kind:'permissions',source:'Capture même version',same_version:true,version_code:1});
const base={apps:[app()],references:{'test.a':{penalty_evidence:{visibility:{principal:visibility(10)},findings:[finding('a',[2]),finding('b',[2]),finding('c',[2,3]),finding('d',[2,3]),finding('e',[4],{share_count:200})]}}}};
let r=M.evaluate(base),a=r.apps[0];
assert.equal(a.H,60);assert.equal(a.multiplier,'9600');assert.equal(a.points,'576000');assert.equal(a.color,'critical');assert.deepEqual(a.factors,['8','6','200','1']);assert.equal(r.summary.base,'60');assert.equal(r.summary.multiplier,'9600.00');
let x=structuredClone(base);x.references['test.a'].penalty_evidence.findings.push(finding('f',[4],{share_count:500}));a=M.evaluate(x).apps[0];assert.equal(a.multiplier,'33600');assert.equal(a.points,'2016000');
x=structuredClone(base);x.references['test.a'].penalty_evidence.findings=[];a=M.evaluate(x).apps[0];assert.equal(a.multiplier,'1');assert.equal(a.points,'60');assert.equal(a.color,'unknown','Partial coverage is not green');
// Group identity remains exact, and zero/unknown records do not dilute the multiplier.
x=structuredClone(base);x.apps.push(app('test.b'));x.references['test.b']={penalty_evidence:{visibility:{principal:visibility(10)},findings:[]}};r=M.evaluate(x);assert.equal(r.summary.base,'120');assert.equal(r.summary.base_mean,'60.00');assert.equal(r.summary.sum,'576060');assert.equal(r.summary.multiplier,'4800.50');assert.equal(BigInt(r.summary.multiplier_numerator),BigInt(r.summary.sum));assert.equal(BigInt(r.summary.multiplier_denominator),BigInt(r.summary.base));
x.apps.push(app('clean',0),app('unknown'));x.references.clean={penalty_evidence:{visibility:{principal:visibility(0)}}};assert.equal(M.evaluate(x).summary.multiplier,'4800.50');assert.equal(M.evaluate(x).summary.base_mean,'60.00');
// Same-profile inventory count, not other profiles; duplicate packages do not inflate.
x=structuredClone(base);x.references['test.a'].penalty_evidence.findings=[finding('sharing',[4])];x.apps.push(app('second'),app('other.profile',70,110001),app('second'));a=M.evaluate(x).apps.find(a=>a.package_name==='test.a');assert.equal(a.multiplier,'2');
// No implicit sharing claim from a permission name, visibility ratio or absent observation.
x=structuredClone(base);x.references['test.a'].penalty_evidence.findings=[finding('unknown-hidden',[4],{hidden:false})];a=M.evaluate(x).apps[0];assert.equal(a.multiplier,'1');assert.match(a.excluded[0].exclusion,/non établi/);
x.references['test.a'].penalty_evidence.findings=[finding('old',[5],{active:true,outside_permissions:true})];a=M.evaluate(x).apps[0];assert.equal(a.multiplier,'1');assert.equal(a.counts[5],1);
// Critical boundaries use the multiplier at both scopes.
for(const [factor,color] of [[1,'unknown'],[2,'yellow'],[4,'orange'],[6,'red'],[8,'critical']]){x=structuredClone(base);x.references['test.a'].penalty_evidence.findings=[finding('factor',[4],{share_count:factor})];r=M.evaluate(x);assert.equal(r.apps[0].color,color);assert.equal(r.summary.color,color);}
// Source validation, inactive observations, stale versions, and contradictory sharing scopes.
assert.throws(()=>M.validateEvidence({findings:[finding('bad',[4],{share_count:-1})]}));
x=structuredClone(base);x.references['test.a'].penalty_evidence.findings=[finding('inactive',[4],{active:false})];assert.equal(M.evaluate(x).apps[0].multiplier,'1');
x.references['test.a'].penalty_evidence.findings=[finding('a',[4],{permission:'p.1',share_count:200}),finding('b',[4],{permission:'p.1',share_count:500})];assert.equal(M.evaluate(x).apps[0].multiplier,'1');
x.references['test.a'].penalty_evidence.visibility.principal.version_code=0;assert.equal(M.evaluate(x).summary.base,null);
// BigInt prevents overflow even after many independent sharing capabilities.
x=structuredClone(base);x.references['test.a'].penalty_evidence.findings=Array.from({length:100},(_,i)=>finding('share'+i,[4],{share_count:100000}));a=M.evaluate(x,{multipliers:{level4:{combination:'product'}}}).apps[0];assert.equal(a.multiplier,'1'+'0'.repeat(500));assert.equal(a.points,'6'+'0'.repeat(501));assert.equal(a.color,'critical');
const migrated=M.validatePolicy({schema:'aiv-penalty-policy/1',multipliers:{level4:4}});assert.equal(migrated.schema,'aiv-penalty-policy/3');assert.equal(migrated.multipliers.level4.mode,'installed_app_count');
console.log('PASS v2: 60 × 9600, stacked sharing, group identity, no dilution, boundaries, profiles, provenance, migration, huge exact integers');
