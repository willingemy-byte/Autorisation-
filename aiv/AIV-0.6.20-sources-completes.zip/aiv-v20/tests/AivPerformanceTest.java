package fr.erick.journallocal;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import org.json.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CancellationException;

/** Real production algorithms and SQL, host SQLite facade; no Android device claim. */
public final class AivPerformanceTest {
 static int checks;static SQLiteDatabase db;static Context context;
 static void check(boolean value,String label){checks++;if(!value)throw new AssertionError(label);}
 static long n(String sql){return AivStore.number(db,sql);}
 static WorkBudget batch(int rows){return new WorkBudget(()->0L,()->false,rows,40);}
 static void event(int index){
  long id=index*2,ts=1000+index;JSONObject e=EventStore.object("timestamp_ms",ts,"app","test.app","action","Connexion","destination","192.0.2.1","transport","TCP","category","trafic","details",EventStore.object("uid",12345,"packages",new JSONArray().put("test.app"),"remote_ip","192.0.2.1"));
  db.execSQL("INSERT INTO events(id,timestamp_ms,app,action,destination,transport,category,payload,search_text) VALUES(?,?,?,?,?,?,?,?,?)",new Object[]{id,ts,"test.app","Connexion","192.0.2.1","TCP","trafic",e.toString(),e.toString()});
 }
 static void finish(AivVerifier v,int rows){int loops=0;while(!v.advance(db,batch(rows))){check(++loops<1000,"bounded verifier makes progress");}check(v.valid(),"captured chain valid");}
 public static void main(String[] args)throws Exception{
  long[] time={0};WorkBudget timed=new WorkBudget(()->time[0],()->false,16,40);check(timed.next(),"first item admitted");time[0]=40;check(!timed.next(),"time slice expires");WorkBudget capped=batch(16);for(int i=0;i<16;i++)check(capped.next(),"item admitted");check(!capped.next(),"item cap");check(WorkBudget.pauseAfter(0)==1000,"minimum pause");check(WorkBudget.pauseAfter(500)==4500,"measured work pause");check(WorkBudget.pauseAfter(Long.MAX_VALUE)==Long.MAX_VALUE,"pause overflow saturates");
  try{new WorkBudget(()->0L,()->true,16,40).next();throw new AssertionError("cancellation ignored");}catch(CancellationException expected){checks++;}
  Path dir=Files.createTempDirectory("aiv-performance-");context=new Context(args[0]);
  try(SQLiteDatabase journal=new SQLiteDatabase(dir.resolve("journal.sqlite").toString());SQLiteDatabase audit=new SQLiteDatabase(dir.resolve("audit.sqlite").toString())){
   db=journal;EventStore.db=db;PermissionAudit.db=audit;
   db.execSQL("PRAGMA journal_mode=WAL");db.execSQL("PRAGMA user_version=1");
   db.execSQL("CREATE TABLE events(id INTEGER PRIMARY KEY AUTOINCREMENT,timestamp_ms INTEGER NOT NULL,app TEXT NOT NULL,action TEXT NOT NULL,destination TEXT NOT NULL,transport TEXT NOT NULL,category TEXT NOT NULL,payload TEXT NOT NULL,search_text TEXT NOT NULL)");db.execSQL("CREATE INDEX events_time ON events(timestamp_ms,id)");
   for(int i=1;i<=70;i++)event(i);
   // Install a real 0.6 schema first, then run the current production migration twice.
   db.execSQL("ALTER TABLE events ADD COLUMN hash_prev TEXT");db.execSQL("ALTER TABLE events ADD COLUMN hash_self TEXT");
   for(String line:Files.readAllLines(Paths.get(args[0],"aiv-schema.sql"),StandardCharsets.UTF_8))if(!line.trim().isEmpty()&&!line.contains("aiv_app_stats")&&!line.contains("aiv_stats_state"))db.execSQL(line);
   db.execSQL("INSERT INTO aiv_state VALUES(1,2,0,140,0,?)",new Object[]{ChainStore.GENESIS});
   AivStore.install(context,db);AivStore.install(context,db);
   check(n("PRAGMA user_version")==1,"database identity preserved");check(n("SELECT schema_version FROM aiv_state")==3,"additive migration");check(n("SELECT COUNT(*) FROM events")==70,"source retained");
   audit.execSQL("CREATE TABLE scans(id INTEGER PRIMARY KEY,ended_ms INTEGER)");audit.execSQL("CREATE TABLE apps(scan_id INTEGER,package_name TEXT,payload TEXT,PRIMARY KEY(scan_id,package_name))");audit.execSQL("INSERT INTO scans VALUES(1,900)");
   JSONObject inventory=EventStore.object("uid",12345,"system_app",false,"version_code",1,"permissions",new JSONArray().put(EventStore.object("name","android.permission.INTERNET","description",new String(new char[8192]).replace('\0','x'))));
   audit.execSQL("INSERT INTO apps VALUES(1,'test.app',?)",new Object[]{inventory.toString()});
   finish(new AivVerifier(db),3);
   MainEngine engine=new MainEngine(context);int[] calls={0};
   try{engine.drain(16,new WorkBudget(()->0L,()->++calls[0]>5,16,40));throw new AssertionError("writer cancellation ignored");}catch(CancellationException expected){checks++;}
   check(n("SELECT COUNT(*) FROM decisions")==0,"cancelled decisions rolled back");check(n("SELECT COUNT(*) FROM journal_chain")==0,"cancelled chain rolled back");check(n("SELECT COUNT(*) FROM events WHERE hash_self IS NOT NULL")==0,"source seal rollback");check(n("SELECT checkpoint FROM aiv_state")==0,"writer checkpoint rollback");
   audit.queries=0;check(engine.drain(999,batch(999))==16,"writer caps requested large batch");check(audit.queries==2,"inventory loaded once per batch and package");check(n("SELECT COUNT(*) FROM journal_chain")==32,"one event and decision per source");
   JSONObject early=AivStore.summary(context);check(!early.getBoolean("stats_complete"),"partial stats signalled");check(early.isNull("pending"),"ID gaps are not pending counts");
   while(engine.drain(999,batch(999))>0){}check(n("SELECT COUNT(*) FROM decisions")==70,"all historic sources evaluated");check(n("SELECT checkpoint FROM aiv_state")==140,"ID gaps resumed correctly");check(AivStore.verify(context).getBoolean("valid"),"original full verifier accepts current writer");
   String head;try(Cursor c=db.rawQuery("SELECT chain_head FROM aiv_state",null)){c.moveToFirst();head=c.getString(0);}AivStore.install(context,db);try(Cursor c=db.rawQuery("SELECT chain_head FROM aiv_state",null)){c.moveToFirst();check(head.equals(c.getString(0)),"migration preserves sealed chain");}
   calls[0]=0;try{AivStats.advance(db,new WorkBudget(()->0L,()->++calls[0]>4,64,40));throw new AssertionError("stats cancellation ignored");}catch(CancellationException expected){checks++;}
   check(n("SELECT checkpoint FROM aiv_stats_state")==0,"stats checkpoint rolled back");check(n("SELECT COUNT(*) FROM aiv_app_stats")==0,"stats counts rolled back");
   int loops=0;while(AivStats.advance(db,batch(3))>0)check(++loops<30,"stats makes bounded progress");
   long expected=n("SELECT COUNT(*) FROM decisions WHERE decision!='ALLOW'");check(n("SELECT evaluated FROM aiv_stats_state")==70,"stats evaluated exact");check(n("SELECT findings FROM aiv_stats_state")==expected,"stats findings exact");check(AivStats.advance(db,batch(64))==0,"stats retry idempotent");check(n("SELECT evaluated FROM aiv_stats_state")==70,"stats retry no double counting");
   JSONObject summary=AivStore.summary(context);check(summary.getBoolean("stats_complete"),"complete stats signalled");check(summary.getLong("findings")==expected,"summary matches reference aggregation");
   JSONObject page=AivStore.page(context,"",0);JSONArray rows=page.getJSONArray("rows");check(rows.length()==50,"first page limit");check(!rows.getJSONObject(0).has("reason"),"large evidence omitted from list");check(AivStore.page(context,"",page.getLong("next")).getJSONArray("rows").length()==20,"second page no loss");check(AivStore.detail(context,2).getJSONObject("decision").getString("reason").contains("evidence"),"detail retains evidence");
   AivVerifier prefix=new AivVerifier(db);check(!prefix.advance(db,batch(3)),"verification yields before end");event(71);check(engine.drain(16,batch(16))==1,"concurrent append allowed between verification pages");finish(prefix,7);check(prefix.total()==140,"verifier remains on captured prefix");finish(new AivVerifier(db),7);check(!AivStore.summary(context).getBoolean("stats_complete"),"new decision makes stats partial");
   db.execSQL("DROP TRIGGER aiv_decisions_update");db.execSQL("UPDATE decisions SET reason='tampered' WHERE id=1");AivVerifier broken=new AivVerifier(db);while(!broken.advance(db,batch(5))){}check(!broken.valid(),"tampered projection rejected");check(AivStore.verification.startsWith("BROKEN"),"broken status explicit");event(72);try{engine.drain(16,batch(16));throw new AssertionError("broken chain writer accepted");}catch(IllegalStateException expectedFailure){checks++;}
   check(n("SELECT checkpoint FROM aiv_state")==142,"broken chain suspends checkpoint");
  }
  System.out.println("PASS "+checks+" assertions: production writer, verifier, stats, migration, cancellation rollback, pagination, inventory cache and concurrent append; host SQLite only.");
 }
}
