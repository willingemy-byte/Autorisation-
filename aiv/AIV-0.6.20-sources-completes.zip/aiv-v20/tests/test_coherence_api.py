import importlib.util
import sys
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
P=ROOT/'api/coherence.py'
spec=importlib.util.spec_from_file_location('aiv_api_test',P)
api=importlib.util.module_from_spec(spec);sys.modules[spec.name]=api;spec.loader.exec_module(api)
class ApiTests(unittest.TestCase):
    def test_schema_and_weather_penalty(self):
        out=api.evaluate_payload({'apps':[{'package':'com.accuweather.demo','permissions':['android.permission.CALL_PHONE']}]})
        self.assertEqual('aiv-coherence-verdicts/2',out['schema']);self.assertLess(out['apps'][0]['score_local'],65)
    def test_unknown_stays_unpenalized(self):
        out=api.evaluate_payload({'apps':[{'package':'org.example.unknown','permissions':['CALL_PHONE']}]})
        self.assertEqual(100,out['apps'][0]['score_local']);self.assertEqual([],out['apps'][0]['incoherences_local'])
    def test_rejects_excessive_apps(self):
        with self.assertRaises(ValueError): api.evaluate_payload({'apps':[{}]*(api.MAX_APPS+1)})
if __name__=='__main__': unittest.main()
