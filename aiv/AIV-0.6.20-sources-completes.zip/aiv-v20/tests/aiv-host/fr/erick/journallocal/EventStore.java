package fr.erick.journallocal;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import org.json.*;
public final class EventStore {public static SQLiteDatabase db;private static final EventStore INSTANCE=new EventStore();public static EventStore get(Context context){return INSTANCE;}public SQLiteDatabase getWritableDatabase(){return db;}public SQLiteDatabase getReadableDatabase(){return db;}public static JSONObject object(Object... values){try{JSONObject o=new JSONObject();for(int i=0;i<values.length;i+=2)o.put((String)values[i],values[i+1]);return o;}catch(JSONException e){throw new IllegalStateException(e);}}}
