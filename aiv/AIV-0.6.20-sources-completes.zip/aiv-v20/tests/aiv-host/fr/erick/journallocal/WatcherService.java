package fr.erick.journallocal;
/** No Android service lifecycle is exercised by these host-only persistence tests. */
public final class WatcherService {public static boolean running,analysisActive;public static String operation="Analyse AIV en pause";}
