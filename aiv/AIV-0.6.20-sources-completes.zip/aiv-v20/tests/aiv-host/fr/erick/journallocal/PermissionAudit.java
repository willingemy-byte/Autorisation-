package fr.erick.journallocal;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
public final class PermissionAudit {public static SQLiteDatabase db;private static final PermissionAudit INSTANCE=new PermissionAudit();public static PermissionAudit get(Context c){return INSTANCE;}public SQLiteDatabase getReadableDatabase(){return db;}}
