package android.database.sqlite;
import android.content.ContentValues;
import android.database.Cursor;
import java.sql.*;
import java.util.*;
/** Real SQLite via JDBC; this is a test facade, never included in the Android application. */
public final class SQLiteDatabase implements AutoCloseable {
 public static final int CONFLICT_IGNORE=4;private final Connection connection;private boolean transaction,successful;public int queries;
 public SQLiteDatabase(String path)throws SQLException{connection=DriverManager.getConnection("jdbc:sqlite:"+path);execSQL("PRAGMA foreign_keys=ON");}
 private PreparedStatement prepare(String sql,Object[] args)throws SQLException{PreparedStatement p=connection.prepareStatement(sql);if(args!=null)for(int i=0;i<args.length;i++)p.setObject(i+1,args[i]);return p;}
 public Cursor rawQuery(String sql,String[] args){queries++;try(PreparedStatement p=prepare(sql,args);ResultSet r=p.executeQuery()){return new Cursor(r);}catch(SQLException e){throw new IllegalStateException(sql,e);}}
 public void execSQL(String sql){execSQL(sql,null);}public void execSQL(String sql,Object[] args){try(PreparedStatement p=prepare(sql,args)){p.execute();}catch(SQLException e){throw new IllegalStateException(sql,e);}}
 public void beginTransaction(){if(transaction)throw new IllegalStateException("Nested host transaction");try{connection.setAutoCommit(false);transaction=true;successful=false;}catch(SQLException e){throw new IllegalStateException(e);}}
 public void setTransactionSuccessful(){if(!transaction)throw new IllegalStateException();successful=true;}public boolean inTransaction(){return transaction;}
 public void endTransaction(){try{if(successful)connection.commit();else connection.rollback();connection.setAutoCommit(true);}catch(SQLException e){throw new IllegalStateException(e);}finally{transaction=false;successful=false;}}
 private long insert(String table,ContentValues v,boolean ignore){StringBuilder columns=new StringBuilder(),marks=new StringBuilder();for(String k:v.keySet()){if(columns.length()>0){columns.append(',');marks.append(',');}columns.append(k);marks.append('?');}execSQL("INSERT "+(ignore?"OR IGNORE ":"")+"INTO "+table+"("+columns+") VALUES("+marks+")",v.values().toArray());try(Cursor c=rawQuery("SELECT last_insert_rowid()",null)){c.moveToFirst();return c.getLong(0);}}
 public long insertOrThrow(String table,String nullColumn,ContentValues v){return insert(table,v,false);}public long insertWithOnConflict(String table,String nullColumn,ContentValues v,int conflict){if(conflict!=CONFLICT_IGNORE)throw new IllegalArgumentException();return insert(table,v,true);}public void close()throws SQLException{connection.close();}
}
