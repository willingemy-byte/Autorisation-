package android.database;
import java.sql.*;
import java.util.*;
/** Host facade materializes small query results. Does not simulate Android CursorWindow. */
public final class Cursor implements AutoCloseable {
 public static final int FIELD_TYPE_INTEGER=1,FIELD_TYPE_FLOAT=2,FIELD_TYPE_STRING=3;
 private final List<Object[]> rows=new ArrayList<>();private final String[] names;private int at=-1;
 public Cursor(ResultSet r)throws SQLException{ResultSetMetaData m=r.getMetaData();names=new String[m.getColumnCount()];for(int i=0;i<names.length;i++)names[i]=m.getColumnLabel(i+1);while(r.next()){Object[] row=new Object[names.length];for(int i=0;i<row.length;i++)row[i]=r.getObject(i+1);rows.add(row);}}
 public boolean moveToNext(){return ++at<rows.size();}public boolean moveToFirst(){at=0;return !rows.isEmpty();}public int getColumnCount(){return names.length;}public String getColumnName(int i){return names[i];}
 public boolean isNull(int i){return rows.get(at)[i]==null;}public String getString(int i){Object v=rows.get(at)[i];return v==null?null:String.valueOf(v);}public long getLong(int i){return Long.parseLong(getString(i));}public int getInt(int i){return (int)getLong(i);}public double getDouble(int i){return Double.parseDouble(getString(i));}
 public int getType(int i){Object v=rows.get(at)[i];return v instanceof Float||v instanceof Double?FIELD_TYPE_FLOAT:v instanceof Number?FIELD_TYPE_INTEGER:FIELD_TYPE_STRING;}public void close(){}
}
