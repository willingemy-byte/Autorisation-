package android.content;
import java.util.LinkedHashMap;
public class ContentValues extends LinkedHashMap<String,Object>{
 public void put(String k,String v){super.put(k,v);}public void put(String k,Long v){super.put(k,v);}public void put(String k,Integer v){super.put(k,v);}
}
