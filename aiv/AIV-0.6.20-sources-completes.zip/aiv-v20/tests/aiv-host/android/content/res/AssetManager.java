package android.content.res;
import java.io.*;
public class AssetManager {private final String root;public AssetManager(String root){this.root=root;}public InputStream open(String name)throws IOException{return new FileInputStream(new File(root,name));}}
