package android.content;
import android.content.res.AssetManager;
public class Context {private final AssetManager assets;public Context(String path){assets=new AssetManager(path);}public Context getApplicationContext(){return this;}public AssetManager getAssets(){return assets;}}
