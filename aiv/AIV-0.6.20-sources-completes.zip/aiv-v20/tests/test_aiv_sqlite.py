#!/usr/bin/env python3
"""Real host SQLite, not Android SQLiteDatabase. Checks migration and interruption boundaries."""
import pathlib,sqlite3,tempfile,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
DDL=(ROOT/'app/src/main/assets/aiv-schema.sql').read_text()
BASE='CREATE TABLE events(id INTEGER PRIMARY KEY AUTOINCREMENT,timestamp_ms INTEGER NOT NULL,app TEXT NOT NULL,action TEXT NOT NULL,destination TEXT NOT NULL,transport TEXT NOT NULL,category TEXT NOT NULL,payload TEXT NOT NULL,search_text TEXT NOT NULL)'
class Transactions(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.path=pathlib.Path(self.tmp.name)/'journal.sqlite';self.db=sqlite3.connect(self.path);self.db.execute('PRAGMA journal_mode=WAL');self.db.execute('PRAGMA user_version=1');self.db.execute(BASE)
  self.db.execute("INSERT INTO events VALUES(1,1,'app','a','ip','tcp','trafic','{}','{}')");self.db.commit()
  self.migrate()
 def tearDown(self):self.db.close();self.tmp.cleanup()
 def migrate(self):
  with self.db:
   cols={r[1] for r in self.db.execute('PRAGMA table_info(events)')}
   for col in ['hash_prev','hash_self']:
    if col not in cols:self.db.execute('ALTER TABLE events ADD COLUMN '+col+' TEXT')
   # Each asset line is one entire statement, including trigger body.
   for line in DDL.splitlines():
    if line.strip():self.db.execute(line)
   self.db.execute("INSERT OR IGNORE INTO aiv_state VALUES(1,2,0,1,0,?)",('0'*64,))
 def append(self,fail=False):
  with self.db:
   self.db.execute('UPDATE events SET hash_prev=?,hash_self=? WHERE id=1',('0'*64,'1'*64))
   self.db.execute("INSERT INTO decisions(id,event_id,rule_name,decision,reason,timestamp_ms,hash_prev,hash_self) VALUES(1,1,'R6','DENIED','test',1,?,?)",('1'*64,'2'*64))
   self.db.execute("INSERT INTO journal_chain VALUES(1,1,?,?,NULL,1,'EVENT',NULL,'payload')",('0'*64,'1'*64))
   self.db.execute("INSERT INTO journal_chain VALUES(2,1,?,?,NULL,1,'DECISION',1,'decision')",('1'*64,'2'*64))
   self.db.execute('UPDATE aiv_state SET checkpoint=1,chain_count=2,chain_head=?',('2'*64,))
   if fail:raise RuntimeError('interruption')
 def test_repeat_migration(self):
  self.migrate();self.assertEqual(self.db.execute('PRAGMA user_version').fetchone()[0],1);self.assertEqual(self.db.execute('SELECT payload FROM events').fetchone()[0],'{}')
 def test_atomic_rollback_and_retry(self):
  with self.assertRaises(RuntimeError):self.append(True)
  self.assertEqual(self.db.execute('SELECT COUNT(*) FROM decisions').fetchone()[0],0);self.assertIsNone(self.db.execute('SELECT hash_self FROM events').fetchone()[0]);self.assertEqual(self.db.execute('SELECT checkpoint FROM aiv_state').fetchone()[0],0)
  self.append();self.assertEqual(self.db.execute('SELECT COUNT(*) FROM journal_chain').fetchone()[0],2)
 def test_source_protected_before_seal(self):
  with self.assertRaises(sqlite3.IntegrityError):self.db.execute("UPDATE events SET payload='changed'")
  with self.assertRaises(sqlite3.IntegrityError):self.db.execute('DELETE FROM events')
 def test_append_only_after_seal(self):
  self.append()
  for table in ['events','decisions','journal_chain']:
   with self.assertRaises(sqlite3.IntegrityError):self.db.execute('DELETE FROM '+table)
   with self.assertRaises(sqlite3.IntegrityError):self.db.execute('UPDATE '+table+' SET id=id')
 def test_rule_versions(self):
  self.db.execute("INSERT INTO main_rules(name,condition,decision,priority,enabled,version,created_ms) VALUES('R1','{}','WATCH',1,1,1,1)")
  with self.assertRaises(sqlite3.IntegrityError):self.db.execute('UPDATE main_rules SET enabled=0')
  self.db.execute("INSERT INTO main_rules(name,condition,decision,priority,enabled,version,created_ms) VALUES('R1','{}','WATCH',1,0,2,2)");self.assertEqual(self.db.execute('SELECT MAX(version) FROM main_rules').fetchone()[0],2)
 def test_reference_rollback(self):
  self.db.execute("INSERT INTO sync_state(source,status) VALUES('bayton','OFFLINE')");self.db.commit()
  with self.assertRaises(RuntimeError):
   with self.db:
    self.db.execute("INSERT INTO reference_apps VALUES('test.app','[]','[]','bayton',1,'{}')");self.db.execute("UPDATE sync_state SET cursor='next',status='DONE'");raise RuntimeError()
  self.assertEqual(self.db.execute('SELECT COUNT(*) FROM reference_apps').fetchone()[0],0);self.assertIsNone(self.db.execute('SELECT cursor FROM sync_state').fetchone()[0])
 def test_reopen_after_interruption(self):
  with self.assertRaises(RuntimeError):self.append(True)
  self.db.close();self.db=sqlite3.connect(self.path);self.assertEqual(self.db.execute('PRAGMA integrity_check').fetchone()[0],'ok');self.append()
if __name__=='__main__':unittest.main()
