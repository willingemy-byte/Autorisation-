"""Verify the deliverable's signing identity, permissions, JNI and native ABI packaging."""
import argparse,hashlib,json,re,struct,subprocess,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def methods(path):
    data=path.read_bytes();at=8
    def take(fmt):
        nonlocal at
        values=struct.unpack_from('>'+fmt,data,at);at+=struct.calcsize('>'+fmt);return values[0] if len(values)==1 else values
    count=take('H');pool={};index=1
    while index<count:
        tag=take('B')
        if tag==1:
            length=take('H');pool[index]=data[at:at+length].decode('utf-8',errors='replace');at+=length
        elif tag in (3,4):at+=4
        elif tag in (5,6):at+=8;index+=1
        elif tag in (7,8,16,19,20):at+=2
        elif tag in (9,10,11,12,17,18):at+=4
        elif tag==15:at+=3
        else:raise AssertionError('Unexpected class tag '+str(tag))
        index+=1
    at+=6;interfaces=take('H');at+=2*interfaces
    def attributes():
        nonlocal at
        for _ in range(take('H')):
            take('H');length=take('I');at+=length
    for _ in range(take('H')):at+=6;attributes()
    result={}
    for _ in range(take('H')):
        access,name,descriptor=take('HHH');result[pool[name]]=pool[descriptor];attributes()
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument('--build-tools',required=True,type=Path);p.add_argument('--old-apk',required=True,type=Path);a=p.parse_args()
    apk=ROOT/'build/journal-local.apk'
    def output(*args):return subprocess.check_output([str(x) for x in args],text=True)
    def certificate(path):
        text=output('java','-jar',a.build_tools/'lib/apksigner.jar','verify','--print-certs',path)
        return re.search(r'Signer #1 certificate SHA-256 digest: ([0-9a-f]+)',text).group(1)
    signer=certificate(apk);assert signer==certificate(a.old_apk),'Update must retain original signer'
    badging=output(a.build_tools/'aapt2','dump','badging',apk)
    assert "versionCode='7'" in badging and "versionName='0.6.1-aiv'" in badging and "package: name='fr.erick.journallocal'" in badging
    expected={'android.permission.QUERY_ALL_PACKAGES','android.permission.INTERNET','android.permission.ACCESS_NETWORK_STATE','android.permission.FOREGROUND_SERVICE','android.permission.FOREGROUND_SERVICE_SPECIAL_USE','android.permission.POST_NOTIFICATIONS','android.permission.BLUETOOTH','android.permission.BLUETOOTH_CONNECT'}
    permissions=set(re.findall(r"uses-permission: name='([^']+)'",badging));assert permissions==expected,(permissions,expected)
    manifest=output(a.build_tools/'aapt2','dump','xmltree',apk,'--file','AndroidManifest.xml')
    assert 'android.permission.BIND_VPN_SERVICE' in manifest and 'extractNativeLibs' in manifest
    descriptor=methods(ROOT/'build/classes/fr/erick/journallocal/NetworkCaptureService.class')
    cpp=(ROOT/'app/src/main/cpp/jni.c').read_text()
    contracts=re.findall(r'GetMethodID\(env,cls,"([^"]+)","([^"]+)"\)',cpp)
    assert len(contracts)==7
    for name,signature in contracts:assert descriptor.get(name)==signature,(name,descriptor.get(name),signature)
    assert descriptor['runNative']=='(I)I'
    old_badging=output(a.build_tools/'aapt2','dump','badging',a.old_apk)
    old_permissions=set(re.findall(r"uses-permission: name='([^']+)'",old_badging));assert permissions==old_permissions, 'AIV adds no Android permission over 0.5.0'
    with zipfile.ZipFile(apk) as z,zipfile.ZipFile(a.old_apk) as old:
        for asset in ['journal.html','licenses.txt','aiv-schema.sql']:assert z.read('assets/'+asset)==(ROOT/'app/src/main/assets'/asset).read_bytes()
        assert not any(n.endswith(('.p12','.jks','.keystore')) or n.rsplit('/',1)[-1]=='password.txt' for n in z.namelist()), 'Signing secrets must stay outside the APK'
        for abi in ['arm64-v8a','x86_64']:
            for library in ['libjournal_zdtun.so','libjournalrelay.so']:
                data=z.read('lib/'+abi+'/'+library);assert data[:6]==b'\x7fELF\x02\x01'
                if library=='libjournal_zdtun.so':assert data==old.read('lib/'+abi+'/'+library), 'Underlying relay source remains unchanged'
                assert data==(ROOT/'build/lib'/abi/library).read_bytes()
                phoff=struct.unpack_from('<Q',data,32)[0];size,count=struct.unpack_from('<HH',data,54)
                loads=0
                for i in range(count):
                    at=phoff+i*size
                    if struct.unpack_from('<I',data,at)[0]==1:
                        loads+=1;assert struct.unpack_from('<Q',data,at+48)[0]>=16384
                assert loads
                symbols=output('readelf','--dyn-syms','--wide',ROOT/'build/lib'/abi/library)
                assert not re.search(r'\bUND\s+system(?:@|\s|$)',symbols),'Unused vendor command helpers must not be linked'
                if library=='libjournalrelay.so':assert 'Java_fr_erick_journallocal_NetworkCaptureService_runNative' in symbols
    output(a.build_tools/'zipalign','-c','-P','16','4',apk)
    report={'version':'0.6.1-aiv','apk_bytes':apk.stat().st_size,'apk_sha256':hashlib.sha256(apk.read_bytes()).hexdigest(),'certificate_sha256':signer,'same_signer_as_reference_apk':True,'native_libraries_reused_from_pinned_0_6_apk':True,'native_sources_unchanged':True,'additional_android_permissions':sorted(permissions-old_permissions),'permissions':sorted(permissions),'jni_contracts_verified':True,'native_abis':['arm64-v8a','x86_64'],'elf_page_alignment':16384,'zip_alignment_verified':True,'aiv_schema_packaged':True,'signing_secrets_excluded':True,'android_vpn_runtime_tested':False,'samsung_uid_attribution_tested':False,'phone_connected':False}
    (ROOT/'verification-apk.json').write_text(json.dumps(report,indent=2)+'\n')
    print('PASS: update signer, permissions, version, JNI methods, native libraries, 16 KiB ELF alignment and embedded reader/licenses')

if __name__=='__main__':main()
