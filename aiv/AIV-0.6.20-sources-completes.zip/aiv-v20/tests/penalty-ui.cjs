// Integration with a simulated Android bridge; no physical device claims.
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {JSDOM,VirtualConsole}=require('jsdom');
const M=require('../tools/penalty-model');
const old=fs.readFileSync(path.join(__dirname,'native-reader.cjs'),'utf8');
let fixture=old.slice(old.indexOf('const records = []'),old.indexOf('const errors = []'));
fixture+=`
auditApps.forEach((a,i)=>{a.profile_id=0;a.uid_packages=[a.package_name];a.permissions=Array.from({length:i===0?92:4},(_,j)=>({name:'p.'+j,label:'Permission '+j,granted:true,description:'déclarée',protection:'Signature',defined_by:'android'}));a.count=a.permissions.length;});
const visibility={count:4,kind:'permissions',source:'capture test',same_version:true,version_code:5};
let config={schema:'aiv-penalty-settings/1',policy:{},references:{'test.app0':{visibility:{principal:visibility,toutes:{...visibility,count:14}},findings:[]}}};
let imported='';
bridge.penaltyData=()=>JSON.stringify({scan_id:1,apps:auditApps,references:Object.fromEntries(auditApps.map(a=>[a.package_name,{penalty_evidence:config.references[a.package_name]||{}}]))});
bridge.penaltyConfig=()=>JSON.stringify(config);
bridge.penaltySave=v=>{config=JSON.parse(v);return JSON.stringify({ok:true});};
bridge.penaltyImported=()=>{const r=imported;imported='';return r;};
window.testImport=v=>{imported=v;};
window.testConfig=()=>config;
window.testCommands=commands;
window.JournalAndroid=bridge;
`;
const errors=[],vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
const dom=new JSDOM(fs.readFileSync(path.join(__dirname,'../app/src/main/assets/journal.html'),'utf8'),{
 url:'https://journal.local.invalid/',runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,
 beforeParse(w){w.eval(fixture);w.TextEncoder=TextEncoder;w.TextDecoder=TextDecoder;w.HTMLElement.prototype.scrollIntoView=function(){};w.setInterval=f=>{w.testTick=f;return 1;};w.clearInterval=()=>{};}
});
(async()=>{try{
 const w=dom.window,d=w.document,id=x=>d.getElementById(x),button=(node,label)=>[...node.querySelectorAll('button')].find(b=>b.textContent===label);
 assert.deepEqual(errors,[]);assert.equal(id('jc-score-number').textContent,'88');assert.match(id('jc-home-sub').textContent,/29 non évaluées/);
 assert.equal(id('jc-group-rings').children.length,3);assert.equal(id('jc-score-ring').querySelector('.jp-multiplier').textContent,'×1');assert.equal(id('jc-score-ring').dataset.penaltyColor,'unknown');assert.ok([...id('jc-group-rings').querySelectorAll('.jp-group-number')].some(e=>e.textContent==='88'));assert.equal(id('jc-group-rings').querySelectorAll('.jp-multiplier').length,3);
 id('jc-home-app-list').firstElementChild.click();await new Promise(r=>setTimeout(r,90));assert.ok(id('jp-app-detail'));assert.match(id('jp-app-detail').textContent,/88 moins visibles × 1/);
 assert.equal(id('ja-play-count'),null,'Old duplicate reference editor hidden on V14');
 const fields=id('jp-app-detail').querySelectorAll('fieldset');fields[0].querySelector('input[type=number]').value='0';
 button(id('jp-app-detail'),'Enregistrer les observations et recalculer').click();await new Promise(r=>setTimeout(r,90));assert.match(id('jp-app-detail').textContent,/92 moins visibles/);assert.equal(w.testConfig().references['test.app0'].visibility.principal.count,0);
 button(id('jp-app-detail'),'Modifier le barème global').click();await new Promise(r=>setTimeout(r,90));assert.equal(id('jc-pane-penalty').hidden,false);
 const c=JSON.parse(id('jp-json').value);c.policy.visibility='toutes';id('jp-json').value=JSON.stringify(c);id('jp-validate').click();await new Promise(r=>setTimeout(r,90));assert.match(id('jp-preview').textContent,/78 points/);assert.equal(w.testConfig().policy.visibility,'principal','Preview does not mutate');
 id('jp-apply-json').click();await new Promise(r=>setTimeout(r,90));assert.equal(w.testConfig().policy.visibility,'toutes');
 const invalid=JSON.parse(id('jp-json').value);invalid.policy.colors.yellow_ratio=10;id('jp-json').value=JSON.stringify(invalid);id('jp-apply-json').click();await new Promise(r=>setTimeout(r,90));assert.match(id('jp-status').textContent,/Seuils/);assert.equal(w.testConfig().policy.colors.yellow_ratio,2,'Invalid config leaves previous intact');
 id('jp-reset').click();await new Promise(r=>setTimeout(r,90));assert.equal(w.testConfig().policy.visibility,'toutes','Reset is a preview until applied');
 id('jp-export').click();await new Promise(r=>setTimeout(r,90));assert.ok(w.testCommands.includes('export-penalty'));
 id('jp-import').click();await new Promise(r=>setTimeout(r,90));assert.ok(w.testCommands.includes('import-penalty'));
 const imported={schema:'aiv-penalty-settings/1',policy:M.defaults(),references:{'test.app0':{visibility:{principal:{count:4,kind:'permissions',source:'<img src=x onerror=alert(1)>',same_version:true,version_code:5}},findings:[]}}};
 w.testImport(JSON.stringify(imported));w.testTick();assert.match(id('jp-status').textContent,/Vérifie/);assert.equal(w.testConfig().policy.visibility,'toutes','Import requires apply');
 id('jp-apply-json').click();await new Promise(r=>setTimeout(r,90));assert.equal(w.testConfig().policy.visibility,'principal');assert.equal(d.querySelectorAll('#jp-preview img').length,0);
 d.querySelector('[data-jc-tab=home]').click();await new Promise(r=>setTimeout(r,90));assert.equal(id('jc-score-number').textContent,'88');
 id('jc-home-refresh').click();await new Promise(r=>setTimeout(r,90));assert.ok(w.testCommands.includes('audit-scan'));assert.ok(!w.testCommands.includes('coherence-refresh'));w.testTick();
 id('jc-mode-ti').click();await new Promise(r=>setTimeout(r,90));assert.match(id('jc-mode-banner').textContent,/données de ce téléphone/);id('jc-mode-user').click();await new Promise(r=>setTimeout(r,90));assert.equal(id('jc-score-number').textContent,'88');
 const f=(id,levels,extra={})=>({id,levels,hidden:true,version_code:5,source:'fixture',reason:'fixture',observed_at:'2026-09-23',...extra});
 const critical={schema:'aiv-penalty-settings/1',policy:M.defaults(),references:{'test.app0':{visibility:{principal:{count:32,kind:'permissions',source:'fixture',same_version:true,version_code:5}},findings:[f('a',[2]),f('b',[2]),f('c',[2,3]),f('d',[2,3]),f('e',[4],{share_count:200})]}}};
 d.querySelector('[data-jc-tab=menu]').click();id('jc-pane-penalty').parentElement.open=true;id('jp-json').value=JSON.stringify(critical);id('jp-apply-json').click();await new Promise(r=>setTimeout(r,90));d.querySelector('[data-jc-tab=home]').click();
 assert.equal(id('jc-score-number').textContent,'60');assert.equal(id('jc-score-ring').querySelector('.jp-multiplier').textContent,'×9 600');assert.equal(id('jc-score-ring').dataset.penaltyColor,'critical');
 assert.match(id('jc-home-app-list').firstElementChild.textContent,/60 pts de base/);assert.match(id('jc-home-app-list').firstElementChild.textContent,/×9 600/);
 id('jc-mode-ti').click();await new Promise(r=>setTimeout(r,90));assert.equal(id('jc-score-ring').dataset.penaltyColor,'critical');id('jc-mode-user').click();await new Promise(r=>setTimeout(r,90));assert.equal(id('jc-score-ring').dataset.penaltyColor,'critical');
 d.querySelector('[data-jc-tab=decisions]').click();const colorInput=id('aiv-score-colors').querySelector('[data-color-key=critical_ratio]');colorInput.value='10000';button(id('aiv-score-colors'),'Enregistrer les couleurs').click();await new Promise(r=>setTimeout(r,90));assert.equal(w.testConfig().policy.colors.critical_ratio,10000);d.querySelector('[data-jc-tab=home]').click();await new Promise(r=>setTimeout(r,90));assert.equal(id('jc-score-ring').dataset.penaltyColor,'red','Same threshold updates main and application colors without an APK');
 assert.equal(id('jc-home-app-list').firstElementChild.dataset.penaltyColor,'red');
 assert.deepEqual(errors,[]);console.log('PASS phone home, detail, reference editor, settings persistence, preview/import/apply/export, invalid JSON preservation, local refresh, TI compatibility, safe rendering');
}finally{dom.window.close();}

})().catch(e=>{console.error(e);process.exitCode=1});
