"""Exercise the actual home-group lookup against a large SQLite journal index."""
import re
import sqlite3
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'app/src/main/java/fr/erick/journallocal/EventStore.java'
SQL = re.search(r'COHERENCE_PACKAGES_SQL="([^"]+)"', SOURCE.read_text()).group(1)

class JournalGroupTests(unittest.TestCase):
    def test_complete_index_shared_uids_and_no_trace(self):
        with sqlite3.connect(':memory:') as db:
            db.executescript('''
                CREATE TABLE audit_appmap(package_name TEXT PRIMARY KEY, system_app INTEGER);
                CREATE TABLE event_audit(event_id INTEGER PRIMARY KEY, package_name TEXT, uid INTEGER);
                CREATE INDEX event_audit_package ON event_audit(package_name,event_id);
            ''')
            db.executemany('INSERT INTO audit_appmap VALUES (?,?)', [
                ('preinstalled.visible',1),('preinstalled.unseen',1),('android.shared',1),
                ('android.workprofile',1),('user.unseen',0),('user.visible',0)])
            db.executemany('INSERT INTO event_audit VALUES (?,?,?)',
                ((i,'preinstalled.visible',10234) for i in range(1,500001)))
            # Old indexes may contain a candidate package for reserved UIDs: never attribute it.
            db.executemany('INSERT INTO event_audit VALUES (?,?,?)', [
                (500001,'android.shared',1000),(500002,'android.workprofile',101000),
                (500003,None,10235),(500004,'user.visible',110236)])
            self.assertEqual([r[0] for r in db.execute(SQL)], ['preinstalled.visible','user.visible'])
            plan=' '.join(r[3] for r in db.execute('EXPLAIN QUERY PLAN '+SQL))
            self.assertIn('event_audit_package',plan)
            db.execute('INSERT INTO event_audit VALUES (500005,?,?)',('preinstalled.unseen',10456))
            self.assertIn('preinstalled.unseen',[r[0] for r in db.execute(SQL)])

if __name__=='__main__': unittest.main()
