import fr.erick.journallocal.CoherenceGroups;
public class CoherenceGroupsTest {
    static int checks;
    static void eq(Object actual,Object expected){checks++;if(actual==null?expected!=null:!actual.equals(expected))throw new AssertionError(actual+" != "+expected);}
    public static void main(String[] args){
        eq(CoherenceGroups.group(true,1000,91),"android");
        eq(CoherenceGroups.group(true,101000,1),"android");
        eq(CoherenceGroups.group(true,10234,2),"android");
        eq(CoherenceGroups.group(true,10234,1),"system");
        eq(CoherenceGroups.group(false,10235,1),"user");
        eq(CoherenceGroups.group(false,-1,0),"android");
        eq(CoherenceGroups.attributable("trafic",1000,1,"android"),false);
        eq(CoherenceGroups.attributable("trafic",101000,1,"android"),false);
        eq(CoherenceGroups.attributable("dns",10234,2,"com.example.shared"),false);
        eq(CoherenceGroups.attributable("dns",10234,1,"com.example.single"),true);
        eq(CoherenceGroups.attributable("trafic",110234,1,"com.example.profile"),true);
        eq(CoherenceGroups.attributable("inventaire",10234,1,"com.example.single"),false);
        eq(CoherenceGroups.score(0),0);eq(CoherenceGroups.score(100),100);
        eq(CoherenceGroups.score(null),null);eq(CoherenceGroups.score(Double.NaN),null);
        CoherenceGroups.Stats s=new CoherenceGroups.Stats();eq(s.mean(),null);
        s.add(0,3);s.add(100,0);s.add(100,0);s.add(null,0);
        eq(s.mean(),67);eq(s.total,4);eq(s.evaluated,3);eq(s.unknown,1);eq(s.below50,1);eq(s.below70,1);eq(s.minimum,0);eq(s.sum,200L);
        System.out.println("PASS "+checks+" grouping, unknown denominator and threshold checks");
    }
}
