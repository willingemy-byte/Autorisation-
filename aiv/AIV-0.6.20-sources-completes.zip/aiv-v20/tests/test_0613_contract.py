from pathlib import Path
import re, unittest
ROOT=Path(__file__).resolve().parents[1]
read=lambda rel:(ROOT/rel).read_text(encoding='utf-8')
class V0613Contract(unittest.TestCase):
  def test_version_identity(self):
    m=read('app/src/main/AndroidManifest.xml')
    self.assertIn('package="fr.erick.journallocal"',m);self.assertIn('android:versionName="0.6.13"',m);self.assertIn('android:versionCode="19"',m)
  def test_flow_reuses_local_vpn_correlation(self):
    e=read('app/src/main/java/fr/erick/journallocal/EventStore.java');n=read('app/src/main/java/fr/erick/journallocal/NetworkCaptureService.java')
    for token in ('flow_correlation_id','first_outbound_ms','first_inbound_ms','same_flow_return','Aucun contenu TLS'):
      self.assertIn(token,e)
    self.assertIn('flow_correlation_id',n);self.assertNotIn('X-AIV',n);self.assertIn('aucune duplication du trafic ni marqueur injecté',e)
  def test_shared_and_reserved_uid_are_not_unique(self):
    g=read('app/src/main/java/fr/erick/journallocal/CoherenceGroups.java')
    self.assertIn('uid%100000<10000',g);self.assertIn('candidates!=1',g);self.assertIn('return "android"',g)
  def test_score_denominator_and_thresholds(self):
    c=read('app/src/main/java/fr/erick/journallocal/CoherenceRefresh.java');h=read('tools/mvp-home.js')
    self.assertIn('"unknown".equals(category)?null:rawScore',c)
    for x in ('if(score>=85)','if(score>=70)','if(score>=50)'): self.assertIn(x,h)
    self.assertIn('points ÷ ${evaluated} évaluée(s)',read('tools/coherence-groups.js'))
  def test_flux_ui_and_app_event_drilldown(self):
    f=read('tools/flow-pane.html')+read('tools/flow-adapter.js');a=read('tools/audit-adapter.js');d=read('tools/diagnostic-adapter.js')
    for token in ('Premier sortant','Premier retour','DNS observé','SNI TLS observé','NON_ATTRIBUABLE'): self.assertIn(token,f)
    self.assertIn('Voir les flux réseau de cette application',a);self.assertIn('Voir le flux complet',d)
  def test_three_groups_are_exclusive(self):
    c=read('app/src/main/java/fr/erick/journallocal/CoherenceRefresh.java')
    self.assertIn('for(String id:new String[]{"android","system","user"})',c)
    self.assertIn('groups.get(group).add',c)
  def test_performance_guards(self):
    e=read('app/src/main/java/fr/erick/journallocal/EventStore.java')
    self.assertIn('scanLimit=Math.min(2500',e);self.assertIn('now-transparencyCacheAt<15000L',e)
if __name__=='__main__':unittest.main()
