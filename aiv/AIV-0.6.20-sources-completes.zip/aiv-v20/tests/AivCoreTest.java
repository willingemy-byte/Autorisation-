package fr.erick.journallocal;
import java.security.*;
import java.security.spec.*;
import java.util.*;
import java.nio.charset.StandardCharsets;
public final class AivCoreTest {
    static int count;
    static void ok(boolean v){count++;if(!v)throw new AssertionError("Test "+count);}
    static CoherenceRules.Rule rule(String name){CoherenceRules.Rule r=new CoherenceRules.Rule();r.name=name;r.enabled=true;r.version=1;r.decision="WATCH";return r;}
    static void match(CoherenceRules.Rule r,CoherenceRules.Facts f,CoherenceRules.Match m){ok(CoherenceRules.evaluate(r,f)==m);}
    public static void main(String[] args)throws Exception{
        String p=ChainStore.pack("EVENT","1","é",null,""),h=ChainStore.hash(ChainStore.GENESIS,p,123,1);
        ok(h.length()==64);ok(h.equals(ChainStore.hash(ChainStore.GENESIS,p,123,1)));
        ok(!h.equals(ChainStore.hash(ChainStore.GENESIS,p,124,1)));ok(!h.equals(ChainStore.hash(ChainStore.GENESIS,p,123,2)));
        ok(!h.equals(ChainStore.hash(ChainStore.GENESIS,p+" ",123,1)));ok(!ChainStore.pack("ab","c").equals(ChainStore.pack("a","bc")));
        ok(!ChainStore.pack((String)null).equals(ChainStore.pack("")));
        try{ChainStore.hash("wrong",p,1,1);throw new AssertionError();}catch(IllegalArgumentException expected){count++;}
        String prev=ChainStore.GENESIS;for(int i=1;i<=2000;i++){String next=ChainStore.hash(prev,ChainStore.pack("EVENT",""+i,"record"),i,i);ok(!next.equals(prev));prev=next;}
        CoherenceRules.Facts f=new CoherenceRules.Facts();f.network=true;
        CoherenceRules.Rule r=rule("R1");match(r,f,CoherenceRules.Match.UNKNOWN);f.internet=true;f.knownDestination=false;match(r,f,CoherenceRules.Match.YES);f.knownDestination=true;match(r,f,CoherenceRules.Match.NO);
        r=rule("R2");f.contacts=true;match(r,f,CoherenceRules.Match.UNKNOWN);f.contactSyncExpected=true;f.contactWindowComplete=true;f.contactSyncSeen=false;match(r,f,CoherenceRules.Match.YES);f.contactSyncSeen=true;match(r,f,CoherenceRules.Match.NO);
        r=rule("R3");f.uid=101000;f.action="CAMERA";f.system=true;match(r,f,CoherenceRules.Match.UNKNOWN);f.visible=false;match(r,f,CoherenceRules.Match.YES);f.visible=true;match(r,f,CoherenceRules.Match.NO);f.uid=11000;match(r,f,CoherenceRules.Match.NO);
        r=rule("R4");match(r,f,CoherenceRules.Match.UNKNOWN);f.inventoried=false;match(r,f,CoherenceRules.Match.YES);f.inventoried=true;match(r,f,CoherenceRules.Match.NO);
        r=rule("R5");r.threshold=100;f.txBytes=101L;match(r,f,CoherenceRules.Match.UNKNOWN);f.whitelisted=false;match(r,f,CoherenceRules.Match.YES);f.txBytes=100L;match(r,f,CoherenceRules.Match.NO);f.txBytes=101L;f.whitelisted=true;match(r,f,CoherenceRules.Match.NO);
        r=rule("R6");r.domains=Arrays.asList("example.org");match(r,f,CoherenceRules.Match.UNKNOWN);f.sni="api.EXAMPLE.org.";match(r,f,CoherenceRules.Match.YES);f.sni="evil-example.org";match(r,f,CoherenceRules.Match.NO);f.sni="example.org.attacker.net";match(r,f,CoherenceRules.Match.NO);f.sni="example.org";r.enabled=false;match(r,f,CoherenceRules.Match.NO);
        CoherenceRules.Rule a=rule("R1"),b=rule("R6");a.priority=10;b.priority=20;ok(CoherenceRules.sorted(Arrays.asList(a,b)).get(0)==b);b.priority=10;ok(CoherenceRules.sorted(Arrays.asList(b,a)).get(0)==a);
        List<TemporalPatternMath.Interval> intervals=Arrays.asList(new TemporalPatternMath.Interval(0,1000),new TemporalPatternMath.Interval(2000,3000),new TemporalPatternMath.Interval(6000,7000));
        List<TemporalPatternMath.Interval> collapsed=TemporalPatternMath.collapse(intervals,1500);ok(collapsed.size()==2);ok(collapsed.get(0).start==0&&collapsed.get(0).end==3000);
        TemporalPatternMath.Interval trigger=new TemporalPatternMath.Interval(10000,12000);ok(TemporalPatternMath.relationMs(trigger,new TemporalPatternMath.Interval(15000,16000))==3000);ok(TemporalPatternMath.relationMs(trigger,new TemporalPatternMath.Interval(7000,8000))==-2000);ok(TemporalPatternMath.relationMs(trigger,new TemporalPatternMath.Interval(11000,13000))==0);
        TemporalPatternMath.Metrics tm=TemporalPatternMath.metrics(Arrays.asList(new TemporalPatternMath.Interval(0,1000),new TemporalPatternMath.Interval(10000,11000)),Arrays.asList(new TemporalPatternMath.Interval(1500,1600),new TemporalPatternMath.Interval(30000,30100)),2000);ok(tm.pairedAfter==1);ok(tm.outsideAfter==1);ok(tm.medianAfterMs==500);
        KeyPairGenerator g=KeyPairGenerator.getInstance("EC");g.initialize(new ECGenParameterSpec("secp256r1"));KeyPair pair=g.generateKeyPair();byte[] message=h.getBytes(StandardCharsets.US_ASCII);Signature signer=Signature.getInstance("SHA256withECDSA");signer.initSign(pair.getPrivate());signer.update(message);byte[] signature=signer.sign();ok(ChainStore.verify(pair.getPublic(),message,signature));message[0]^=1;ok(!ChainStore.verify(pair.getPublic(),message,signature));message[0]^=1;ok(!ChainStore.verify(g.generateKeyPair().getPublic(),message,signature));
        System.out.println("PASS "+count+" assertions: chain, tri-state rules, temporal patterns, priority, JCA signature; no Android runtime.");
    }
}
