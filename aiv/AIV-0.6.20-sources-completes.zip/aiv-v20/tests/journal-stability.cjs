// Interface integration tests with a simulated Android bridge, not a device test.
// Install jsdom 26.1.0 in a separate development directory and set NODE_PATH.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { JSDOM, VirtualConsole } = require('jsdom');

const records = [];
const commands = [];
let running = false, bluetooth = false, failRead = false, capture = false;
let scheduledPoll=()=>{};
const findings=[];
let settings={failures:true,volume:true,dns:true,collection:true,watch:true,research:true,failure_count:8,upload_mib:10,domains:[],quiet:true};
const isNoise=e=>(e.category==='collecteur'&&e.action==='Signal de vie')||(e.category==='reseau'&&['Compteurs réseau globaux','Lecture des compteurs réseau Android'].includes(e.action))||e.action==='État de batterie reçu';
function add(action, transport = 'Interne') {
  records.push({ id: records.length + 1, timestamp: new Date().toISOString(), app: 'Android',
    action, transport, category: 'systeme', destination: 'Ressource observée', source: 'API simulée pour ce test',
    details: { marker: 'test-only' } });
}
const bridge = {
  status: () => JSON.stringify({running, network: running, bluetooth: running && bluetooth,
    bluetooth_enabled: bluetooth, last_alive_ms: running ? Date.now() : 0, error: '', capture, capture_starting: false, capture_state: capture ? 'Actif' : 'Arrêté', capture_error: ''}),
  page(query, transport, offset, limit, ceiling, actor, kind, quiet) {
    if (failRead) return JSON.stringify({error: 'Base temporairement indisponible'});
    const anchor = ceiling || records.length;
    const base = records.filter(e => e.id <= anchor && (!transport || e.transport === transport) &&
      (!actor || e.app === actor) && (kind !== 'apps' || ['trafic','dns'].includes(e.category)) && (kind !== 'system' || !['trafic','dns'].includes(e.category)) && JSON.stringify(e).toLowerCase().includes(query.toLowerCase())).reverse();
    const found=base.filter(e=>!quiet||query.trim()||!isNoise(e));
    return JSON.stringify({events: found.slice(offset, offset + limit), total: records.length,
      matched: found.length, ceiling_id: anchor, actors: [...new Set(records.map(e => e.app))],hidden_count:base.length-found.length});
  },
  diagnosticSummary(){return JSON.stringify({settings:{year:2026,utc_offset_minutes:-240,window_seconds:2},records:1,imports:[],file_status:'',recovery:'',activity:'',error:''});},
  diagnosticConfigure(value){const s=JSON.parse(value);return JSON.stringify(s.year<1970?{error:'Année invalide'}:s);},
  correlate(eventId){return JSON.stringify({event_id:eventId,interpretation:'Proximité temporelle seulement. Attribution non établie.',lines_in_window:1,lines_examined:1,window_ms_each_side:2000,candidates:[{match:'temporal',pid:222,delta_ms:123,import_id:1,source_line:4,tag:'<img src=x onerror="window.pwned=true">',time_basis:'epoch UTC',scope:'PID du rédacteur, pas nécessairement du socket.'}]});},
  analysisSummary(){return JSON.stringify({processed:records.length,checkpoint:records.length,latest:records.length,busy:false,unread:findings.filter(f=>f.kind==='anomaly'&&!f.reviewed).length,traces:findings.filter(f=>f.kind==='trace').length,error:'',settings});},
  analysisPage(kind,unread,offset){const selected=findings.filter(f=>f.kind===kind&&(!unread||!f.reviewed));return JSON.stringify({rows:selected.slice(offset,offset+15),total:selected.length});},
  analysisEvidence(){return JSON.stringify({events:records.slice(-2)});},
  analysisChange(action,value){
    if(action==='review')findings.find(f=>f.id===Number(value)).reviewed=true;
    if(action==='settings'){
      const input=JSON.parse(value);
      if(input.domains.some(d=>d.includes('://')))return JSON.stringify({error:'Domaine invalide : utiliser un nom seul.'});
      settings=input;
    }
    return JSON.stringify({ok:true,settings});
  },
  command(command) {
    commands.push(command);
    if (command === 'start') { running = true; add('Collecte démarrée'); }
    if (command === 'capture-on') capture = true;
    if (command === 'capture-off') capture = false;
    if (command === 'stop') { capture = false; running = false; add('Collecte arrêtée'); }
    if (command === 'bluetooth-on') bluetooth = true;
    if (command === 'bluetooth-off') bluetooth = false;
  }
};
const auditApps=Array.from({length:30},(_,i)=>({package_name:'test.app'+i,label:'Application '+String(i).padStart(2,'0'),system_app:i!==29,uid:11000+i,count:72,version_code:5,reference:{play_count:12,count_kind:'permissions',same_version:true,play_source:'Capture de test',reference_origin:'Saisie utilisateur',installed_version_code:5},permissions:[{name:'android.permission.CALL_PHONE',label:'Appeler',description:'<img src=x onerror="window.pwned=true">',granted:true,protection:'Dangereuse',protection_level:1,defined_by:'android',revocation:'INCONNU'}],attribution:'Un paquet',version_name:'5.0',enabled:true}));
let auditLastFilter;
bridge.auditSummary=()=>JSON.stringify({scan_id:1,total:30,system:29,busy:false,error:'',coverage:'Données simulées'});
bridge.auditPage=(q,scope,offset)=>{const rows=auditApps.filter(a=>(scope!=='system'||a.system_app)&&(scope!=='other'||!a.system_app)&&JSON.stringify(a).toLowerCase().includes(q.toLowerCase()));return JSON.stringify({rows:rows.slice(offset,offset+25),total:rows.length});};
bridge.auditDetail=pkg=>JSON.stringify({app:auditApps.find(a=>a.package_name===pkg),reference:auditApps.find(a=>a.package_name===pkg).reference,history:[],imported_findings:[],import_scope:'Simulé'});
bridge.auditContext=pkg=>JSON.stringify(auditApps.find(a=>a.package_name===pkg)||{error:'Inconnu'});
bridge.auditSave=(pkg,value)=>{auditApps.find(a=>a.package_name===pkg).reference={...JSON.parse(value),installed_version_code:5,reference_origin:'Saisie utilisateur'};return JSON.stringify({ok:true});};
bridge.pageFiltered=(...args)=>{auditLastFilter=args.slice(-2);const result=JSON.parse(bridge.page(...args.slice(0,8)));if(args[9]){result.events=result.events.filter(e=>e.details?.uid>=0&&e.details.uid%100000!==1000&&e.details.packages?.length===1&&e.details.packages[0]===args[9]);result.matched=result.events.length;}return JSON.stringify({...result,audit_index_checkpoint:records.length,audit_index_busy:false});};
const errors = [];
const virtualConsole = new VirtualConsole();
virtualConsole.on('jsdomError', e => errors.push(e.message));
const dom = new JSDOM(fs.readFileSync(path.join(__dirname, '../app/src/main/assets/journal.html'), 'utf8'), {
  url: 'https://journal.local.invalid/', runScripts: 'dangerously', pretendToBeVisual: true, virtualConsole,
  beforeParse(window) {
    window.JournalAndroid = bridge;
    window.TextEncoder = TextEncoder;
    window.TextDecoder = TextDecoder;
    window.HTMLElement.prototype.scrollIntoView = function() {};
    const interval = window.setInterval.bind(window);
    window.setInterval = (callback, delay) => {
      assert.equal(delay, 3000);
      scheduledPoll = callback;
      return interval(callback, delay);
    };
  }
});
const doc = dom.window.document;
const byId = id => doc.getElementById(id);
const rows = () => [...doc.querySelectorAll('#jc-events li')];
const click = id => byId(id).click();
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
function change(id, value, event = 'change') {
  byId(id).value = value;
  byId(id).dispatchEvent(new dom.window.Event(event, {bubbles: true}));
}

(async()=>{
 try {
  doc.querySelector('[data-jc-tab="journal"]').click();
  add('Premier événement');click('jc-refresh-journal');
  const first=rows()[0]; assert.equal(rows().length,1);
  add('Deuxième événement');
  for(let i=0;i<10;i++)scheduledPoll();
  assert.equal(rows().length,1,'New events do not replace the journal during reading');
  assert.equal(rows()[0],first,'Exact DOM node survives timer ticks');
  byId('jc-search').focus();byId('jc-search').value='texte en cours';scheduledPoll();
  assert.equal(doc.activeElement,byId('jc-search'));assert.equal(byId('jc-search').value,'texte en cours');
  byId('jc-search').value='';click('jc-refresh-journal');assert.equal(rows().length,2);
  rows()[0].querySelector('button').click();const detail=byId('jc-detail').innerHTML;
  add('Troisième événement');scheduledPoll();assert.equal(byId('jc-detail').innerHTML,detail);
  assert.equal(rows().length,2);assert.deepEqual(errors,[]);
  console.log('PASS journal stable DOM, focused input, open detail, incoming events and manual refresh');
 } finally {dom.window.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
