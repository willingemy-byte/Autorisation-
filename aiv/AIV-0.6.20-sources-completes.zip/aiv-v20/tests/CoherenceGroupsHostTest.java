package fr.erick.journallocal;
public final class CoherenceGroupsHostTest {
  private static void eq(Object a,Object b){if(a==null?b!=null:!a.equals(b))throw new AssertionError(a+" != "+b);}
  public static void main(String[] args){
    eq(CoherenceGroups.group(true,1000,91),"android");
    eq(CoherenceGroups.group(true,101000,1),"android");
    eq(CoherenceGroups.group(true,10138,1),"system");
    eq(CoherenceGroups.group(false,10363,1),"user");
    eq(CoherenceGroups.group(false,10363,2),"android");
    CoherenceGroups.Stats s=new CoherenceGroups.Stats();s.add(80,1);s.add(null,0);s.add(100,0);eq(s.total,3);eq(s.evaluated,2);eq(s.unknown,1);eq(s.mean(),90);
    System.out.println("PASS exclusive UID groups and unknown excluded from mean");
  }
}
