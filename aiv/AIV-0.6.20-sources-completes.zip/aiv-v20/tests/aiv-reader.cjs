// Real Chromium DOM with simulated Java bridge; not Android/WebView or SQLite integration.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES?process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright':'playwright');
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:process.env.AIV_CHROMIUM||undefined,args:['--no-sandbox']});
 try{
  const page=await browser.newPage({viewport:{width:390,height:844}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
  const old=fs.readFileSync(path.join(__dirname,'native-reader.cjs'),'utf8');
  const mock=old.slice(old.indexOf('const records = []'),old.indexOf('const errors = []'));
  await page.evaluate(mock+`\nwindow.testCommands=commands;window.testConfig=[];
  bridge.aivSummary=()=>JSON.stringify({findings:2,pending:0,watcher_running:true,verification:'VALID_AT_4',apps:[{app:'test.app',findings:2,evaluated:3,ratio:2/3}],sources:[{source:'bayton',apps:3,last_sync_ms:100,status:'IMPORTED_LOCAL_UNVERIFIED_SOURCE'}],rules:[{name:'R6',version:1,enabled:1,priority:600,decision:'DENIED',condition:'{"type":"R6","domains":[]}'}]});
  bridge.aivPage=(filter,before)=>{window.testFilter=filter;window.testBefore=before;return JSON.stringify({rows:filter==='ALLOW'?[]:[{id:2,event_id:1,rule_name:'R6',decision:'DENIED',timestamp_ms:100}],next:before?0:1});};
  bridge.aivDetail=id=>JSON.stringify({event:{id,payload:'<img src=x onerror="window.pwned=true">'},chain:[{hash_prev:'0'.repeat(64),hash_self:'1'.repeat(64),signature:null}],verification:'VALID_AT_4',signature_scope:'EXPORT_ONLY'});
  bridge.aivConfigure=value=>window.testConfig.push(JSON.parse(value));window.JournalAndroid=bridge;`);
  await page.setContent(fs.readFileSync(path.join(__dirname,'../app/src/main/assets/journal.html'),'utf8'));
  await page.locator('#aiv-tab').click();await page.locator('#aiv-rows button').first().click();
  assert.match(await page.locator('#aiv-detail').innerText(),/hash_prev/);assert.equal(await page.locator('#aiv-detail img').count(),0);
  assert.equal(await page.evaluate(()=>window.pwned),undefined);
  await page.selectOption('#aiv-filter','ALLOW');assert.match(await page.locator('#aiv-rows').innerText(),/Aucune/);assert.equal(await page.evaluate(()=>window.testFilter),'ALLOW');
  await page.selectOption('#aiv-filter','DENIED');await page.locator('#aiv-next').click();assert.equal(await page.evaluate(()=>window.testBefore),1);await page.locator('#aiv-first').click();assert.equal(await page.evaluate(()=>window.testBefore),0);
  for(const id of ['aiv-start','aiv-stop','aiv-verify','aiv-export'])await page.locator('#'+id).click();
  assert.deepEqual(await page.evaluate(()=>window.testCommands.slice(-4)),['aiv-start','aiv-stop','aiv-verify','aiv-export']);
  await page.locator('#jc-pane-decisions details summary').click();await page.locator('#aiv-rules button').first().click();await page.locator('#aiv-save').click();assert.equal(await page.evaluate(()=>window.testConfig[0].name),'R6');
  await page.locator('[data-jc-tab="references"]').click();assert.match(await page.locator('#aiv-references').innerText(),/bayton/);await page.locator('#aiv-import').click();assert.equal(await page.evaluate(()=>window.testCommands.at(-1)),'aiv-reference');
  for(const tab of ['journal','audit','anomalies','diagnostic','permissions','sources','decisions'])await page.locator('[data-jc-tab="'+tab+'"]').click();
  const width=await page.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth}));assert.ok(width.scroll<=width.width+1,JSON.stringify(width));
  await page.screenshot({path:path.join(__dirname,'../build/aiv-mobile.png'),fullPage:true});
  assert.deepEqual(errors,[]);console.log('PASS AIV Chromium bridge: tabs, filters, keyset pagination, details, XSS, policy edit, import/export commands, 390px layout; no Android device.');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exit(1)});
