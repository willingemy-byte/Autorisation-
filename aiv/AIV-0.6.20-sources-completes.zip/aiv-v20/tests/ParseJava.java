import java.nio.file.*;
import java.util.*;
import javax.tools.*;
import com.sun.source.util.JavacTask;
/** Syntax-only gate: explicitly does not resolve Android API symbols. */
public class ParseJava {
 public static void main(String[] args)throws Exception{
  JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();DiagnosticCollector<JavaFileObject> diagnostics=new DiagnosticCollector<>();
  List<java.io.File> files=new ArrayList<>();try(java.util.stream.Stream<Path> stream=Files.walk(Paths.get(args[0]))){stream.filter(p->p.toString().endsWith(".java")).forEach(p->files.add(p.toFile()));}
  try(StandardJavaFileManager fm=compiler.getStandardFileManager(diagnostics,null,null)){
   JavacTask task=(JavacTask)compiler.getTask(null,fm,diagnostics,Arrays.asList("-source","8","-proc:none"),null,fm.getJavaFileObjectsFromFiles(files));for(Object unit:task.parse()){}
   for(Diagnostic<?> d:diagnostics.getDiagnostics())if(d.getKind()==Diagnostic.Kind.ERROR)throw new AssertionError(d.toString());
  }System.out.println("PASS syntax parse of "+files.size()+" Java sources; no Android API binding or APK compilation.");
 }
}
