// UI contract with a simulated Android bridge; never a device/UID attribution test.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {JSDOM,VirtualConsole}=require('jsdom');
const original=fs.readFileSync(path.join(__dirname,'native-reader.cjs'),'utf8');
const fixture=original.slice(original.indexOf('const records = []'),original.indexOf('const errors = []'))+`
auditApps.forEach((a,i)=>{a.system_app=i<2;a.uid=i===0?1000:11000+i;});
const scored=auditApps.map((a,i)=>({package:a.package_name,label:a.label,uid:a.uid,group:i===0?'android':i===1?'system':'user',category:i===29?'unknown':'weather',score:i===29?null:i===0?85:i===1?70:i===2?5:100,incoherences:i===2?4:0}));
scored.sort((a,b)=>(a.score??101)-(b.score??101));
const groups=[{id:'android',score:85,app_count:1,evaluated_count:1,unknown_count:0,below_50:0,incoherences:0,sum_scores:85,minimum:85},{id:'system',score:70,app_count:1,evaluated_count:1,unknown_count:0,below_50:0,incoherences:0,sum_scores:70,minimum:70},{id:'user',score:96,app_count:28,evaluated_count:27,unknown_count:1,below_50:1,incoherences:4,sum_scores:2605,minimum:5}];
bridge.coherenceSummary=()=>JSON.stringify({available:true,groups,apps:scored,app_count:30,evaluated_count:29,unknown_count:1,below_50:1,incoherences:4,sum_scores:2760,minimum:5});
bridge.coherenceStatus=()=>JSON.stringify({endpoint_configured:true,endpoint:'https://example.invalid/api/coherence',running:false,message:'Résultats de test'});
bridge.coherenceDetail=pkg=>JSON.stringify({available:true,engine:'generate_verdicts.py/2.1',generated_at_ms:1789507319000,verdict:{package:pkg,category:'weather',score_local:5,incoherences_local:[{permission:'CALL_PHONE',reason:'Règle de test <img src=x onerror="window.pwned=true">',penalty:40},{permission:'*',reason:'Cumul',penalty:30},{permission:'*',reason:'Volume',penalty:15},{permission:'READ_SMS',reason:'Règle de test',penalty:10}]}});
bridge.openAuditedApp=(pkg,settings)=>commands.push({pkg,settings});
bridge.coherenceRefresh=()=>{commands.push('coherence-refresh');return JSON.stringify({running:false});};
bridge.aivSummary=()=>JSON.stringify({findings:0,stats_evaluated:0,apps:[]});
window.JournalAndroid=bridge;window.testCommands=commands;
`;
fs.mkdirSync(path.join(__dirname,'../build'),{recursive:true});
fs.writeFileSync(path.join(__dirname,'../build/coherence-fixture.js'),fixture);
const errors=[],vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
const dom=new JSDOM(fs.readFileSync(path.join(__dirname,'../app/src/main/assets/journal.html'),'utf8'),{
  url:'https://journal.local.invalid/',runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,
  beforeParse(w){w.eval(fixture);w.TextEncoder=TextEncoder;w.TextDecoder=TextDecoder;w.HTMLElement.prototype.scrollIntoView=function(){};w.setInterval=()=>1;w.clearInterval=()=>{};}
});
try{
  const d=dom.window.document,id=x=>d.getElementById(x);
  assert.deepEqual(errors,[]);
  assert.equal(d.querySelectorAll('#jc-group-rings button').length,3);
  assert.deepEqual([...d.querySelectorAll('#jc-group-rings button strong')].map(x=>x.textContent),['Android','Système','Utilisateur']);
  assert.match(id('jc-home-title').textContent,/1 application.*sous 50/);
  assert.equal(id('jc-home-app-list').children.length,25);
  id('jc-home-more').click();assert.equal(id('jc-home-app-list').children.length,30);
  d.querySelector('[data-group="android"]').click();assert.equal(id('jc-home-app-list').children.length,1);assert.match(id('jc-home-app-list').textContent,/UID 1000/);
  d.querySelector('[data-group="system"]').click();assert.equal(id('jc-home-app-list').children.length,1);assert.match(id('jc-home-alert-text').textContent,/70 points ÷ 1/);
  d.querySelector('[data-group="user"]').click();assert.match(id('jc-home-alert-text').textContent,/2605 points ÷ 27/);
  assert.equal(id('jc-home-app-list').firstElementChild.dataset.package,'test.app2');
  id('jc-home-app-list').firstElementChild.click();assert.equal(id('jc-pane-audit').hidden,false);
  assert.match(id('ja-detail').textContent,/100 points − 95 points de pénalité = 5/);
  assert.equal(id('ja-detail').querySelectorAll('img').length,0);assert.equal(dom.window.pwned,undefined);
  assert.ok(id('ja-permission-search'));assert.match(id('ja-permissions').textContent,/CALL_PHONE/);
  [...id('ja-detail').querySelectorAll('button')].find(b=>b.textContent==='Fiche Android et autorisations').click();assert.equal(dom.window.testCommands.at(-1).settings,true);
  [...id('ja-detail').querySelectorAll('button')].find(b=>b.textContent==='Retour aux trois scores').click();assert.equal(id('jc-pane-home').hidden,false);
  id('jc-home-search').value='Application 29';id('jc-home-search').dispatchEvent(new dom.window.Event('input'));assert.match(id('jc-home-app-list').textContent,/Non évaluée/);
  id('jc-home-refresh').click();assert.ok(dom.window.testCommands.includes('coherence-refresh'));
  id('jc-mode-ti').click();assert.match(id('jc-score-number').textContent,/72/);id('jc-mode-user').click();
  assert.deepEqual(errors,[]);console.log('PASS three groups, filters, pagination, average explanation, detail, permissions, settings action, unknown category excluded, refresh, TI switch, safe text. Simulated bridge only.');
}finally{dom.window.close();}
