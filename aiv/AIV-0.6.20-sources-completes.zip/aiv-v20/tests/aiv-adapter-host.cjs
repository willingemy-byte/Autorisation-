// Actual adapter JS with a minimal DOM and Android bridge double. No rendering engine.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
class Node {constructor(tag='div',text=''){this.tag=tag;this.textContent=text;this.children=[];this.style={};this.value='';this.handlers={};}append(...xs){this.children.push(...xs)}replaceChildren(...xs){this.children=xs}addEventListener(n,f){this.handlers[n]=f}}
const elements=new Map(),$=id=>{if(!elements.has(id))elements.set(id,new Node());return elements.get(id)};
const calls=[],events=[];let broken=false;
const bridge={
 aivSummary:()=>JSON.stringify({findings:2,pending:3,watcher_running:true,verification:broken?'BROKEN: test':'VALID_AT_4',apps:[{app:'test.app',findings:2,evaluated:3,ratio:2/3}],sources:[{source:'bayton',apps:2,status:'IMPORTED',last_sync_ms:100}],rules:[{name:'R6',version:1,enabled:1,decision:'DENIED',priority:600,condition:'{"type":"R6","domains":[]}'}]}),
 aivPage:(filter,before)=>{calls.push(['page',filter,before]);return JSON.stringify({rows:filter==='ALLOW'?[]:[{id:2,event_id:1,rule_name:'R6',decision:'DENIED',timestamp_ms:100}],next:before?0:1})},
 aivDetail:id=>JSON.stringify({event:{id,app:'<img src=x onerror=bad()>'},chain:[{hash_prev:'0'.repeat(64),hash_self:'1'.repeat(64),signature:null}]}),
 command:c=>calls.push(['command',c]),aivConfigure:s=>calls.push(['configure',JSON.parse(s)])
};
const ctx={nativeBridge:bridge,$,element:(tag,text)=>new Node(tag,text),setTimeout:f=>f(),console};vm.createContext(ctx);vm.runInContext(fs.readFileSync(path.join(__dirname,'../tools/aiv-adapter.js'),'utf8'),ctx);
ctx.renderAiv();assert.equal($('aiv-tab').textContent,'Décisions · 2');assert.equal($('aiv-next').disabled,false);
$('aiv-rows').children[0].children[0].onclick();assert.match($('aiv-detail').children[1].textContent,/hash_prev/);assert.match($('aiv-detail').children[1].textContent,/<img/);assert.equal($('aiv-detail').children[1].tag,'pre');
$('aiv-filter').value='ALLOW';$('aiv-filter').onchange();assert.match($('aiv-rows').children[0].textContent,/Aucune/);
$('aiv-filter').value='DENIED';$('aiv-filter').onchange();$('aiv-next').onclick();assert.deepEqual(calls.at(-1),['page','DENIED',1]);$('aiv-first').onclick();assert.deepEqual(calls.at(-1),['page','DENIED',0]);
for(const id of ['aiv-start','aiv-stop','aiv-verify','aiv-export','aiv-import'])$(id).onclick();assert.deepEqual(calls.filter(c=>c[0]==='command').map(c=>c[1]),['aiv-start','aiv-stop','aiv-verify','aiv-export','aiv-reference']);
$('aiv-rules').children[0].onclick();$('aiv-save').onclick();assert.equal(calls.at(-1)[1].name,'R6');assert.equal(calls.at(-1)[1].enabled,true);
broken=true;ctx.renderAivStatus();assert.equal($('aiv-status').style.color,'#ff5964');
bridge.aivPage=()=>JSON.stringify({error:'Base interrompue'});ctx.renderAiv();assert.equal($('aiv-status').textContent,'Base interrompue');
console.log('PASS adapter integration: filters, pagination, details as text, commands, rules, broken-chain badge, errors. Minimal DOM simulation, no browser rendering.');

// Background tabs must not perform AIV bridge calls; visible tabs refresh at most every 10 seconds.
let now=Date.now()+50000,summaryReads=0;const originalSummary=bridge.aivSummary;
ctx.Date=class extends Date {static now(){return now;}};
bridge.aivSummary=()=>{summaryReads++;return originalSummary();};
for(let i=0;i<6000;i++){now+=3000;ctx.pollAiv('journal');}
assert.equal(summaryReads,0);
ctx.pollAiv('references');assert.equal(summaryReads,1);
for(let i=0;i<1000;i++)ctx.pollAiv('references');assert.equal(summaryReads,1);
now+=9999;ctx.pollAiv('references');assert.equal(summaryReads,1);
now++;ctx.pollAiv('references');assert.equal(summaryReads,2);
bridge.aivSummary=()=>JSON.stringify({...JSON.parse(originalSummary()),checkpoint:14,latest_event_id:90,pending:null,stats_complete:false,stats_evaluated:7,operation:'Analyse AIV en pause'});
ctx.renderAivStatus();assert.equal($('aiv-tab').textContent,'Décisions · calcul partiel');assert.match($('aiv-apps').children[0].textContent,/7 décisions/);assert.doesNotMatch($('aiv-status').textContent,/null événements/);assert.match($('aiv-status').textContent,/dernier enregistré 90/);
console.log('PASS throttled active-tab polling, 6000 inactive polls, partial statistics and honest progress with ID gaps.');
