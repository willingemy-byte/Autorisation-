import sys,pathlib,tempfile,subprocess,json,hashlib,base64,unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'tools'))
from verify_aiv_export import check,pack,chain_hash,GENESIS
class ExportProtocol(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory();cls.d=pathlib.Path(cls.tmp.name)
  subprocess.run(['openssl','genpkey','-algorithm','EC','-pkeyopt','ec_paramgen_curve:P-256','-out',str(cls.d/'key.pem')],check=True,capture_output=True)
  cls.pub=subprocess.check_output(['openssl','pkey','-in',str(cls.d/'key.pem'),'-pubout','-outform','DER']);cls.pin=hashlib.sha256(cls.pub).hexdigest()
 @classmethod
 def tearDownClass(cls):cls.tmp.cleanup()
 def fixture(self,signed=True):
  e=pack('EVENT',1,123,'test.app','traffic','1.2.3.4:443','TCP','trafic','{}','{}');eh=chain_hash(GENESIS,e,123,1)
  p=pack('DECISION',1,1,'R6','DENIED',json.dumps({'event_hash':eh}),124,'NOT_ENFORCED');dh=chain_hash(eh,p,124,2)
  rows=[dict(type='HEADER',format='AIV-EXPORT-1',genesis=GENESIS,count=2,head=dh,checkpoint=1,signature_status='SIGNED' if signed else 'UNSIGNED_KEYSTORE_UNAVAILABLE',key_id=self.pin if signed else None,public_key_spki=base64.b64encode(self.pub).decode() if signed else None),dict(type='RECORD',id=1,event_id=1,decision_id=None,kind='EVENT',payload=e,timestamp_ms=123,hash_prev=GENESIS,hash_self=eh),dict(type='RECORD',id=2,event_id=1,decision_id=1,kind='DECISION',payload=p,timestamp_ms=124,hash_prev=eh,hash_self=dh)]
  body=b''.join((json.dumps(r)+'\n').encode() for r in rows);h=hashlib.sha256(body).hexdigest();sig=None
  if signed:
   (self.d/'msg').write_bytes(('AIV-EXPORT-1\n'+h).encode());sig=base64.b64encode(subprocess.check_output(['openssl','dgst','-sha256','-sign',str(self.d/'key.pem'),str(self.d/'msg')])).decode()
  raw=body+(json.dumps(dict(type='FOOTER',sha256=h,algorithm='SHA256withECDSA' if signed else 'NONE',signature=sig))+'\n').encode();p=self.d/'test.jsonl';p.write_bytes(raw);return p
 def test_signed_pinned(self):self.assertTrue(check(self.fixture(),self.pin)['trusted_key'])
 def test_signed_unpinned(self):self.assertFalse(check(self.fixture())['trusted_key'])
 def test_wrong_pin(self):
  with self.assertRaises(ValueError):check(self.fixture(),'0'*64)
 def test_degraded(self):self.assertFalse(check(self.fixture(False))['signature_valid'])
 def test_truncated(self):
  p=self.fixture();p.write_bytes(p.read_bytes()[:-10])
  with self.assertRaises(ValueError):check(p,self.pin)
 def test_changed_payload(self):
  p=self.fixture();p.write_bytes(p.read_bytes().replace(b'test.app',b'evil.app'))
  with self.assertRaises(ValueError):check(p,self.pin)
 def test_reordered(self):
  p=self.fixture();r=p.read_bytes().splitlines(keepends=True);r[1],r[2]=r[2],r[1];p.write_bytes(b''.join(r))
  with self.assertRaises(ValueError):check(p,self.pin)
 def test_tail_removed(self):
  p=self.fixture();r=p.read_bytes().splitlines(keepends=True);p.write_bytes(b''.join(r[:2]+r[3:]))
  with self.assertRaises(ValueError):check(p,self.pin)
 def test_signature_missing(self):
  p=self.fixture();r=p.read_bytes().splitlines(keepends=True);f=json.loads(r[-1]);f['signature']=None;r[-1]=(json.dumps(f)+'\n').encode();p.write_bytes(b''.join(r))
  with self.assertRaises(ValueError):check(p,self.pin)
if __name__=='__main__':unittest.main()
