#!/usr/bin/env python3
"""Host-only tests, no downloads. Java 17 JDK compiler module, Python 3, Node, OpenSSL."""
import pathlib,subprocess
r=pathlib.Path(__file__).resolve().parents[1];out=r/'build/host-aiv';out.mkdir(parents=True,exist_ok=True)
def run(*args):subprocess.run(list(map(str,args)),check=True)
src=r/'app/src/main/java/fr/erick/journallocal'
run('java','-m','jdk.compiler/com.sun.tools.javac.Main','--release','8','-d',out,src/'ChainStore.java',src/'CoherenceRules.java',src/'TemporalPatternMath.java',r/'tests/AivCoreTest.java')
run('java','-cp',out,'fr.erick.journallocal.AivCoreTest')
run('java',r/'tests/ParseJava.java',r/'app/src/main/java')
run('python3',r/'tests/test_aiv_sqlite.py')
run('python3',r/'tests/test_aiv_export.py')
run('node',r/'tests/aiv-adapter-host.cjs')
run('node',r/'tests/audit-rules.cjs')
run('python3',r/'tools/connect_reader.py')
