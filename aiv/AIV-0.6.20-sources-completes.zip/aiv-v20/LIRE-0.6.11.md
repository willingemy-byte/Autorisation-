# AIV 0.6.11 — trois groupes et compilation Railway

Version de l’application : **0.6.11**, code **17**, package `fr.erick.journallocal`.
Base : `AIV-0.6.10-working-no-category-exclusion.zip`.

## Accueil

| Cercle | Règle |
|---|---|
| Android, gauche | Application préinstallée sans trace individuellement attribuable dans le journal analysé. |
| Système, centre | Application préinstallée avec une trace individuellement attribuable dans ce journal. |
| Utilisateur, droite | Application installée par l’utilisateur, avec ou sans trace. |

L’origine provient des flags Android `FLAG_SYSTEM`/`FLAG_UPDATED_SYSTEM_APP`, pas
du nom du paquet ni de la catégorie fonctionnelle estimée. Les traces exploitables
sont actuellement les métadonnées réseau indexées par le collecteur. Un UID
partagé ou réservé, dont 1000, ne permet pas d’attribuer un flux à tous les paquets
candidats. Les traces d’inventaire ne sont pas prises pour une activité de l’app.

L’historique complet disponible est indexé, sans limite aux derniers événements.
Une recherche indexée par application évite de reparcourir 500 000 événements
pour chaque app. Le classement est marqué provisoire pendant cette indexation
et se met à jour à son achèvement. Une application système passe au centre si
une nouvelle trace individuelle devient disponible. L’absence actuelle de trace
n’est pas transformée en certitude d’absence future ou d’absence d’activité.

## Scores

Chaque score numérique existant participe à la moyenne de son groupe, y compris
si la fonction est `unknown`. Une application réellement sans résultat reste
affichée en attente de score; ni zéro ni cent ne sont inventés à sa place.
Les coefficients et les scores individuels du moteur ne sont pas modifiés.

Le fichier de scores retrouvé contient 25 apps, dont 6 auparavant exclues par le
résumé. La copie corrigée conserve les 25 entrées à l’identique et inclut leurs
25 scores. Elle ne permet pas de calculer honnêtement les trois groupes à elle
seule : l’origine locale des installations et le journal du téléphone sont requis.
La moyenne arithmétique de contrôle des 25 scores est 76,6; elle ne remplace pas
les trois moyennes de l’accueil.

L’audit vise les écarts entre fonction annoncée, permissions déclarées, permissions
accordées et observations disponibles. Ces données restent distinctes. Les nombres
affichés dans une fiche et dans un manifeste doivent être comparés pour la même
version et le même type de liste; une permission de journal d’appels ne signifie
pas un accès au journal privé AIV. Aucun nouveau score du Dossier sécurisé n’est
inventé dans cette livraison.

## Compilation et signature

La chaîne reproductible est documentée dans `railway-build/README.md`.
L’APK 0.6.11 a été entièrement recompilé sur Railway le 16 septembre 2026 et
récupéré avec contrôle SHA-256. Il est non signé; la signature est une étape
distincte avec la clé historique conservée localement.
Le rapport associé indique précisément les tests effectués et leurs limites.

Les anciens guides et rapports 0.6.1 à 0.6.10 restent des pièces historiques;
ils ne prouvent pas la validation de 0.6.11. Le bootstrap local lit désormais la
version du manifeste au lieu d’exiger encore 0.6.9. `AIV_BUILD_MODE=unsigned`
active sa sortie sans signature; le mode par défaut conserve la signature locale.
