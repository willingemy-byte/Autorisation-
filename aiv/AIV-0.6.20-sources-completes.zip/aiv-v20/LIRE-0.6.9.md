# Journal Local AIV 0.6.10 — attribution Android et paquets système

APK : `AIV-0.6.9-trois-groupes.apk`. Paquet : `fr.erick.journallocal`.
Version code : 16. Certificat historique vérifié; mise à jour sur l'installation
existante, sans désinstallation ni effacement des données.

## Changements

- Trois cercles : Android (appId de l'UID inférieur à 10000), Système
  (FLAG_SYSTEM ou FLAG_UPDATED_SYSTEM_APP, hors premier groupe), Utilisateur
  (autres applications de l'inventaire). Le profil est pris en compte par
  `uid % 100000`. Un UID inconnu reste non classé.
- Chaque cercle affiche une moyenne distincte, sa couverture et le nombre de
  scores inférieurs à 50. Le clic filtre la liste. La liste est triée, recherchable
  et paginée par 25, avec les inconnues en fin de liste.
- Le clic d'une application ouvre son dossier et les pénalités expliquant le
  score. Boutons séparés pour lancer l'application ou sa fiche Android.
- Un UID partagé reste partagé. Les groupes concernent les permissions des
  paquets inventoriés : les flux sans attribution n'obtiennent pas de score fictif.
- Correction de l'inférence `gm` : Gmail ne capture plus `gms` ou
  `gms.supervision`. Correspondance exacte ou suivie d'un point. Chrome est
  explicitement un navigateur. Le moteur 2.1 expose les pénalités en points.
- Les UID et flags restent locaux; la requête HTTPS conserve seulement les
  noms de paquets et les permissions déclarées.

## Sources à modifier

`tools/coherence-groups.js`, `tools/mvp-home.js`, `.html` et `.css`,
`tools/audit-adapter.js` : interface. `tools/connect_reader.py` génère ensuite
`app/src/main/assets/journal.html` ; ne pas modifier seulement le HTML généré.

Java : `CoherenceGroups.java`, `CoherenceRefresh.java`, `PermissionAudit.java`,
`MainActivity.java` dans `app/src/main/java/fr/erick/journallocal/`.

Moteur : `api/coherence.py` et `tools/generate_verdicts.py`.

## Compilation réellement utilisée

Compilation locale, pas sur Railway. Outils : Platform 35 r02, Build Tools
35.0.0, NDK 27.3.13750724 et ECJ 3.40.0. Provenances et empreintes dans
`docs/build-toolchain.json`; téléchargement vérifié disponible dans
`bootstrap-clean-build.sh`. Le script doit garder les marqueurs de la version
courante lorsqu'une nouvelle version est préparée.

Dans cette session, le cache était dans
`/workspace/scratch/0b13c3c2a290/toolchain`. Ce chemin est temporaire : le tester
avant de le réutiliser, sinon réinstaller les outils officiels et vérifier les
empreintes. La signature était fournie depuis un dossier privé séparé.

```bash
python3 build.py \
  --android-jar "$AIV_SDK/platforms/android-35/android.jar" \
  --build-tools "$AIV_SDK/build-tools/35.0.0" \
  --ecj "$AIV_ECJ" \
  --ndk "$AIV_SDK/ndk/27.3.13750724" \
  --signing-dir "$AIV_SIGNING_DIR"
```

Ce sont des variables à renseigner selon les fichiers réellement disponibles.
`build.py` reconstruit Java, DEX et les bibliothèques C/JNI arm64 et x86_64,
package les ressources, effectue zipalign, vérifie le certificat et signe.
Il n'utilise aucune ancienne APK comme base. Résultat : `build/journal-local.apk`.
Le keystore `journal-local.p12` et `password.txt` doivent être récupérés séparément,
rester privés et être exclus des archives et des variables Railway.

## Railway : moteur uniquement

Archive autonome : `AIV-coherence-Railway.zip`.
Projet : AIV Android Clean Build, `767d6c04-3517-4308-9a68-5b2ea0c64037`.
Service : aiv-coherence, `3c2c79dd-0ce8-4997-b5ea-d9bf8d9cc8be`.
Environnement : production, `f9f4a840-53d1-4641-95d2-766b2eb46fb5`.
URL : https://aiv-coherence-production.up.railway.app/api/coherence

Le service `aiv-android-builder` préexistant n'a pas été utilisé ni modifié.
Le service de calcul utilise l'image officielle `python:3.12-slim`, PORT=8080
et le contrôle `/health`. Aucune dépendance pip ni dépôt GitHub requis pour
cette méthode.

Pour mettre à jour le moteur : synchroniser ses deux sources dans l'archive
Railway, lancer `python3 package_service.py`, puis transmettre les nouvelles
valeurs `AIV_SOURCE_ZIP_B64` et `AIV_SOURCE_SHA256` de `deployment-spec.json`
à `railway_set_variables` pour ce service avec `skipDeploys=false`.
La commande de démarrage existante reconstitue uniquement les trois fichiers
autorisés et vérifie SHA-256. Ne modifier la commande que si nécessaire.
Vérifier SUCCESS, `/health`, puis un POST réel synthétique; un GET seul ne
vérifie pas le calcul. Aucun inventaire personnel requis pour ces tests.

## Validation et limites

16 vérifications Java de groupes/moyennes; interface jsdom avec pont Android
simulé; 14 tests du moteur et serveur; POST HTTPS réel moteur 2.1; signature v2/v3,
version, certificat et permissions vérifiés. Natives intégralement reconstruites
et identiques à la version précédente. Détail dans `verification-0.6.9.json`.

Aucun téléphone ni émulateur connecté. Rendu Chromium non vérifié : le
téléchargement du navigateur a échoué. Ne pas présenter les simulations comme
des tests effectués sur Android. Installer l'APK mise à jour puis Actualiser
pour récupérer les catégories corrigées et les pénalités détaillées.

Après toute modification d'application, incrémenter versionCode et versionName.
Les fichiers `verification*.json` plus anciens documentent les versions passées.
`SOURCE-SHA256.json` recense les sources de la présente archive.
