# AIV 0.6.17 — démarrage et navigation

Installer AIV-0.6.17-signed.apk comme mise à jour de l’application existante, sans la désinstaller. Ensuite ouvrir AIV depuis son icône Android : ouvrir à nouveau le fichier APK relance l’installateur.

Même identifiant fr.erick.journallocal et même certificat que les versions précédentes. Aucun effacement, réinitialisation ou remplacement de la base du journal. Les observations, règles et références existantes sont conservées. Une désinstallation Android peut supprimer ces données privées.

## Changements

- Initialisation visible avec cercle animé : inventaire en arrière-plan, référence estimée puis calcul local. Le dernier inventaire complet reste conservé si le relevé échoue. Un écran d’erreur permet de consulter le dernier relevé ou de réessayer.
- L’historique réseau complet n’est pas réanalysé avant d’ouvrir l’accueil. L’analyse incrémentale continue séparément.
- Suppression du rafraîchissement automatique de trois secondes qui reconstruisait les pages Applications, Anomalies, Sources et Diagnostic. Le journal demeure actualisé à la demande.
- Réutilisation du résultat calculé pour changer les filtres de l’accueil ou ouvrir une fiche. Recalcul après nouvel inventaire ou modification des règles.
- Lecture et recherche du journal en arrière-plan; les résultats devenus périmés ne remplacent pas une nouvelle recherche. Temporisation de 300 ms pendant la saisie.
- Boutons de navigation et modes actifs bleus. Couleurs de gravité conservées sur les résultats et multiplicateurs.
- Navigation : Accueil, Journal, Anomalies, Décisions, Applications, Paramètres. Bixby n’a plus d’entrée dédiée; son dossier et ses données ne sont pas supprimés.
- Paramètres regroupe barème, formules, couleurs, références, règles R1 à R6 et réglages des signalements. Diagnostic et sources restent accessibles ici.
- Vue TI : mêmes données locales et même calcul que la vue utilisateur. Les pourcentages fictifs du parc de démonstration ne sont plus affichés.
- Nom, UID et couleur de l’application lorsque l’attribution permet une correspondance unique. UID absent ou ambigu explicitement non attribué; aucune attribution forcée depuis un simple nom ou un domaine commun.

## Deux valeurs distinctes

Pour chaque application : H est le nombre de permissions moins visibles selon la référence retenue, M son multiplicateur et P = H × M.

Pour un groupe ou le téléphone :

- Centre du cercle = ΣH / C, où C compte seulement les applications évaluées avec H > 0.
- Badge = ΣP / ΣH : multiplicateur effectif, pondéré par les écarts de chaque application.
- Couleur = seuil du multiplicateur. Défauts : jaune ×2, orange ×4, rouge ×6, critique ×8. Modifiables sans nouvelle APK.
- Les totaux bruts restent explicités sous le cercle. Arrondi à deux décimales pour les moyennes; calcul des pénalités entières sans perte de précision.
- Les applications sans écart et inconnues n’abaissent pas cette moyenne. Toutes inconnues : tiret. Applications évaluées sans écart : zéro et facteur neutre ×1.

Exemple des captures : 12 043 / 399 = 30,18 au centre. Android : 4 044 / 140 = 28,89; Système : 6 934 / 214 = 32,40; Utilisateur : 1 065 / 45 = 23,67.

Les facteurs du barème 0.6.16 sont conservés : L2, L3 et portées L4 documentées. Les anciens constats L5 restent conservés sans réactivation automatique; ils sont visibles dans les fiches et doivent être requalifiés explicitement. Cette mise à jour ne crée pas de preuves de capacités manquantes. Un facteur ×1 signifie qu’aucun facteur supérieur n’a été appliqué avec les règles et observations disponibles.

## Séries liées

Dans Anomalies, deux vues : Signalements et Séries liées. Les rapprochements sont préparés à l’ouverture, sans bouton « lier ».

Les flux sortie/retour restent reliés par leur identifiant local. Des séries supplémentaires rapprochent les flux observés vers une même IP/port/protocole, un même nom DNS ou SNI, dans une fenêtre de cinq minutes. Elles portent l’étiquette « corrélation temporelle ». Les cartes sont compactes; toucher ouvre les détails.

La projection est bornée à la page examinée (25 flux, jusqu’à 750 événements réseau par demande). La recherche et « Afficher des flux plus anciens » permettent d’examiner d’autres fenêtres. Ce n’est pas un graphe exhaustif de tout l’historique, ni une preuve qu’une application a causé le plantage d’une autre. Les correspondances entre fenêtres chargées séparément ne sont pas fusionnées. Les noms SNI associés à ECH ne servent pas à ces rapprochements.

## Vérification

Compilation Java et native, signature APK vérifiée. Tests de calcul, interface avec pont Android simulé, stabilité du journal, démarrage différé, réutilisation du cache, navigation, séries et réponses asynchrones périmées. Pas de test sur un appareil Android ou émulateur dans cet environnement; les performances réelles sur le téléphone restent à confirmer.
