# AIV 0.6.16 — base, multiplicateur et style néon

Version 0.6.16, code Android 22, paquet fr.erick.journallocal. Signature historique conservée. Installer par-dessus l’application existante.

## Nouvelle formule

Chaque application part de zéro. La base H est le nombre de permissions individuelles supplémentaires par rapport à la vue de référence choisie. Les mots « permissions » et « applications » sont distincts : 70 permissions réelles contre 10 visibles donnent H = 60, et non 60 applications.

- L1 : +1 par permission moins visible.
- L2 : actions à l’insu de l’utilisateur; facteur max(1, 2 × nombre de constats distincts).
- L3 : actions à son insu accompagnées d’un avertissement Android documenté; facteur max(1, 3 × nombre de constats distincts).
- L4 : capacité de partage/gestion de capacités pour d’autres applications. Chaque capacité distincte multiplie par sa portée. Par défaut, la portée est le nombre de paquets inventoriés dans le même profil. C’est une pondération du potentiel, pas la preuve d’un partage effectif à chaque paquet.

M = F2 × F3 × produit des portées L4. P = H × M.

Exemple demandé : 60 × (2 × 4) × (3 × 2) × 200 = 576 000. Le cercle affiche **60**, avec **×9 600** au-dessus. Une autre capacité L4 de portée 500 donne ×4 800 000 et 288 000 000 points pondérés. Les facteurs restent neutres à 1 quand aucun constat applicable n’est présent.

Les constats doivent concerner le moins visible : nom de permission présent parmi les candidats de la référence estimée, ou `hidden:true` explicitement justifié dans le constat. Une référence manuelle ne permet pas à elle seule de savoir quelles permissions sont cachées; le lien doit être renseigné. Les versions périmées et capacités explicitement inactives sont écartées. Les doublons d’une même permission à un même niveau ne gonflent pas le résultat. Deux portées contradictoires d’une même capacité L4 restent signalées avec un facteur neutre.

La liste de règles automatiques reste vide par défaut : cette version ne fabrique pas des preuves d’actions autonomes, d’avertissements ou de partage à partir des seuls noms des permissions. Une application peut donc afficher une grosse base et ×1 tant que ses niveaux supérieurs ne sont pas documentés. Un zéro ou ×1 ne constitue pas une certification d’innocuité.

## Groupes et global

Le nombre central est la **somme des bases H**, sans moyenne par application. Le multiplicateur du groupe est ΣP / ΣH, uniquement sur les applications évaluées avec H > 0. Ainsi ΣH × multiplicateur = ΣP exactement avant arrondi. On ne multiplie pas entre elles les pénalités d’applications indépendantes. Les applications sans écart ou inconnues ne diluent pas ce rapport.

Le multiplicateur d’un groupe peut être décimal et est affiché à deux décimales; le rapport exact numérateur/dénominateur est conservé. Les couleurs sont calculées sur le rapport exact, avant arrondi. Un groupe sans données évaluables affiche —; un groupe évalué sans écart affiche 0 et ×1.

## Couleurs et affichage

Même règle pour application, groupe et global : multiplicateur <2 vert; de 2 à moins de 4 jaune; de 4 à moins de 6 orange; de 6 à moins de 8 rouge; à partir de 8 critique. Les seuils restent modifiables dans Barème AIV et au même endroit que R1 à R6 : Menu → Décisions et règles → Règles locales versionnées → Couleurs des points AIV. Les deux formulaires partagent les mêmes réglages; l’enregistrement recalcule immédiatement sans nouvelle APK. Le ratio réel/visible reste descriptif dans la fiche, sans rôle dans la couleur.

Chiffres agrandis et placés au-dessus du fond des petits cercles. Multiplicateur dans un cartouche visible au-dessus du disque. À partir du seuil critique, disque rouge avec barre diagonale et multiplicateur pulsant lentement; l’option d’animation et la préférence système de mouvement réduit sont respectées. Les groupes s’empilent sur petit écran pour rester lisibles. Les très longs nombres utilisent une notation scientifique compacte dans les petits espaces; les valeurs exactes restent dans le détail.

## Réglages et migration

Le barème utilise aiv-penalty-policy/2 et accepte les anciens fichiers /1. L’ancien multiplicateur numérique L4 est remplacé par la portée configurée. Les réglages et observations L5 sont conservés pour consultation mais ne multiplient plus automatiquement : la nouvelle formule demandée comporte quatre niveaux. Il faut requalifier explicitement un ancien constat en L4 lorsque le partage de capacité est établi. Une source d’installation ne prouve pas à elle seule cette capacité.

L4 est configurable : installed_app_count, fixed ou disabled. Un constat peut fournir `share_count` pour sa propre portée. Exemple :

```json
{"id":"partage-1","permission":"nom.exact.permission","levels":[4],"hidden":true,"share_count":200,"source":"Référence ou capture vérifiée","reason":"Description précise de la capacité de partage et de sa portée","version_code":1,"observed_at":"2026-09-23T12:00:00Z"}
```

Ne pas copier ce constat d’exemple comme une preuve réelle. Renseigner les données observées. Le mode disabled neutralise toutes les portées L4.

## Référence visuelle retrouvée

Ancienne adresse retrouvée dans les échanges : https://all-invisible-aiv-demo.willingemy.chatgpt.site

L’accès au site depuis l’environnement de travail retourne 403; le dépôt source nommé dans les anciens échanges n’est pas accessible avec la connexion actuelle. L’affichage actuel du site n’a donc pas été vérifié ni copié. Les prototypes sauvegardés `aiv_mode_utilisateur_prototype.html` et `aiv_mode_ti_prototype.html` fournissent le fond sombre, le turquoise #55d9d5 et les cartes arrondies. La V16 reprend cette base et ajoute les accents rose-mauve Watcher et halos néon décrits par Erick, ainsi qu’un rouge critique saturé. Les écrans de démonstration existants restent identifiés comme simulations.

## Vérifications et limites

Tests du modèle : exemple 60 × 9 600, empilement de portées 200 et 500, rapport exact des groupes, seuils de couleur identiques, absence de dilution, profils, déduplication, provenance, migration et entiers dépassant la précision des nombres JavaScript ordinaires. Tests d’interface avec pont Android simulé : grands nombres/multiplicateurs présents, édition/import/export des réglages, référence et recalcul, journal stable.

Compilation Java/native, vérification de la signature et de la version. Pas de test sur téléphone physique. L’aperçu visuel dans le navigateur distant n’a pas pu être ouvert, sa politique bloquant les fichiers locaux; la validation d’interface réalisée est une simulation DOM, pas une capture d’écran Android.

La V15 reste la référence pour l’actualisation locale et les exports compacts : aucun rafraîchissement périodique du journal, historique préservé, dernier inventaire exportable séparément. Aucun journal n’est transmis au site de démo, à Drive, Supabase ou à cette conversation par l’APK.
