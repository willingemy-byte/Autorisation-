# AIV 0.6.14 — pénalités locales et barème modifiable

Version Android : `0.6.14`, code `20`, paquet `fr.erick.journallocal`.

## Installer et commencer

1. Installer `AIV-0.6.14-signed.apk` comme mise à jour de Journal local.
2. Ouvrir **Accueil → Actualiser**. Cette action refait l’inventaire local, avec les sources d’installation accessibles.
3. Ouvrir une application. Dans **Pénalité AIV**, renseigner séparément la vue principale et « Toutes les autorisations » : nombre, unité, source/capture, confirmation de la version.
4. Ajouter les constats L2–L5 documentés ou des règles dans **Menu → Barème AIV → Réglages complets en JSON**.
5. Ajuster les multiplicateurs, la vue de référence et les seuils dans **Barème AIV**. Enregistrer recalcule immédiatement; aucune recompilation ni connexion serveur n’est nécessaire.

Les données manquantes apparaissent « non évaluées ». Un premier écran sans score calculable est normal si aucune référence de visibilité comparable n’est encore renseignée. Les références Play antérieures restent exploitables lorsque leur unité, leur source et leur version correspondent. Les applications sans écart ne reçoivent pas un score de 100 % : elles ont zéro pénalité et restent exclues de la moyenne.

## Calcul

`R` compte les noms distincts des permissions demandées/déclarées du dernier inventaire. Une permission déclarée n’est pas automatiquement accordée ou utilisée. Les champs accordé/refusé/inconnu restent accessibles dans le dossier.

`V_principal` et `V_toutes` restent séparés. Le barème choisit `principal` ou `toutes` pour `V`.

```
H = R − V
F2 = max(1, poids_L2 × nombre_L2)
F3 = max(1, poids_L3 × nombre_L3)
F4 = max(1, poids_L4 × nombre_L4)
F5 = max(1, K) si un constat L5 actif est confirmé
P = H × F2 × F3 × F4 × F5
Indice = somme(P) / nombre d’applications avec H > 0
```

Poids initiaux L2/L3/L4 : 2/3/4. L5 peut utiliser le nombre de paquets reliés, une valeur fixe ou être désactivé. Un poids zéro neutralise le niveau concerné; aucun facteur ne descend sous 1.

Exemple : `88 × 4 × 3 × 4 × 5 = 21 120`. Avec 70 paquets reliés : `295 680`.

Les produits et sommes sont calculés en entiers exacts (`BigInt`), exportables comme chaînes décimales. La moyenne est affichée avec au plus deux décimales, arrondie au centième. Il n’y a pas de plafonnement à 100 ni de conversion implicite en pourcentage.

Une référence manquante, une autre version ou un comptage de groupes au lieu de permissions individuelles ne produit pas de zéro artificiel. V > R et V_toutes < V_principal sont signalés comme contradictions; aucun nombre n’est choisi arbitrairement.

## Niveaux et preuves

- L1 : écart de visibilité H.
- L2 : capacité autonome documentée, sélectionnée dans un constat ou une règle.
- L3 : avertissement documenté, sélectionné dans un constat ou une règle.
- L4 : capacité de contrôle d’autres applications documentée, sélectionnée dans un constat ou une règle.
- L5 : accès spécial hors de la surface habituelle des permissions, observé actif et documenté.

**Le catalogue automatique est vide au départ.** Le texte fourni définit les niveaux, mais ne donne pas une liste exhaustive de permissions à chacun. Cette version fournit le moteur et les outils pour ajouter ces règles avec leurs sources; elle n’invente pas un catalogue d’autonomie ou de danger. Les constats peuvent être saisis dans chaque dossier. Ils conservent leur version et leur date et deviennent exclus du calcul si la version change. Une même permission compte une fois par niveau, même si plusieurs règles la décrivent.

Pour L5, les champs `active: true` et `outside_permissions: true` sont nécessaires. L’état des accès spéciaux des autres applications n’est pas supposé connu : cette application ordinaire ne transforme pas une permission de manifeste en accès spécial actif. Un constat utilisateur peut documenter la capture du réglage.

Exemple de constat à saisir dans le dossier de l’application (remplacer la version, la date et la source par celles observées) :

```json
{
  "id": "installation-source-observee",
  "levels": [5],
  "source": "Capture locale du réglage, date et nom du fichier",
  "reason": "Accès spécial d’installation observé actif hors de la liste habituelle",
  "active": true,
  "outside_permissions": true,
  "version_code": 123,
  "observed_at": "2026-09-23T10:00:00Z"
}
```

Une règle vise soit `permission` (nom exact), soit `prefix`, et porte un tableau `levels` (2, 3, 4), une `source`, une `reason`, un identifiant unique, `require_granted` facultatif et `enabled` facultatif. Les règles ne peuvent pas déclarer automatiquement L5 actif. Tout reste du JSON de données; aucun script importé n’est exécuté.

## Relations d’installation : ce que K compte

`PackageManager.getInstallSourceInfo()` est interrogé à partir d’Android 11 (API 30). Sur les versions précédentes, seul l’installateur enregistré accessible par l’ancienne API est conservé. Les champs suivants restent séparés :

- `initiating_package` : initiateur de l’installation/mise à jour exposée;
- `installing_package` : installateur enregistré, valeur modifiable dans Android;
- `update_owner_package` : responsable des mises à jour, lorsqu’exposé (API 34+);
- `originating_package` : origine déclarée par l’initiateur, non vérifiée par Android et exclue de K.

K compte **les paquets directement reliés, distincts, dans le même profil**. Une application citée comme installée, initiée et gérée ne compte qu’une fois. La relation et sa source sont visibles dans le dossier; ce n’est pas une reconstruction complète de l’historique. Les liens transitifs, les noms de famille Meta/Samsung, les domaines communs, les certificats communs et les UID communs ne deviennent pas des preuves d’installation.

Une source indisponible est conservée avec une raison : `ANDROID_NOT_EXPOSED`, `PACKAGE_NOT_VISIBLE`, `ANDROID_ACCESS_DENIED`, ou couverture ancienne/incomplète. Les anciens inventaires doivent être actualisés pour obtenir ces nouveaux champs.

Documentation de l’API : https://developer.android.com/reference/android/content/pm/InstallSourceInfo

## Couleurs

Couleurs individuelles par ratio R/V : vert <2, jaune ≥2, orange ≥4, rouge ≥6, critique ≥8. R>0 et V=0 donne un ratio infini; R=V=0 donne une comparaison sans écart. L5 actif peut imposer la couleur critique même lorsque H est inconnu ou nul. Cela ne fait pas entrer H=0 dans la moyenne.

L’indice global utilise des seuils de points distincts et modifiables : 100/1 000/10 000/100 000 au départ. **Ce sont des valeurs initiales de présentation choisies pour cette version, pas des seuils convenus antérieurement ni une mesure scientifique du danger.** Les ratios et les points ne sont pas confondus.

Le symbole critique peut être animé ou fixe. L’animation respecte également la préférence système de réduction des mouvements.

## Import/export et stockage

**Barème AIV → Exporter mes réglages** produit un petit JSON avec la politique et les observations enregistrées pour le nouveau moteur. Il ne contient ni le million d’événements ni les secrets de signature. L’export complet des autorisations conserve aussi la nouvelle table de configuration.

L’import accepte une politique seule (`aiv-penalty-policy/1`) ou un ensemble de réglages (`aiv-penalty-settings/1`). Il affiche une prévisualisation; **Appliquer le JSON** effectue l’enregistrement. Les dossiers importés se fusionnent par nom de paquet; les autres dossiers sont conservés. Pour vider un dossier, importer explicitement son objet avec `visibility: {}` et `findings: []` (ou modifier ses champs dans la fiche). Les dossiers d’autres versions restent identifiés comme périmés.

Le retour au barème par défaut prépare une prévisualisation et conserve les observations. Il faut l’appliquer pour modifier la politique active. Les réglages s’enregistrent dans la base privée `permission-audit.sqlite`, ajout d’une table à la migration 1→2. Les tables existantes sont conservées. Le journal réseau reste dans sa base existante.

## Gallery et `com.sec.spp.permission.TOKEN_…`

Cette chaîne est un **nom de permission personnalisée**. Sa longue partie hexadécimale ne suffit pas à établir qu’il s’agit d’un secret utilisable, ni à démontrer une capacité de contrôle ou d’exécution distante. Le préfixe est compatible avec l’espace de noms Samsung SPP; Samsung publie son service de notifications sous `com.sec.spp.push`. La documentation publique consultée ne décrit pas la sémantique de ce TOKEN précis.

Dans **Applications → Gallery → autorisations déclarées**, ouvrir cette permission pour lire **Définie par**, **Protection**, et **accordée/non accordée/inconnue**. Ces métadonnées Android permettent d’aller plus loin que le nom. Si Android ne fournit pas la définition, elle reste inconnue. Aucun surclassement L2–L5 automatique n’est déclenché par le mot TOKEN.

Références :
- Permissions personnalisées Android : https://developer.android.com/guide/topics/permissions/defining
- Fiche officielle Samsung Push Service : https://play.google.com/store/apps/details?id=com.sec.spp.push

## Vérification de cette livraison

- Compilation des sources Java et natives arm64-v8a/x86_64 avec SDK 35, NDK r27d et ECJ 3.40.0.
- APK vérifié par `apksigner`, signatures v2/v3; même certificat SHA-256 que la V13 fournie : `4a14b9e2cf3869fa9faf2317cba96e948145e4dba32240f9547380c040deba7b`.
- Tests du moteur : exemples 5/70 liens, exclusion des zéros/inconnus, contradictions, références périmées, déduplication, profils, neutralisation L5, grands nombres et absence de surclassement automatique des TOKEN.
- Tests d’interface avec pont simulé : accueil, groupes, fiches, références, prévisualisation, import/appliquer/export, conservation de l’ancienne configuration en cas d’erreur, actualisation locale et retour TI.
- Test de régression de l’événement Photos : le groupe est lu depuis `original.details` après normalisation. L’ancienne V13 cherchait au mauvais niveau et affichait Android/non attribuable.
- Le test historique `native-reader.cjs` échoue aussi sur les sources V13 intactes au contrôle du rafraîchissement automatique : il reste sur l’accueil alors que ce contrôle vise le journal. Ce résultat préexistant est conservé, sans le présenter comme une réussite.

**Aucun test sur ton Samsung ni émulateur Android n’a été effectué dans cette session.** Les données d’installation et la migration sur ta base réelle restent à vérifier avec l’APK. Les tests d’interface utilisent des données simulées, jamais présentées comme tes applications réelles.

## Recompiler

La compilation complète utilise `bootstrap-clean-build.sh` avec un dossier d’outils accessible et la clé historique située hors des sources. Les téléchargements sont vérifiés par les empreintes de `docs/build-toolchain.json`. Le script ne crée pas de clé de remplacement. `AIV_BUILD_MODE=unsigned` produit uniquement l’APK non signé; pour une mise à jour installable, réutiliser le certificat historique.

Tests ajoutés :
```
node tests/penalty-model.cjs
NODE_PATH=/chemin/vers/jsdom-26.1.0/node_modules node tests/penalty-ui.cjs
```

Le fichier `app/src/main/assets/journal.html` est généré à partir de `tools/` par `tools/connect_reader.py`; modifier les sources dans `tools/`, puis regénérer le lecteur.
