  const penaltyColors={unknown:'#87949e',green:'#47d89f',yellow:'#e3c35b',orange:'#ef9a4d',red:'#ff5964',critical:'#ff3344'};
  let penaltyCache=null,penaltyImportTimer=0;
  function penaltyRead(method,...args){const raw=nativeBridge&&nativeBridge[method]&&nativeBridge[method](...args);if(!raw)throw Error('Ce calcul nécessite AIV 0.6.14.');const r=JSON.parse(raw);if(r.error)throw Error(r.error);return r;}
  function penaltySettings(){const c=penaltyRead('penaltyConfig');c.policy=PenaltyModel.validatePolicy(c.policy||{});c.references=c.references||{};return c;}
  function penaltyValidateSettings(c){
    if(c.schema!=='aiv-penalty-settings/1'||!c.references||typeof c.references!=='object'||Array.isArray(c.references))throw Error('Format attendu : aiv-penalty-settings/1');
    if(Object.keys(c).some(k=>!['schema','policy','references'].includes(k)))throw Error('Champ de configuration inconnu');
    c.policy=PenaltyModel.validatePolicy(c.policy);
    for(const [pkg,e] of Object.entries(c.references)){if(!/^[A-Za-z0-9_]+(?:\.[A-Za-z0-9_]+)*$/.test(pkg))throw Error('Paquet invalide');c.references[pkg]=PenaltyModel.validateEvidence(e);}
    return c;
  }
  function penaltySave(c){penaltyRead('penaltySave',JSON.stringify(penaltyValidateSettings(c)));penaltyCache=null;}
  function penaltySnapshot(input,settings){
    const stable=x=>Array.isArray(x)?x.map(stable):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,stable(x[k])])):x;
    // Scan identifiers/times are not evidence changes. Every app field and reference is.
    const identity=JSON.stringify(stable({engine:'aiv-penalty/0.6.19-snapshots-1',apps:input.apps,references:input.references,policy:settings.policy}));
    if(nativeBridge.calculationLoad){const saved=penaltyRead('calculationLoad',identity);if(saved.cached&&saved.result?.schema==='aiv-penalty-result/2')return {...saved.result,scan_id:input.scan_id};}
    const result=PenaltyModel.evaluate(input,settings.policy);
    if(nativeBridge.calculationSave){try{penaltyRead('calculationSave',identity,JSON.stringify(result));}catch(e){penaltyStatus('Calcul terminé; instantané non enregistré : '+e.message);}}
    return result;
  }
  function penaltyLoad(force=false){
    if(!penaltyCache||force){const input=penaltyRead('penaltyData'),settings=penaltySettings();penaltyCache={input,settings,result:penaltySnapshot(input,settings)};}
    return penaltyCache;
  }
  function penaltyNumber(value){if(value===null||value===undefined)return '—';const [whole,fraction]=String(value).split('.');return whole.replace(/\B(?=(\d{3})+(?!\d))/g,' ')+(fraction&&fraction!=='00'?','+fraction:'');}
  function penaltyCompact(value){
    if(value===null||value===undefined)return '—';
    const [whole]=String(value).split('.');
    if(whole.length<=6)return penaltyNumber(value);
    return whole[0]+','+whole.slice(1,3)+'e'+(whole.length-1);
  }
  function penaltyDisc(disc,row,policy){
    disc.dataset.penaltyColor=row.color;
    let badge=disc.querySelector('.jp-multiplier');if(!badge){badge=element('span',undefined,'jp-multiplier');disc.append(badge);}
    badge.textContent=row.multiplier===null?'× —':'×'+penaltyCompact(row.multiplier);
    badge.title='Multiplicateur : '+penaltyNumber(row.multiplier)+(row.multiplier_denominator?' ; rapport exact '+row.multiplier_numerator+'/'+row.multiplier_denominator:'');
    badge.classList.toggle('jp-critical-symbol',row.color==='critical'&&policy.colors.blink_critical);
  }
  function penaltyButton(label,action){const b=element('button',label);b.type='button';b.onclick=action;return b;}
  function penaltyStatus(text){$('jp-status').textContent=text;}
  function renderPenaltyColors(){
    const box=$('aiv-score-colors');if(!box)return;
    box.replaceChildren();
    try{
      const settings=penaltySettings(),keys=['yellow_ratio','orange_ratio','red_ratio','critical_ratio'],fields=[];
      keys.forEach((key,i)=>{const label=element('label',['Jaune à partir de ×','Orange à partir de ×','Rouge à partir de ×','Critique à partir de ×'][i]),input=element('input');input.type='number';input.step='any';input.min='0';input.value=settings.policy.colors[key];input.dataset.colorKey=key;label.append(input);box.append(label);fields.push(input);});
      const status=element('p');status.setAttribute('role','status');
      box.append(penaltyButton('Enregistrer les couleurs',()=>{try{
        const fresh=penaltySettings();keys.forEach((key,i)=>{fresh.policy.colors[key]=Number(fields[i].value);});
        penaltySave(fresh);const updated=penaltyLoad(true).result.summary;
        status.textContent='Couleurs enregistrées et recalculées : '+penaltyNumber(updated.base)+' points de base × '+penaltyNumber(updated.multiplier)+'.';
      }catch(e){status.textContent=e.message;}}),status);
    }catch(e){box.append(element('p',e.message));}
  }
  function renderPenaltySettings(){
    try{
      const c=penaltySettings(),p=c.policy,box=$('jp-controls');box.replaceChildren();
      const make=(label,value,type='number')=>{const l=element('label',label),i=element('input');i.type=type;if(type==='checkbox')i.checked=value;else i.value=value;i.min='0';l.append(i);box.append(l);return i;};
      const select=(label,choices,value)=>{const l=element('label',label),i=element('select');for(const [v,t]of choices)i.append(new Option(t,v));i.value=value;l.append(i);box.append(l);return i;};
      const auto=make('Détecter automatiquement les capacités documentées',p.automatic.enabled,'checkbox');
      const routes=make('Détecter les accès potentiels entre applications',p.automatic.component_links,'checkbox');
      const descriptions=make('Détecter les mentions explicites d’autonomie dans les descriptions Android',p.automatic.android_descriptions,'checkbox');
      const warnings=make('Compter les avertissements Android observés en L3',p.automatic.android_warnings,'checkbox');
      const derived=make('Référence locale estimée quand aucune observation n’est renseignée',p.derived_reference,'checkbox');
      const view=select('Vue de référence',[['principal','Vue principale'],['toutes','Toutes les autorisations']],p.visibility);
      const weights=[2,3].map(n=>make('Multiplicateur de niveau '+n,p.multipliers['level'+n]));
      const mode=select('L4 · portée par capacité de partage',[['installed_app_count','Tous les paquets du profil (potentiel)'],['fixed','Valeur fixe'],['disabled','Désactivé']],p.multipliers.level4.mode);
      const fixed=make('Portée fixe L4 (si choisie)',p.multipliers.level4.fixed);
      const combination=select('Combiner les capacités L4',[['sum','Additionner les portées'],['product','Multiplier les portées (ancien calcul)']],p.multipliers.level4.combination);
      const l5mode=select('L5 confirmé : portée installation',[['linked_packages','Paquets reliés par une source Android'],['fixed','Valeur fixe'],['disabled','Désactivé']],p.multipliers.level5.mode);
      const l5fixed=make('Portée fixe L5',p.multipliers.level5.fixed);
      const ratioKeys=['yellow_ratio','orange_ratio','red_ratio','critical_ratio'];
      const ratio=ratioKeys.map((k,i)=>make(['Multiplicateur jaune','Multiplicateur orange','Multiplicateur rouge','Multiplicateur critique'][i],p.colors[k]));
      const blink=make('Animer le symbole critique',p.colors.blink_critical,'checkbox');
      box.append(penaltyButton('Enregistrer et recalculer',()=>{try{
        const fresh=penaltySettings();fresh.policy.visibility=view.value;fresh.policy.derived_reference=derived.checked;
        fresh.policy.automatic.android_descriptions=descriptions.checked;fresh.policy.automatic.enabled=auto.checked;fresh.policy.automatic.component_links=routes.checked;fresh.policy.automatic.android_warnings=warnings.checked;fresh.policy.multipliers.level4.combination=combination.value;fresh.policy.multipliers.level5.mode=l5mode.value;fresh.policy.multipliers.level5.fixed=Number(l5fixed.value);
        weights.forEach((w,i)=>{fresh.policy.multipliers['level'+(i+2)]=Number(w.value);});
        fresh.policy.multipliers.level4.mode=mode.value;fresh.policy.multipliers.level4.fixed=Number(fixed.value);
        ratio.forEach((w,i)=>{fresh.policy.colors[ratioKeys[i]]=Number(w.value);});
        fresh.policy.colors.blink_critical=blink.checked;
        penaltySave(fresh);renderPenaltySettings();penaltyStatus('Réglages enregistrés. Les résultats ont été recalculés.');
      }catch(e){penaltyStatus(e.message);}}));
      $('jp-json').value=JSON.stringify(c,null,2);$('jp-preview').textContent='';
    }catch(e){penaltyStatus(e.message);}
  }
  function penaltyPreview(){const c=penaltyValidateSettings(JSON.parse($('jp-json').value)),current=penaltyLoad(),input=JSON.parse(JSON.stringify(current.input));
    for(const [pkg,e]of Object.entries(c.references)){input.references[pkg]={...(input.references[pkg]||{}),penalty_evidence:e};}
    const r=PenaltyModel.evaluate(input,c.policy);$('jp-preview').textContent=`Prévisualisation : ${penaltyNumber(r.summary.base)} points de base × ${penaltyNumber(r.summary.multiplier)} · ${r.summary.concerned} applications avec caché · ${r.summary.unknown} non évaluées.\nPénalité cumulée : ${penaltyNumber(r.summary.sum)}. Aucun réglage appliqué.`;return c;}
  $('jp-validate').onclick=()=>{try{penaltyPreview();penaltyStatus('Configuration valide.');}catch(e){penaltyStatus(e.message);}};
  $('jp-apply-json').onclick=()=>{try{penaltySave(penaltyPreview());renderPenaltySettings();penaltyStatus('Configuration appliquée.');}catch(e){penaltyStatus(e.message);}};
  $('jp-reset').onclick=()=>{try{const c=penaltySettings();c.policy=PenaltyModel.defaults();$('jp-json').value=JSON.stringify(c,null,2);$('jp-json').closest('details').open=true;penaltyPreview();penaltyStatus('Barème par défaut préparé; tes observations restent présentes. Appuie sur Appliquer le JSON pour le choisir.');}catch(e){penaltyStatus(e.message);}};
  $('jp-export').onclick=()=>{try{const c=penaltySettings();penaltySave(c);nativeBridge.command('export-penalty');penaltyStatus('Choisis où enregistrer le fichier de réglages.');}catch(e){penaltyStatus(e.message);}};
  function penaltyCheckImport(){try{if(!nativeBridge||!nativeBridge.penaltyImported)return;const value=nativeBridge.penaltyImported();if(!value)return;
    const incoming=JSON.parse(value);const c=['aiv-penalty-policy/1','aiv-penalty-policy/2','aiv-penalty-policy/3'].includes(incoming.schema)?{...penaltySettings(),policy:incoming}:incoming;
    penaltyValidateSettings(c);const fresh=penaltySettings();c.references={...fresh.references,...c.references};
    $('jp-json').value=JSON.stringify(c,null,2);$('jp-json').closest('details').open=true;penaltyPreview();penaltyStatus('Fichier lu. Vérifie la prévisualisation puis applique le JSON.');
    clearInterval(penaltyImportTimer);penaltyImportTimer=0;
  }catch(e){penaltyStatus('Import refusé : '+e.message);clearInterval(penaltyImportTimer);penaltyImportTimer=0;}}
  $('jp-import').onclick=()=>{nativeBridge.command('import-penalty');clearInterval(penaltyImportTimer);let ticks=0;penaltyImportTimer=setInterval(()=>{penaltyCheckImport();if(++ticks>300){clearInterval(penaltyImportTimer);penaltyImportTimer=0;}},1000);};
  function renderPenaltyHome(){
    try{
      const scan=penaltyRead('auditSummary');if(penaltyCache&&penaltyCache.input.scan_id!==scan.scan_id)penaltyCache=null;
      const {result:r,input}=penaltyLoad(),g=r.summary,p=r.policy,ring=$('jc-score-ring'),list=$('jc-home-app-list');
      $('jc-endpoint-config').hidden=true;$('jc-pane-home').dataset.lowScore=String(g.color==='critical');$('jc-pane-home').style.background='';
      $('jc-mode-banner').textContent='Départ à zéro. +1 point par permission moins visible. Les niveaux 2 à 5 sont comptés séparément; le multiplicateur détermine la couleur.';
      $('jc-home-eyebrow').textContent='Indice de pénalité AIV';$('jc-score-label').textContent='moyenne par application avec écart';
      $('jc-score-number').textContent=penaltyCompact(g.base_mean);$('jc-score-number').title=penaltyNumber(g.base_mean);$('jc-score-number').style.fontSize='';penaltyDisc(ring,g,p);
      ring.style.setProperty('--score-color',penaltyColors[g.color]);ring.style.setProperty('--score-angle',g.base===null?'0deg':'360deg');ring.setAttribute('aria-label',penaltyNumber(g.base_mean)+' points moyens de base, multiplicateur '+penaltyNumber(g.multiplier));
      $('jc-home-title').textContent=g.concerned?`${g.concerned} applications avec du caché sur ${g.total}`:'Aucune application avec caché évalué pour le moment';
      $('jc-home-sub').textContent=`${penaltyNumber(g.base)} écarts ÷ ${g.concerned} applications concernées = ${penaltyNumber(g.base_mean)} de moyenne. Cumul pondéré : ${penaltyNumber(g.base)} × ${penaltyNumber(g.multiplier)}${g.base&&g.multiplier_numerator && BigInt(g.multiplier_numerator)%BigInt(g.multiplier_denominator)!==0?' (arrondi)':''} = ${penaltyNumber(g.sum)} points pondérés. ${g.zero} sans écart et ${g.unknown} non évaluées restent hors du calcul du multiplicateur.`;
      $('jc-home-alert').style.setProperty('--score-color',penaltyColors[g.color]);$('jc-home-alert-title').textContent='Composition et portée du résultat';
      $('jc-home-alert-text').textContent=`L2 : ${g.levels[2]} apps · L3 : ${g.levels[3]} · L4 : ${g.levels[4]} · L5 : ${g.levels[5]}. Maximum individuel : ${penaltyNumber(g.maximum)} points. ${p.name}. Les points sont une pondération AIV, pas un pourcentage de danger.`;
      const ids=['jc-home-total','jc-home-evaluated','jc-home-unknown','jc-home-findings','jc-home-app-count'];
      [g.total,g.concerned,g.unknown,g.hidden,g.zero].forEach((v,i)=>{$(ids[i]).textContent=penaltyNumber(v);});
      ['paquets inventoriés','avec écart · incluses','non évalués','éléments moins visibles','sans écart · exclus'].forEach((v,i)=>{$(['jc-home-counter-0','jc-home-counter-1','jc-home-counter-u','jc-home-counter-2','jc-home-counter-3'][i]).textContent=v;});
      const holder=$('jc-group-rings');holder.replaceChildren();
      for(const group of r.groups){const b=penaltyButton('',()=>{homeGroup=group.id;homeLimit=25;renderPenaltyHome();});b.className='jc-group-card';b.dataset.group=group.id;b.setAttribute('aria-pressed',String(homeGroup===group.id));
        const disc=element('span',undefined,'jc-group-disc');disc.style.setProperty('--score-color',penaltyColors[group.color]);disc.style.setProperty('--score-angle',group.base===null?'0deg':'360deg');const number=element('strong',penaltyCompact(group.base_mean),'jp-group-number');number.title=penaltyNumber(group.base_mean);disc.append(number);penaltyDisc(disc,group,p);
        b.append(element('strong',groupNames[group.id]),disc,element('span',`Moyenne sans multiplicateur · ${group.concerned} / ${group.total} avec écart · ${group.unknown} inconnues`,'jc-group-meta'));holder.append(b);}
      $('jc-home-list-title').textContent=groupNames[homeGroup]+' · pénalités décroissantes';
      const q=$('jc-home-search').value.trim().toLocaleLowerCase('fr');const rows=r.apps.filter(a=>(homeGroup==='all'||a.group===homeGroup)&&(!q||[a.label,a.package_name].join(' ').toLocaleLowerCase('fr').includes(q)));
      list.replaceChildren();for(const a of rows.slice(0,homeLimit)){const b=penaltyButton('',()=>{setTab('audit');renderAuditDetail(a.package_name);});b.className='jc-home-app';b.dataset.package=a.package_name;
        const info=element('span');info.append(element('strong',a.label),element('span',groupNames[a.group]+' · '+a.package_name+' · UID '+(a.uid??'inconnu'),'jc-sub'),element('span',a.H===null?a.reason:`${a.H} moins visibles${a.estimated ? " (estimation)" : ""}${a.coverage_partial?' · analyse partielle':''}`,'jc-sub'));
        const impact=element('span',a.points===null?'Non évaluée':penaltyNumber(a.H)+' pts de base','jc-home-impact');if(a.H!==null){const multiplier=element('strong','×'+penaltyCompact(a.multiplier),'jp-app-multiplier');multiplier.title='Multiplicateur exact : ×'+penaltyNumber(a.multiplier);if(a.color==='critical'&&p.colors.blink_critical)multiplier.classList.add('jp-critical-symbol');impact.append(multiplier,element('small',penaltyCompact(a.points)+' points pondérés'));}b.dataset.penaltyColor=a.color;impact.style.setProperty('--home-app-color',penaltyColors[a.color]);
        if(a.color==='critical'){const symbol=element('span',' ⊘');symbol.className=p.colors.blink_critical?'jp-critical-symbol':'';symbol.setAttribute('aria-label','Critique');impact.append(symbol);}b.append(info,impact);list.append(b);}
      if(!rows.length)list.append(element('p','Aucune application pour ce filtre.','jc-sub'));
      $('jc-group-all').setAttribute('aria-pressed',String(homeGroup==='all'));$('jc-home-more').hidden=rows.length<=homeLimit;
      $('jc-home-note').textContent=r.apps.filter(a=>a.estimated).length+' applications utilisent une référence estimée, actualisée avec l’inventaire. Les observations saisies restent prioritaires. R correspond aux permissions déclarées dans le manifeste. H mesure leur écart avec une référence de visibilité comparable. Une possibilité déclarée ne démontre pas son utilisation. Les sources absentes restent inconnues.';
      $('jc-refresh-status').textContent=input.scan_id?`Inventaire ${input.scan_id} · calcul local · Paramètres → Barème AIV pour ajuster les règles.`:'Appuie sur Actualiser pour relever les applications, la référence locale sera calculée automatiquement.';
      $('jc-home-refresh').disabled=Boolean(input.busy);$('jc-home-refresh').textContent=input.busy?'Inventaire…':'Actualiser';
    }catch(e){$('jc-score-number').textContent='—';$('jc-home-title').textContent='Calcul indisponible';$('jc-home-sub').textContent=e.message;}
  }
  function renderPenaltyDetail(pane,pkg){
    const box=element('section',undefined,'ja-card');box.id='jp-app-detail';
    try{
      const current=penaltyLoad(),row=current.result.apps.find(a=>a.package_name===pkg);if(!row)throw Error('Paquet absent du dernier inventaire');
      const raw=current.input.apps.find(a=>a.package_name===pkg),reference=current.input.references[pkg]||{},saved=reference.penalty_evidence||{};
      if(row.estimated)box.append(element('p','Référence estimée automatiquement — calibration V6 et dernier inventaire. Ce nombre ne mesure pas directement les écrans de permissions Android.'));
      box.append(element('h3','Pénalité AIV · '+(row.points===null?'non évaluée':penaltyNumber(row.H)+' points de base × '+penaltyNumber(row.multiplier))));
      box.append(element('p',row.H===null?row.reason:`${row.H} moins visibles × ${row.factors[0]} L2 × ${row.factors[1]} L3 × ${row.factors[2]} L4 × ${row.factors[3]} L5 = ${penaltyNumber(row.points)} points`));
      box.append(element('p',`R : ${row.R} permissions déclarées · vue principale : ${row.layers.principal.value??'inconnue'} · toutes : ${row.layers.toutes.value??'inconnue'}.`));
      box.append(element('p',`Écart principal : ${row.layers.principal.hidden??'inconnu'} · écart toutes : ${row.layers.toutes.hidden??'inconnu'}. Ratio descriptif réel/visible : ${row.ratio??'inconnu'} (ne détermine pas la couleur).`,'jc-sub'));
      for(const factor of row.share_factors)box.append(element('p',`L4 · ${factor.identity} : ×${penaltyNumber(factor.factor)} — ${factor.scope}`));
      box.append(element('p','Composants : '+(row.components_collected?'inventoriés':'ancien relevé, actualiser')+'. '+(row.coverage_partial?'Analyse partielle : des capacités restent non classifiées. ×1 ne constitue pas une validation.':'Les règles disponibles ont été examinées.'),'jc-note'));
      const routeDetails=element('details');routeDetails.append(element('summary','Accès interapplications potentiels · '+row.routes.length+' permissions de passage'));
      for(const route of row.routes){routeDetails.append(element('h4',route.permission+' · '+route.clients.length+' paquets distincts'),element('p',route.scope));
        for(const c of route.components)routeDetails.append(element('p',c.type+' · '+c.name+' · '+c.operation+(c.path_restrictions?' · restrictions par chemin':'')));
        for(const client of route.clients)routeDetails.append(element('p',(client.label||client.package_name)+' · '+client.package_name+' · UID '+client.uid));}
      routeDetails.append(element('p','Un client qui détient la permission ne reçoit pas toutes les capacités du fournisseur. Ces liens ne prouvent pas un appel exécuté ni une délégation de permissions. Les clients d’un même UID ou d’un autre profil sont exclus.'));
      box.append(routeDetails);
      const unc=element('details');unc.append(element('summary','Permissions moins visibles non classifiées · '+row.unclassified.length),element('pre',row.unclassified.join('\n')||'Aucun nom disponible; une référence numérique ne désigne pas les permissions individuelles.'));box.append(unc);
      const relations=element('details');relations.append(element('summary',`Sources d’installation · ${row.K} paquets distincts (comptage direct)`));
      for(const child of row.linked){relations.append(element('strong',child.label||child.package_name),element('p',child.package_name),element('pre',JSON.stringify(child.relations,null,2)));}
      relations.append(element('p','Les sources Android décrivent une installation ou une mise à jour exposée. Elles ne prouvent pas une installation clandestine. Famille, certificat, domaines communs et origine déclarative ne sont pas ajoutés à K.','jc-sub'));
      box.append(relations);
      const own=element('details');own.append(element('summary','Source d’installation de cette application'),element('pre',JSON.stringify(row.install_source,null,2)));box.append(own);
      for(const f of row.matched){box.append(element('p',`${f.permission||f.id} · niveaux ${f.levels.join(', ')} · ${f.origin} · ${f.source} — ${f.reason}${f.levels.includes(5)?' · actif : '+String(f.active):''}`,'jc-sub'));}
      for(const f of row.excluded)box.append(element('p','Constat non utilisé : '+f.id+' — '+f.exclusion,'jc-sub'));
      const form=element('div',undefined,'ja-form'),inputs={};box.append(element('h4','Références de visibilité pour cette version'));
      for(const [key,label]of [['principal','Vue principale'],['toutes','Toutes les autorisations']]){
        const old=saved.visibility&&Object.prototype.hasOwnProperty.call(saved.visibility,key)?saved.visibility[key]:key==='principal'&&reference.play_count!==undefined?{count:reference.play_count,source:reference.play_source,kind:reference.count_kind,same_version:reference.same_version,version_code:reference.installed_version_code}:{};
        const v=old||{},group=element('fieldset');group.append(element('legend',label));
        const count=element('input');count.type='number';count.min='0';count.value=v.count??'';count.setAttribute('aria-label',label+' : nombre');group.append(count);
        const kind=element('select');for(const [value,title]of [['unknown','Unité à préciser'],['permissions','Permissions individuelles'],['groups','Groupes / catégories']])kind.append(new Option(title,value));kind.value=v.kind||'unknown';kind.setAttribute('aria-label',label+' : unité');group.append(kind);
        const source=element('input');source.value=v.source||'';source.placeholder='Lien ou nom de capture avec date';source.setAttribute('aria-label',label+' : source');group.append(source);
        const checked=element('input');checked.type='checkbox';checked.checked=v.same_version===true&&v.version_code===raw.version_code;const l=element('label','J’ai vérifié la même version installée');l.prepend(checked);group.append(l);
        inputs[key]={count,kind,source,checked};form.append(group);
      }
      box.append(form,element('p','Un champ vide reste inconnu. Un zéro explicitement renseigné signifie aucune permission visible dans cette vue. Les groupes ne sont pas comparés à des permissions individuelles.','jc-sub'));
      const observations=element('details');observations.append(element('summary','Constats L2 à L5 · JSON modifiable'));
      const editor=element('textarea');editor.rows=12;editor.style.width='100%';editor.spellcheck=false;editor.value=JSON.stringify(saved.findings||[],null,2);observations.append(editor);
      observations.append(penaltyButton('Ajouter un constat à compléter',()=>{try{const list=JSON.parse(editor.value);list.push({id:'observation-'+Date.now(),levels:[4],source:'',reason:'',hidden:true,active:null,version_code:raw.version_code,observed_at:new Date().toISOString()});editor.value=JSON.stringify(list,null,2);}catch(e){message.textContent=e.message;}}));
      observations.append(element('p','L2 : action à l’insu de l’utilisateur. L3 : action à son insu avec avertissement Android documenté. L4 : partage de capacité avec d’autres applications. Lier le constat à une permission moins visible (nom ou hidden=true justifié). share_count permet de renseigner une portée propre au constat; sinon le barème utilise le nombre de paquets inventoriés. Chaque capacité L4 distincte multiplie le résultat. Les anciens L5 restent conservés, sans facteur automatique.','jc-sub'));
      box.append(observations);const message=element('p',undefined,'jc-note');message.setAttribute('role','status');
      box.append(penaltyButton('Enregistrer les observations et recalculer',()=>{try{
        const evidence={visibility:{},findings:JSON.parse(editor.value),note:saved.note||''};
        for(const [key,v]of Object.entries(inputs)){const value=v.count.value.trim();evidence.visibility[key]=value===''?null:{count:Number(value),kind:v.kind.value,source:v.source.value,same_version:v.checked.checked,version_code:raw.version_code};}
        PenaltyModel.validateEvidence(evidence);const c=penaltySettings();c.references[pkg]=evidence;penaltySave(c);renderAuditDetail(pkg);
      }catch(e){message.textContent=e.message;}}),message,penaltyButton('Modifier le barème global',()=>setTab('penalty')));
    }catch(e){box.append(element('p',e.message,'jc-error'));}
    pane.append(box);
  }
  // Replace the phone score path only; the TI panel remains explicitly simulated.
  const legacyRenderUserHome=renderUserHome;
  renderUserHome=function(){if(nativeBridge&&nativeBridge.penaltyData)renderPenaltyHome();else legacyRenderUserHome();};
  const legacyRenderCoherenceDetail=renderCoherenceDetail;
  renderCoherenceDetail=function(pane,pkg){if(nativeBridge&&nativeBridge.penaltyData)renderPenaltyDetail(pane,pkg);else legacyRenderCoherenceDetail(pane,pkg);};
  const legacyStartCoherenceRefresh=startCoherenceRefresh;
  startCoherenceRefresh=function(){
    if(mvpViewMode==='ti'||!nativeBridge||!nativeBridge.penaltyData)return legacyStartCoherenceRefresh();
    try{nativeBridge.command('audit-scan');stopCoherencePoll();let ticks=0;
      $('jc-home-refresh').disabled=true;$('jc-refresh-status').textContent='Inventaire local en cours…';
      coherencePollTimer=setInterval(()=>{try{const s=penaltyRead('auditSummary');if(!s.busy||++ticks>180){stopCoherencePoll();penaltyCache=null;renderUserHome();if(s.error)$('jc-refresh-status').textContent=s.error;} }catch(e){stopCoherencePoll();$('jc-refresh-status').textContent=e.message;}},1000);
    }catch(e){$('jc-refresh-status').textContent=e.message;}
  };
  $('jc-home-refresh').onclick=startCoherenceRefresh;
  const oldSetTab=setTab;
  setTab=function(tab){oldSetTab(tab);if(tab==='decisions')renderPenaltyColors();if(tab==='penalty'){renderPenaltySettings();penaltyCheckImport();}};
