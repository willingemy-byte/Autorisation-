  let aivBefore=0,aivNext=0,aivLastPoll=0;
  function aivRead(method,...args){if(!nativeBridge||typeof nativeBridge[method]!=='function')return null;const data=JSON.parse(nativeBridge[method](...args));if(data.error)throw new Error(data.error);return data;}
  function aivError(e){$('aiv-status').textContent=e.message||String(e);}
  function renderAivStatus(){try{
    const s=aivRead('aivSummary');if(!s)return;aivLastPoll=Date.now();
    if($('aiv-tab'))$('aiv-tab').textContent='Décisions · '+(s.stats_complete===false?'calcul partiel':s.findings);
    const progress=Number.isFinite(s.checkpoint)?'Traité jusqu’à l’événement '+s.checkpoint+' · dernier enregistré '+s.latest_event_id:s.pending+' événements en attente';
    $('aiv-status').textContent=(s.operation||(s.watcher_running?'AIV actif':'Analyse AIV en pause'))+' · '+progress+' · '+s.verification+(s.error?' · '+s.error:'')+(s.file_status?' · '+s.file_status:'');
    $('aiv-status').style.color=String(s.verification).startsWith('BROKEN')?'#ff5964':'';
    const apps=$('aiv-apps');apps.replaceChildren();if(s.stats_complete===false)apps.append(element('p','Statistiques partielles : '+s.stats_evaluated+' décisions comptabilisées. Le calcul reprend avec l’analyse AIV.'));for(const a of s.apps){apps.append(element('p',a.app+' : '+a.findings+'/'+a.evaluated+' ('+(100*a.ratio).toFixed(1)+' %)'));}
    if(nativeBridge.auditSummary){const inventory=JSON.parse(nativeBridge.auditSummary());$('aiv-local-ref-status').textContent=(inventory.busy?'Inventaire en cours. ': '')+(inventory.scan_id?'Référence estimée basée sur le dernier inventaire terminé : '+inventory.scan_id+'.':'Appuie sur Actualiser pour créer la référence locale.')+(inventory.error?' '+inventory.error:'');}
    const refs=$('aiv-references');refs.replaceChildren();for(const source of s.sources){refs.append(element('p',source.source+' · '+source.apps+' apps · '+source.status+' · '+(source.last_sync_ms?new Date(source.last_sync_ms).toISOString():'jamais mis à jour')));}
    const rules=$('aiv-rules');rules.replaceChildren();for(const r of s.rules){const b=element('button',r.name+' v'+r.version+' · '+r.decision+' · priorité '+r.priority+(r.enabled?'':' · désactivée'));b.onclick=()=>{$('aiv-config').value=JSON.stringify({name:r.name,decision:r.decision,priority:r.priority,enabled:r.enabled===1,condition:JSON.parse(r.condition)},null,2);};rules.append(b);}
  }catch(e){aivError(e);}}
  function aivShowDetail(eventId,target){try{const d=aivRead('aivDetail',Number(eventId));if(!d)return;target.replaceChildren();target.append(element('h3','Événement '+eventId+' · chaîne et décision'));const pre=element('pre',JSON.stringify(d,null,2));pre.style.whiteSpace='pre-wrap';pre.style.overflowWrap='anywhere';target.append(pre);}catch(e){aivError(e);}}
  function renderAiv(){try{
    renderAivStatus();const p=aivRead('aivPage',$('aiv-filter').value,aivBefore);if(!p)return;
    const rows=$('aiv-rows');rows.replaceChildren(element('p','Décisions historiques : chaque décision conserve les règles utilisées au moment de son calcul.','jc-sub'));for(const d of p.rows){const box=element('article',undefined,'jc-source');const open=element('button',d.decision+' · événement '+d.event_id+' · '+d.rule_name);open.style.color=d.decision==='DENIED'?'#ff5964':d.decision==='WATCH'?'#f3c969':'#58c8ab';open.onclick=()=>aivShowDetail(d.event_id,$('aiv-detail'));appIdentity(box,d.identity||{});box.append(open,element('span',new Date(d.timestamp_ms).toISOString(),'jc-sub'));rows.append(box);}if(!p.rows.length)rows.append(element('p','Aucune décision pour ce filtre.'));aivNext=p.next;$('aiv-next').disabled=!aivNext;
  }catch(e){aivError(e);}}
  function pollAiv(tab){if((tab==='decisions'||tab==='references')&&Date.now()-aivLastPoll>=10000){if(tab==='decisions')renderAiv();else renderAivStatus();}}
  function aivEventExtras(pane,event){if(!nativeBridge||!nativeBridge.aivDetail)return;const box=element('details');box.append(element('summary','Intégrité AIV : empreintes et décision'));const content=element('div');box.append(content);box.addEventListener('toggle',()=>{if(box.open)aivShowDetail(event.original.id,content);});pane.append(box);}
  if(nativeBridge&&nativeBridge.aivSummary){
    for(const [id,command]of [['aiv-start','aiv-start'],['aiv-stop','aiv-stop'],['aiv-verify','aiv-verify'],['aiv-export','aiv-export'],['aiv-import','aiv-reference']])$(id).onclick=()=>{nativeBridge.command(command);setTimeout(renderAivStatus,1000);};
    $('aiv-refresh').onclick=()=>renderAiv();$('aiv-ref-refresh').onclick=()=>{nativeBridge.command('audit-scan');$('aiv-local-ref-status').textContent='Inventaire demandé. La référence utilisera automatiquement le dernier relevé terminé.';};$('aiv-ref-export').onclick=()=>nativeBridge.command('export-reference');
    $('aiv-filter').onchange=()=>{aivBefore=0;renderAiv();};$('aiv-first').onclick=()=>{aivBefore=0;renderAiv();};$('aiv-next').onclick=()=>{aivBefore=aivNext;renderAiv();};
    $('aiv-save').onclick=()=>{try{JSON.parse($('aiv-config').value);nativeBridge.aivConfigure($('aiv-config').value);}catch(e){aivError(e);}};
  }
