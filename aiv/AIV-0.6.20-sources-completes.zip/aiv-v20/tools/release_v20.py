#!/usr/bin/env python3
"""Finite release task. Requires preinstalled toolchain and existing signing files.
The private signing directory is outside the archived source tree.
"""
from pathlib import Path
import hashlib,json,subprocess,zipfile,sys
root=Path(__file__).resolve().parents[1]; workspace=root.parent
out=workspace/'livrables';out.mkdir(exist_ok=True)
def run(args,**kw):return subprocess.run([str(a) for a in args],cwd=workspace,check=True,**kw)
run([sys.executable,root/'build.py','--android-jar','toolchain/android-35/android.jar','--build-tools','toolchain/android-15','--ecj','toolchain/ecj-3.40.0.jar','--ndk','toolchain/android-ndk-r27d','--signing-dir',workspace/'private-signing-drive'])
apk=out/'AIV-0.6.20-signed.apk'
run(['java','-jar','toolchain/android-15/lib/apksigner.jar','sign','--ks','private-signing-drive/journal-local.p12','--ks-key-alias','journal-local','--ks-pass','file:private-signing-drive/password.txt','--out',apk,root/'build/journal-local-aligned.apk'])
verified=run(['java','-jar','toolchain/android-15/lib/apksigner.jar','verify','--verbose','--print-certs',apk],capture_output=True,text=True).stdout
assert '4a14b9e2cf3869fa9faf2317cba96e948145e4dba32240f9547380c040deba7b' in verified
badging=run(['toolchain/android-15/aapt2','dump','badging',apk],capture_output=True,text=True).stdout
assert "name='fr.erick.journallocal'" in badging and "versionCode='26'" in badging and "versionName='0.6.20'" in badging
run(['toolchain/android-15/zipalign','-c','-P','16','4',apk])
with zipfile.ZipFile(apk) as z:
 assert z.testzip() is None
 assert z.read('assets/journal.html')==(root/'app/src/main/assets/journal.html').read_bytes()
 for abi in ['arm64-v8a','x86_64']:
  assert z.getinfo('lib/'+abi+'/libjournalrelay.so').file_size>0
print('PASS APK integrity, assets, package, version, original certificate and alignment',flush=True)
archive=out/'AIV-0.6.20-sources-completes.zip'; manifest={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(root.rglob('*')):
  rel=f.relative_to(root)
  if not f.is_file() or any(p in {'build','.git','__pycache__','node_modules'} for p in rel.parts):continue
  if f.suffix in {'.p12','.jks','.keystore'} or f.name in {'password.txt','.env'}:raise RuntimeError('Secret file forbidden in sources')
  data=f.read_bytes();z.writestr('aiv-v20/'+str(rel),data);manifest[str(rel)]=hashlib.sha256(data).hexdigest()
 z.writestr('SHA256-SOURCES.json',json.dumps(manifest,indent=2))
files=[apk,archive,out/'AIV-0.6.20-bareme.json',out/'AIV-0.6.20-guide.md']
receipt=out/'AIV-0.6.20-build-result.json'
receipt.write_text(json.dumps({'verified':True,'device_tested':False,'files':[{'path':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in files]},indent=2))
helper=Path('/root/.codex/plugins/cache/openai-curated-remote/openai-library/0.1.57/skills/library/scripts/library_upload.py')
prior=out/'AIV-0.6.20-save-receipt.json'
previous={}
if prior.exists():previous={item['local_path']:item for item in json.loads(prior.read_text()).get('results',[]) if item.get('status')=='succeeded'}
uploads=[]
for f in files:
 item=previous.get(str(f));uploads.append({'local_path':str(f),'purpose':'replace_library_file','library_file_id':item['library_file_id'],'expected_current_version':item['current_version_number']} if item else {'local_path':str(f),'purpose':'create_library_file'})
result=run([sys.executable,helper],input=json.dumps({'uploads':uploads}),text=True,capture_output=True)
(out/'AIV-0.6.20-save-receipt.json').write_text(result.stdout)
print(result.stdout,flush=True)
print('RELEASE_FILES '+json.dumps([str(f) for f in files]),flush=True)
