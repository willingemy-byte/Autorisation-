/* AIV penalty model /1. Pure, local, shared by the reader and host tests. */
const PenaltyModel = (() => {
  'use strict';
  const defaults = {
    schema: 'aiv-penalty-policy/3', name: 'Barème AIV personnel',
    visibility: 'principal', derived_reference: true, aggregation: {denominator: 'apps_with_hidden', include_zero: false},
    multipliers: {level2: 2, level3: 3, level4: {mode: 'installed_app_count', fixed: 1, combination:'sum'},
      level5: {mode: 'linked_packages', fixed: 1, relations: ['initiating_package', 'installing_package', 'update_owner_package']}},
    colors: {yellow_ratio: 2, orange_ratio: 4, red_ratio: 6, critical_ratio: 8,
      level5_forces_critical: true, blink_critical: true,
      global_yellow_points: 100, global_orange_points: 1000, global_red_points: 10000, global_critical_points: 100000},
    automatic: {enabled:true,component_links:true,android_warnings:true,android_descriptions:true,catalog:[{"id": "android-call_phone", "permission": "android.permission.CALL_PHONE", "levels": [2], "source": "https://developer.android.com/reference/android/Manifest.permission#CALL_PHONE", "reason": "Appel sans passage par la confirmation du composeur.", "require_granted": true, "enabled": true}, {"id": "android-call_privileged", "permission": "android.permission.CALL_PRIVILEGED", "levels": [2], "source": "https://developer.android.com/reference/android/Manifest.permission#CALL_PRIVILEGED", "reason": "Appels privilégiés, y compris urgences; restrictions système.", "require_granted": true, "enabled": true}, {"id": "android-read_call_log", "permission": "android.permission.READ_CALL_LOG", "levels": [2], "source": "https://developer.android.com/reference/android/Manifest.permission#READ_CALL_LOG", "reason": "Lecture du journal des appels.", "require_granted": true, "enabled": true}, {"id": "android-write_call_log", "permission": "android.permission.WRITE_CALL_LOG", "levels": [2], "source": "https://developer.android.com/reference/android/Manifest.permission#WRITE_CALL_LOG", "reason": "Modification des données du journal des appels.", "require_granted": true, "enabled": true}, {"id": "android-read_contacts", "permission": "android.permission.READ_CONTACTS", "levels": [2], "source": "https://developer.android.com/reference/android/Manifest.permission#READ_CONTACTS", "reason": "Lecture des contacts.", "require_granted": true, "enabled": true}, {"id": "android-write_contacts", "permission": "android.permission.WRITE_CONTACTS", "levels": [2], "source": "https://developer.android.com/reference/android/Manifest.permission#WRITE_CONTACTS", "reason": "Modification des contacts.", "require_granted": true, "enabled": true}, {"id": "android-read_sms", "permission": "android.permission.READ_SMS", "levels": [2], "source": "https://developer.android.com/reference/android/Manifest.permission#READ_SMS", "reason": "Lecture des messages SMS.", "require_granted": true, "enabled": true}, {"id": "android-send_sms", "permission": "android.permission.SEND_SMS", "levels": [2], "source": "https://developer.android.com/reference/android/Manifest.permission#SEND_SMS", "reason": "Envoi de SMS; restrictions Android et opérateur possibles.", "require_granted": true, "enabled": true}, {"id": "android-install_packages", "permission": "android.permission.INSTALL_PACKAGES", "levels": [2], "source": "https://developer.android.com/reference/android/Manifest.permission#INSTALL_PACKAGES", "reason": "Installation privilégiée de paquets.", "require_granted": true, "enabled": true}, {"id": "android-delete_packages", "permission": "android.permission.DELETE_PACKAGES", "levels": [2], "source": "https://developer.android.com/reference/android/Manifest.permission#DELETE_PACKAGES", "reason": "Suppression privilégiée de paquets.", "require_granted": true, "enabled": true}, {"id": "android-write_secure_settings", "permission": "android.permission.WRITE_SECURE_SETTINGS", "levels": [2], "source": "https://developer.android.com/reference/android/Manifest.permission#WRITE_SECURE_SETTINGS", "reason": "Modification privilégiée des paramètres sécurisés.", "require_granted": true, "enabled": true}, {"id": "android-modify_phone_state", "permission": "android.permission.MODIFY_PHONE_STATE", "levels": [2], "source": "https://developer.android.com/reference/android/Manifest.permission#MODIFY_PHONE_STATE", "reason": "Modification privilégiée de l’état téléphonique.", "require_granted": true, "enabled": true}, {"id": "android-grant_runtime_permissions", "permission": "android.permission.GRANT_RUNTIME_PERMISSIONS", "levels": [2, 4], "source": "https://developer.android.com/reference/android/Manifest.permission#GRANT_RUNTIME_PERMISSIONS", "reason": "Gestion des permissions d’autres applications; portée potentielle.", "require_granted": true, "enabled": true}, {"id": "android-revoke_runtime_permissions", "permission": "android.permission.REVOKE_RUNTIME_PERMISSIONS", "levels": [2, 4], "source": "https://developer.android.com/reference/android/Manifest.permission#REVOKE_RUNTIME_PERMISSIONS", "reason": "Révocation des permissions d’autres applications; portée potentielle.", "require_granted": true, "enabled": true}, {"id": "android-change_component_enabled_state", "permission": "android.permission.CHANGE_COMPONENT_ENABLED_STATE", "levels": [2, 4], "source": "https://developer.android.com/reference/android/Manifest.permission#CHANGE_COMPONENT_ENABLED_STATE", "reason": "Activation ou désactivation de composants d’autres applications.", "require_granted": true, "enabled": true}]},
    rules: []
  };
  const clone = x => JSON.parse(JSON.stringify(x));
  const integer = (x, max = 1000000) => typeof x === 'number' && Number.isSafeInteger(x) && x >= 0 && x <= max;
  const text = x => typeof x === 'string' && x.trim().length > 0;
  function keys(o, allowed, at) {
    if (!o || typeof o !== 'object' || Array.isArray(o)) throw Error(at + ' : objet requis');
    for (const k of Object.keys(o)) if (!allowed.includes(k)) throw Error(at + ' : champ inconnu ' + k);
  }
  function validatePolicy(input) {
    input=clone(input);
    // Preserve the old L5 configuration for inspection, but the /2 formula has four levels.
    if(['aiv-penalty-policy/1','aiv-penalty-policy/2'].includes(input.schema))input.schema=defaults.schema;
    if(typeof input.multipliers?.level4==='number')input.multipliers.level4=clone(defaults.multipliers.level4);
    keys(input, Object.keys(defaults), 'Barème');
    const p = clone(defaults);
    for (const k of ['schema','name','visibility','rules','derived_reference']) if (input[k] !== undefined) p[k] = clone(input[k]);
    for (const k of ['aggregation','multipliers','colors','automatic']) if (input[k] !== undefined) {
      keys(input[k], Object.keys(defaults[k]), k); Object.assign(p[k], input[k]);
    }
    if (input.multipliers && input.multipliers.level5) {
      keys(input.multipliers.level5, Object.keys(defaults.multipliers.level5), 'L5');
      p.multipliers.level5 = Object.assign(clone(defaults.multipliers.level5), input.multipliers.level5);
    }
    if(input.multipliers?.level4){keys(input.multipliers.level4,['mode','fixed','combination'],'L4');p.multipliers.level4=Object.assign(clone(defaults.multipliers.level4),input.multipliers.level4);}
    if(!['installed_app_count','fixed','disabled'].includes(p.multipliers.level4.mode)||!integer(p.multipliers.level4.fixed))throw Error('Réglage L4 invalide');
    if(!['sum','product'].includes(p.multipliers.level4.combination))throw Error('Combinaison L4 invalide');
    if (typeof p.derived_reference !== 'boolean') throw Error('derived_reference : booléen requis');
    if (p.schema !== defaults.schema || !text(p.name)) throw Error('Schéma / nom du barème invalide');
    if (!['principal','toutes'].includes(p.visibility)) throw Error('Vue attendue : principal ou toutes');
    if (p.aggregation.denominator !== 'apps_with_hidden' || p.aggregation.include_zero !== false)
      throw Error('Seules les applications avec H > 0 contribuent à la synthèse');
    for (const k of ['level2','level3']) if (!integer(p.multipliers[k])) throw Error(k + ' : entier de 0 à 1 000 000 requis');
    const l5 = p.multipliers.level5;
    if (!['linked_packages','fixed','disabled'].includes(l5.mode) || !integer(l5.fixed)) throw Error('Réglage L5 invalide');
    if (!Array.isArray(l5.relations) || !l5.relations.length || l5.relations.some(x => !['initiating_package','installing_package','update_owner_package'].includes(x))) throw Error('Relations L5 invalides');
    for (const names of [['yellow_ratio','orange_ratio','red_ratio','critical_ratio'],['global_yellow_points','global_orange_points','global_red_points','global_critical_points']]) {
      let previous = 0;
      for (const k of names) {if (typeof p.colors[k] !== 'number' || !Number.isFinite(p.colors[k]) || p.colors[k] <= previous || p.colors[k] > Number.MAX_SAFE_INTEGER || String(p.colors[k]).includes('e')) throw Error('Seuils strictement croissants requis : ' + k); previous = p.colors[k];}
    }
    for (const k of ['level5_forces_critical','blink_critical']) if (typeof p.colors[k] !== 'boolean') throw Error(k + ' : booléen requis');
    if (!Array.isArray(p.rules) || p.rules.length > 2000) throw Error('Liste de règles invalide');
    if(['enabled','component_links','android_warnings','android_descriptions'].some(k=>typeof p.automatic[k]!=='boolean')||!Array.isArray(p.automatic.catalog)||p.automatic.catalog.length>2000)throw Error('Détecteur automatique invalide');
    const ids = new Set();
    for (const r of [...p.rules,...p.automatic.catalog]) {
      keys(r, ['id','permission','prefix','levels','source','reason','require_granted','enabled'], 'Règle');
      if (!text(r.id) || ids.has(r.id) || !text(r.source) || !text(r.reason) || (text(r.permission) === text(r.prefix))) throw Error('Règle : id unique, permission OU préfixe, source et raison requis');
      ids.add(r.id);
      if (!Array.isArray(r.levels) || !r.levels.length || r.levels.some(n => ![2,3,4].includes(n))) throw Error('Règles automatiques : niveaux 2, 3, 4 uniquement');
      if (r.require_granted !== undefined && typeof r.require_granted !== 'boolean') throw Error('require_granted invalide');
      if (r.enabled !== undefined && typeof r.enabled !== 'boolean') throw Error('enabled invalide');
    }
    return p;
  }
  function validateEvidence(e) {
    keys(e, ['visibility','findings','note'], 'Observations');
    if (e.visibility !== undefined) {
      keys(e.visibility, ['principal','toutes'], 'Visibilité');
      for (const [name, v] of Object.entries(e.visibility)) {
        if (v === null) continue;
        keys(v, ['count','kind','source','same_version','version_code'], name);
        if (!integer(v.count,100000) || !['permissions','groups','unknown'].includes(v.kind) || !text(v.source) || typeof v.same_version !== 'boolean' || !integer(v.version_code,Number.MAX_SAFE_INTEGER)) throw Error(name + ' : nombre, unité, source et version requis');
      }
    }
    if (e.findings !== undefined) {
      if (!Array.isArray(e.findings) || e.findings.length > 2000) throw Error('Liste de constats invalide');
      const ids = new Set();
      for (const f of e.findings) {
        keys(f, ['id','permission','levels','source','reason','active','outside_permissions','version_code','observed_at','hidden','share_count'], 'Constat');
        if (!text(f.id) || ids.has(f.id) || !text(f.source) || !text(f.reason) || !integer(f.version_code,Number.MAX_SAFE_INTEGER) || !text(f.observed_at) || !Number.isFinite(Date.parse(f.observed_at))) throw Error('Constat : id unique, source, raison, version et date requis');
        ids.add(f.id);
        if (!Array.isArray(f.levels) || !f.levels.length || f.levels.some(n => ![2,3,4,5].includes(n))) throw Error('Niveaux attendus : 2 à 5');
        if(f.hidden!==undefined&&typeof f.hidden!=='boolean')throw Error('hidden : booléen requis');
        if(f.share_count!==undefined&&!integer(f.share_count,100000))throw Error('share_count : entier de 0 à 100 000 requis');
        if (f.active !== undefined && ![true,false,null].includes(f.active)) throw Error('État actif invalide');
        if (f.levels.includes(5) && typeof f.outside_permissions !== 'boolean') throw Error('L5 : préciser outside_permissions');
      }
    }
    if (e.note !== undefined && typeof e.note !== 'string') throw Error('Note invalide');
    return clone(e);
  }
  function group(a) {
    const uid = a.uid, candidates = a.uid_packages;
    if (!integer(uid,Number.MAX_SAFE_INTEGER) || uid % 100000 < 10000 || !Array.isArray(candidates) || new Set(candidates).size !== 1) return 'android';
    return a.system_app === true ? 'system' : 'user';
  }
  function references(a, ref, policy) {
    const saved = ref.penalty_evidence || {}, result = clone(saved.visibility || {});
    if (!Object.prototype.hasOwnProperty.call(result,'principal') && typeof ref.play_count === 'number') result.principal = {
      count: ref.play_count, source: ref.play_source, kind: ref.count_kind,
      same_version: ref.same_version, version_code: ref.installed_version_code
    };
    if (!Object.prototype.hasOwnProperty.call(result,'principal') && policy.derived_reference && a.local_reference) {
      const r=a.local_reference;
      if(r.estimated===true && r.version_code===a.version_code) result.principal={count:r.visible_permission_count,kind:'permissions',source:r.reference_note,same_version:true,version_code:r.version_code,estimated:true};
    }
    return result;
  }
  function visible(a, v, real) {
    if (!v || !integer(v.count,100000) || !text(v.source)) return {value:null,reason:'Référence de visibilité manquante'};
    if (v.kind !== 'permissions') return {value:null,reason:'Groupes et permissions individuelles : unités non comparables'};
    if (v.same_version !== true || v.version_code !== a.version_code) return {value:null,reason:'Version de référence non confirmée ou périmée'};
    if (v.count > real) return {value:null,reason:'Contradiction : davantage de permissions visibles que déclarées'};
    return {value:v.count,hidden:real-v.count,source:v.source,estimated:v.estimated===true};
  }
  function graph(apps, policy) {
    const result = new Map();
    for (const a of apps) {
      const s = a.install_source || {};
      if (s.source_available !== true) continue;
      for (const relation of policy.multipliers.level5.relations) {
        const parent = s[relation];
        if (!text(parent) || parent === a.package_name) continue;
        // Android API observation only. Originating package, endpoint, family and certificate excluded.
        if (!['PackageManager.getInstallSourceInfo','PackageManager.getInstallerPackageName'].includes(s.source)) continue;
        const key = (a.profile_id ?? Math.floor(a.uid / 100000)) + ':' + parent;
        if (!result.has(key)) result.set(key, new Map());
        const children = result.get(key);
        if (!children.has(a.package_name)) children.set(a.package_name, {package_name:a.package_name,label:a.label,relations:[]});
        const child = children.get(a.package_name);
        if (!child.relations.some(r => r.type === relation)) child.relations.push({type:relation,source:s.source,observed_ms:s.observed_ms ?? null,
          scope:relation === 'installing_package' ? 'Installateur enregistré; valeur modifiable dans Android' : relation === 'initiating_package' ? 'Initiateur de la dernière installation/mise à jour exposée' : 'Responsable des mises à jour'});
      }
    }
    return result;
  }
  function componentGraph(apps){
    const grants=new Map(),byOwner=new Map();
    for(const app of apps){if(app.enabled===false)continue;const profile=app.profile_id??Math.floor(app.uid/100000);
      for(const p of app.permissions||[]){if(p.granted!==true)continue;const key=profile+':'+p.name;if(!grants.has(key))grants.set(key,[]);grants.get(key).push(app);}}
    for(const owner of apps){const routes=new Map(),profile=owner.profile_id??Math.floor(owner.uid/100000);
      if(owner.enabled!==false)for(const c of owner.components||[]){if(c.exported!==true||c.enabled!==true)continue;
        const gates=c.type==='provider'?[['read',c.read_permission],['write',c.write_permission]]:[['invoke',c.permission]];
        for(const [operation,permission]of gates){if(!text(permission))continue;
          if(!routes.has(permission))routes.set(permission,{permission,components:[],clients:[],scope:'Correspondance statique : composant exporté et permission accordée au client. AppOps, chemins, contrôles internes et exécution non vérifiés.'});
          const route=routes.get(permission);route.components.push({name:c.name,type:c.type,operation,path_restrictions:c.path_permissions_present===true});
          for(const client of grants.get(profile+':'+permission)||[]){if(client.package_name===owner.package_name||client.uid===owner.uid)continue;
            if(!route.clients.some(a=>a.package_name===client.package_name))route.clients.push({package_name:client.package_name,label:client.label,uid:client.uid});}
        }
      }byOwner.set(profile+':'+owner.package_name,[...routes.values()]);
    }return byOwner;
  }
  function calculate(a, ref, p, links, installedCount, routes) {
    const permissions = new Map();
    for (const raw of a.permissions || []) {const v = typeof raw === 'string' ? {name:raw} : raw; if (v && text(v.name)) permissions.set(v.name,v);}
    const R = permissions.size, refs = references(a,ref,p), layers = {};
    for (const key of ['principal','toutes']) layers[key] = visible(a,refs[key],R);
    if (layers.principal.value !== null && layers.toutes.value !== null && layers.toutes.value < layers.principal.value) {
      layers.principal = layers.toutes = {value:null,reason:'Contradiction : Toutes les autorisations contient moins que la vue principale'};
    }
    const evidence = ref.penalty_evidence || {}, matched = [], excluded = [];
    for (const f of evidence.findings || []) {
      if (f.version_code !== a.version_code) {excluded.push({...f,exclusion:'Constat d’une autre version'});continue;}
      if (f.permission && !permissions.has(f.permission)) {excluded.push({...f,exclusion:'Permission absente du dernier inventaire'});continue;}
      matched.push({...f,origin:'Observation utilisateur'});
    }
    for (const r of [...p.rules,...(p.automatic.enabled?p.automatic.catalog:[])]) if (r.enabled !== false) for (const permission of permissions.values()) {
      if ((r.permission === permission.name || text(r.prefix) && permission.name.startsWith(r.prefix)) && (!r.require_granted || permission.granted === true))
        matched.push({id:r.id+':'+permission.name,permission:permission.name,levels:r.levels,source:r.source,reason:r.reason,origin:p.automatic.catalog.includes(r)?'Détection automatique · permission accordée':'Règle du barème'});
    }
    if(p.automatic.enabled&&p.automatic.android_descriptions)for(const permission of permissions.values()){
      const description=permission.autonomy_description;
      if(permission.granted===true&&text(description)&&/^(permet|autorise|allows)\b/i.test(description.trim())&&!/(ne permet pas|ne vous permet pas|does not allow|not permitted)/i.test(description))
        matched.push({id:'android-description:'+permission.name,permission:permission.name,levels:[2],source:'Description Android (définition fournie par android)',reason:description,origin:'Détection textuelle : autonomie mentionnée dans la description'});
    }
    if(p.automatic.enabled&&p.automatic.android_warnings)for(const f of [...matched]){
      const permission=permissions.get(f.permission);if(permission?.granted===true&&text(permission.warning)&&f.levels.includes(2))
        matched.push({...f,id:f.id+':warning',levels:[3],source:'Description de permission retournée par Android',reason:permission.warning,origin:'Avertissement Android observé'});
    }
    if(p.automatic.enabled&&p.automatic.component_links)for(const route of routes){
      if(route.clients.length&&permissions.get(route.permission)?.granted===true)
        matched.push({id:'route:'+route.permission,permission:route.permission,levels:[4],share_count:route.clients.length,source:'PackageManager : composants exportés et permissions accordées',reason:route.scope,origin:'Portée potentielle détectée',route});
    }
    const selected=layers[p.visibility], H=selected.value===null?null:selected.hidden;
    const hiddenNames=new Set(selected.estimated?(a.local_reference?.hidden_candidates||[]):[]);
    const counts={}, sets={2:new Set(),3:new Set(),4:new Set(),5:new Set()}, sharing=new Map();
    for(const f of matched){
      if(H===null||H===0||!(f.hidden===true||(f.permission&&hiddenNames.has(f.permission)))){
        excluded.push({...f,exclusion:'Lien avec une permission moins visible non établi pour la vue retenue'});continue;
      }
      if(f.active===false){excluded.push({...f,exclusion:'Capacité signalée inactive'});continue;}
      for(const n of new Set(f.levels)){
        if(n===5&&!(f.active===true&&f.outside_permissions===true)){excluded.push({...f,exclusion:'L5 : accès spécial actif hors permissions non confirmé'});continue;}
        const identity=f.permission||f.id;sets[n].add(identity);
        if(n===4){if(!sharing.has(identity))sharing.set(identity,[]);sharing.get(identity).push(f);}
      }
    }
    for(const n of [2,3,4,5])counts[n]=sets[n].size;
    const profile=a.profile_id??Math.floor(a.uid/100000),linked=Array.from((links.get(profile+':'+a.package_name)||new Map()).values());
    const factors=[2,3].map(n=>BigInt(Math.max(1,p.multipliers['level'+n]*counts[n]))),shareFactors=[];
    const combine=p.multipliers.level4.combination;let F4=combine==='sum'?0n:1n;
    for(const [identity,items] of sharing){
      const explicit=new Set(items.filter(f=>f.share_count!==undefined).map(f=>f.share_count));
      let count=1,scope='Désactivé dans le barème';
      if(explicit.size>1){excluded.push({id:identity,exclusion:'Portées L4 contradictoires; facteur laissé neutre'});scope='Portée contradictoire';}
      else if(p.multipliers.level4.mode!=='disabled'){
        count=explicit.size?Array.from(explicit)[0]:p.multipliers.level4.mode==='fixed'?p.multipliers.level4.fixed:installedCount;
        scope=explicit.size?'Portée renseignée dans le constat':p.multipliers.level4.mode==='fixed'?'Pondération fixe du barème':'Pondération potentielle : tous les paquets inventoriés du même profil; partage effectif non établi';
      }
      const factor=BigInt(Math.max(1,count));if(p.multipliers.level4.mode!=='disabled'&&explicit.size<=1){if(combine==='sum')F4+=BigInt(count);else F4*=factor;}shareFactors.push({identity,count,factor:String(factor),scope});
    }
    factors.push(F4<1n?1n:F4);
    const l5=p.multipliers.level5;factors.push(BigInt(counts[5]&&l5.mode!=='disabled'?Math.max(1,l5.mode==='fixed'?l5.fixed:linked.length):1));
    const multiplier=factors.reduce((s,n)=>s*n,1n),points=H===null?null:BigInt(H)*multiplier;
    const ratio=H===null?null:selected.value===0?R>0?Infinity:1:R/selected.value;
    const classified=new Set(matched.map(f=>f.permission));const unclassified=[...hiddenNames].filter(n=>!classified.has(n));
    const partial=p.automatic.enabled&&H>0&&(!selected.estimated||unclassified.length>0||a.components_collected!==true);
    const color=H===null||partial&&multiplier===1n?'unknown':H===0?'green':colorFor(multiplier,1n,p);
    return {package_name:a.package_name,label:a.label || a.package_name,uid:a.uid,group:group(a),R,H,V:selected.value,layers,
      routes,unclassified,coverage_partial:partial,components_collected:a.components_collected===true,estimated:selected.estimated===true,multiplier:String(multiplier),share_factors:shareFactors,installed_count:installedCount,points:points === null ? null : points.toString(),ratio:ratio === Infinity ? '∞' : ratio,color,counts,
      factors:factors.map(String),K:linked.length,linked,matched,excluded,version_code:a.version_code,
      reason:selected.reason || '',policy_name:p.name,visibility:p.visibility,
      l5_status:counts[5] ? (linked.length ? 'Accès actif observé et relations disponibles' : 'Accès actif observé; aucune relation disponible, facteur neutre') : 'Aucun accès L5 actif confirmé',
      install_source:a.install_source || {source_available:false,reason:'Relevé ancien : refaire l’inventaire'}};
  }
  function colorFor(n,d,p){
    let c='green';
    // Decimal thresholds compared as rationals: no Number conversion of huge penalties.
    for(const [key,next]of [['yellow_ratio','yellow'],['orange_ratio','orange'],['red_ratio','red'],['critical_ratio','critical']]){
      const threshold=String(p.colors[key]);const [whole,fraction='']=threshold.split('.');
      const scale=10n**BigInt(fraction.length);
      if(n*scale>=BigInt(whole+fraction)*d)c=next;
    }
    return c;
  }
  function decimal(n,d){if(!d)return null;const v=(n*100n+d/2n)/d;return (v/100n)+'.'+String(v%100n).padStart(2,'0');}
  function aggregate(rows,p){
    const included=rows.filter(r=>r.H!==null&&r.H>0&&r.points!==null);
    const sum=included.reduce((s,r)=>s+BigInt(r.points),0n),base=included.reduce((s,r)=>s+BigInt(r.H),0n),n=BigInt(included.length);
    const evaluated=rows.filter(r=>r.H!==null).length;
    return {total:rows.length,concerned:included.length,unknown:rows.length-evaluated,zero:rows.filter(r=>r.H===0).length,
      hidden:Number(base),base:evaluated?String(base):null,base_mean:n?decimal(base,n):evaluated?'0.00':null,sum:String(sum),mean:decimal(sum,n),
      multiplier:base?decimal(sum,base):evaluated?'1.00':null,multiplier_numerator:base?String(sum):evaluated?'1':null,multiplier_denominator:base?String(base):evaluated?'1':null,
      maximum:included.reduce((m,r)=>BigInt(r.points)>m?BigInt(r.points):m,0n).toString(),color:base?(sum===base&&included.some(r=>r.coverage_partial)?'unknown':colorFor(sum,base,p)):evaluated?'green':'unknown',
      levels:Object.fromEntries([2,3,4,5].map(n=>[n,rows.filter(r=>r.counts[n]>0).length]))};
  }
  function evaluate(input,policy) {
    const p=validatePolicy(policy || defaults), seen=new Set(), apps=[];
    for(const a of input.apps || []) {const key=(a.profile_id??Math.floor(a.uid/100000))+':'+a.package_name;if(!seen.has(key)){seen.add(key);apps.push(a);}}
    const totals=new Map();for(const a of apps){const profile=a.profile_id??Math.floor(a.uid/100000);totals.set(profile,(totals.get(profile)||0)+1);}
    const links=graph(apps,p),routes=componentGraph(apps), rows=apps.map(a=>calculate(a,(input.references || {})[a.package_name] || {},p,links,totals.get(a.profile_id??Math.floor(a.uid/100000)),routes.get((a.profile_id??Math.floor(a.uid/100000))+':'+a.package_name)||[]));
    rows.sort((a,b)=>a.points===null?(b.points===null?a.package_name.localeCompare(b.package_name):1):b.points===null?-1:BigInt(a.points)===BigInt(b.points)?a.package_name.localeCompare(b.package_name):BigInt(a.points)>BigInt(b.points)?-1:1);
    return {schema:'aiv-penalty-result/2',policy:p,scan_id:input.scan_id,apps:rows,summary:aggregate(rows,p),groups:['android','system','user'].map(id=>({id,...aggregate(rows.filter(r=>r.group===id),p)}))};
  }
  return {defaults:()=>clone(defaults),validatePolicy,validateEvidence,evaluate,group};
})();
if(typeof module!=='undefined')module.exports=PenaltyModel;
