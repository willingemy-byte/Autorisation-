  function auditAppComparison(app){
    if(nativeBridge&&nativeBridge.penaltyData){try{const row=penaltyLoad().result.apps.find(a=>a.package_name===app.package_name);if(row)return {level:row.color==='unknown'?'gray':row.color==='critical'?'red':row.color,label:row.points===null?'Non évaluée':penaltyNumber(row.H)+' points de base × '+penaltyCompact(row.multiplier),penaltyText:row.H===null?row.reason:penaltyNumber(row.points)+' points pondérés · couleur selon le multiplicateur'};}catch(e){return {level:'gray',label:'Calcul indisponible',penaltyText:e.message};}}
    return AuditRules.compare(app.count,app.reference,app.version_code);
  }
  let auditOffset=0,auditStarted=false;
  const auditRead=value=>{const r=JSON.parse(value);if(r.error)throw new Error(r.error);return r;};
  const auditDate=ms=>ms?new Date(ms).toISOString():'INCONNU';
  const auditBadge=r=>element('span',r.label,'ja-badge ja-'+r.level);
  function renderAudit(){
    if(!nativeBridge||!nativeBridge.auditSummary){$('ja-status').textContent='Inventaire disponible dans la version Android mise à jour, sur ton téléphone.';return;}
    try{
      const s=JSON.parse(nativeBridge.auditSummary());$('ja-total').textContent=s.total||0;$('ja-system').textContent=s.system||0;$('ja-scan-number').textContent=s.scan_id||'À faire';
      $('ja-status').textContent=s.error||(s.busy?'Inventaire en cours…':s.coverage||'')+(s.file_status?' · '+s.file_status:'');$('ja-scan').disabled=!!s.busy;
      if(!s.scan_id&&!s.busy&&!s.error&&!auditStarted){auditStarted=true;nativeBridge.command('audit-scan');}
      const result=auditRead(nativeBridge.auditPage($('ja-search').value,$('ja-scope').value,auditOffset));if(auditOffset&&!result.rows.length){auditOffset=0;renderAudit();return;}
      $('ja-count').textContent=result.total+' applications pour ces filtres';const list=$('ja-list');list.replaceChildren();
      for(const app of result.rows){const r=auditAppComparison(app),card=element('article',undefined,'ja-card ja-'+r.level),button=element('button',app.label);button.type='button';button.onclick=()=>renderAuditDetail(app.package_name);
        card.append(button,element('span',app.package_name,'jc-sub'),auditBadge(r),element('span',`${app.count} droits dans le manifeste · ${r.penaltyText||((app.reference.play_count??'INCONNU')+' dans la référence Play')}`,'ja-data'),element('span',`${app.system_app?'Système':'Autre application'} · UID ${app.uid}${app.reference.watched?' · À examiner':''}`,'jc-sub'));appIdentity(card,app);list.append(card);
      }
      $('ja-prev').disabled=!auditOffset;$('ja-next').disabled=auditOffset+25>=result.total;$('ja-page').textContent=`Page ${Math.floor(auditOffset/25)+1} / ${Math.max(1,Math.ceil(result.total/25))}`;
    }catch(e){$('ja-status').textContent=e.message;}
  }
  function auditInput(label,id,value,type='text'){
    const field=element('input');field.id=id;field.type=type;field.value=value??'';const wrap=element('label',label);wrap.append(field);return wrap;
  }
  function renderAuditDetail(pkg){
    try{
      const data=auditRead(nativeBridge.auditDetail(pkg)),a=data.app,ref=data.reference||{},r=auditAppComparison({...a,reference:ref}),pane=$('ja-detail');pane.replaceChildren();
      const head=element('div',undefined,'ja-card ja-'+r.level);head.append(element('h3',a.label),element('p',a.package_name,'jc-sub'),auditBadge(r),element('p',`Version ${a.version_name||'INCONNU'} (${a.version_code}) · UID ${a.uid} · profil ${a.profile_id}`,'ja-data'),element('p',`Attribution : ${a.attribution}. Application ${a.enabled?'activée':'désactivée'}.`,'jc-sub'));appIdentity(head,a);pane.append(head);
      renderCoherenceDetail(pane,pkg);
      const flowButton=element('button','Voir les flux réseau de cette application');flowButton.type='button';flowButton.onclick=()=>flowOpen(pkg);pane.append(flowButton);
      if(nativeBridge.openAuditedApp){const actions=element('div',undefined,'jc-row');for(const [label,settings] of [['Ouvrir l’application',false],['Fiche Android et autorisations',true]]){const button=element('button',label);button.type='button';button.onclick=()=>nativeBridge.openAuditedApp(pkg,settings);actions.append(button);}pane.append(actions);}

      if(!(nativeBridge&&nativeBridge.penaltyData)){
      const form=element('div',undefined,'ja-form ja-card');form.append(element('h3','Référence Google Play'));
      form.append(auditInput('Nombre visible','ja-play-count',ref.play_count,'number'));const kind=element('select');kind.id='ja-count-kind';for(const [value,label]of [['unknown','Type de comptage inconnu'],['groups','Catégories ou groupes'],['permissions','Permissions individuelles']])kind.append(new Option(label,value));kind.value=ref.count_kind||'unknown';const kl=element('label','Ce qui a été compté');kl.append(kind);form.append(kl);
      const source=auditInput('Source : lien ou référence de capture','ja-play-source',ref.play_source);source.className='ja-wide';form.append(source);
      for(const [id,label,checked]of [['ja-same-version','Référence correspondant à cette version installée',ref.same_version===true&&ref.installed_version_code===a.version_code],['ja-watch','Dossier à examiner',ref.watched===true]]){const l=element('label',label),input=element('input');input.type='checkbox';input.id=id;input.checked=checked;l.prepend(input);form.append(l);}
      const note=element('textarea');note.id='ja-note';note.value=ref.note||'';note.rows=4;note.maxLength=8000;const nl=element('label','Tes observations');nl.className='ja-wide';nl.append(note);form.append(nl);
      const save=element('button','Enregistrer le dossier'),saved=element('p',undefined,'jc-sub');save.id='ja-save';save.type='button';save.onclick=()=>{try{const count=$('ja-play-count').value.trim();if(count!==''&&(!Number.isInteger(Number(count))||Number(count)<0))throw new Error('Nombre entier positif ou zéro requis.');auditRead(nativeBridge.auditSave(pkg,JSON.stringify({play_count:count===''?null:Number(count),play_source:$('ja-play-source').value,count_kind:kind.value,same_version:$('ja-same-version').checked,note:note.value,watched:$('ja-watch').checked})));const fresh=auditRead(nativeBridge.auditContext(pkg)),updated=AuditRules.compare(fresh.count,fresh.reference,fresh.version_code);head.className='ja-card ja-'+updated.level;head.querySelector('.ja-badge').replaceWith(auditBadge(updated));saved.textContent='Dossier et référence enregistrés avec horodatage.';renderAudit();}catch(e){saved.textContent=e.message;}};form.append(save,saved);pane.append(form);
      pane.append(element('p',`Origine : ${ref.reference_origin||'Aucune référence renseignée'} · ${auditDate(ref.recorded_ms)}.`,'jc-sub'),element('p','Les groupes affichés dans une interface et les permissions individuelles peuvent avoir des nombres différents. La couleur reste provisoire tant que le type, la version et la source ne correspondent pas.','jc-note'));
      }
      const events=element('button','Voir les événements attribués à ce paquet');events.id='ja-events';events.type='button';events.onclick=()=>{$('jc-package').value=pkg;$('jc-app-scope').value='';$('jc-app').value='';$('jc-search').value='';$('jc-kind').value='apps';$('jc-transport').value='';state.page=0;nativeAnchor=0;state.selected=null;setTab('journal');renderNative();};pane.append(events);
      pane.append(element('h3',a.permissions.length+' autorisations déclarées'));
      const permissionSearch=element('input');permissionSearch.id='ja-permission-search';permissionSearch.type='search';permissionSearch.placeholder='Chercher un droit ou sa description';permissionSearch.setAttribute('aria-label','Chercher une autorisation');const permissions=element('div');permissions.id='ja-permissions';
      const showPermissions=()=>{permissions.replaceChildren();for(const p of a.permissions){if(!JSON.stringify(p).toLowerCase().includes(permissionSearch.value.toLowerCase()))continue;const item=element('details',undefined,'ja-description');item.append(element('summary',`${p.label||p.name} · ${p.granted===true?'accordée':p.granted===false?'non accordée':'état INCONNU'}`),element('p',p.name,'jc-sub'),element('p',p.description),element('p',`Protection : ${p.protection} (${p.protection_level}). Définie par : ${p.defined_by||'INCONNU'}.`,'jc-sub'),element('p',p.revocation,'jc-sub'));permissions.append(item);}};permissionSearch.oninput=showPermissions;pane.append(permissionSearch,permissions);showPermissions();
      pane.append(element('p','Le droit INTERNET concerne la connexion réseau. Ce journal ne permet pas de déduire quelle permission a fourni les données d’un flux. Lire ou modifier le journal d’appels, utiliser le micro et ouvrir une connexion sont des opérations distinctes.','jc-note'));
      const history=element('details',undefined,'ja-card');history.append(element('summary','Historique du dossier — 100 dernières entrées'));for(const h of data.history)history.append(element('pre',JSON.stringify(h,null,2)));pane.append(history);
      const imported=element('details',undefined,'ja-card');imported.append(element('summary','Constats du rapport importé — 50 derniers'),element('p',data.import_scope,'jc-sub'));for(const f of data.imported_findings){const item=element('div',undefined,'ja-card ja-'+r.level);item.append(element('strong',f.title||f.rule||'Constat'),auditBadge(r),element('pre',JSON.stringify(f,null,2)));imported.append(item);}pane.append(imported);
      const raw=element('details',undefined,'ja-card');raw.append(element('summary','Tous les champs, permissions définies et provenance'),element('pre',JSON.stringify(a,null,2)));pane.append(raw);pane.scrollIntoView({block:'start'});
    }catch(e){$('ja-detail').replaceChildren(element('p',e.message,'jc-error'));}
  }
  function auditFindingColor(row){
    const base=row.severity==='attention'?'yellow':'blue';
    if(!nativeBridge||!nativeBridge.auditContext||!['volume','failures','watch','research','research-port'].includes(row.rule))return {level:base,label:row.severity==='attention'?'À examiner':'Information'};
    // These existing rules encode a unique UID:package[:destination] in subject; never join by app label.
    const match=/^(\d+):([A-Za-z0-9_]+(?:\.[A-Za-z0-9_]+)+)(?::|$)/.exec(row.subject||'');
    if(!match||Number(match[1])%100000===1000)return {level:base,label:'Attribution ou référence à compléter'};
    try{const a=auditRead(nativeBridge.auditContext(match[2]));if(a.uid!==Number(match[1]))return {level:base,label:'Identité à vérifier'};const r=AuditRules.compare(a.count,a.reference,a.version_code);return {level:AuditRules.max(base,r.level),label:r.level==='gray'?'Référence Play à compléter':r.label+' · dossier application'};}catch{return {level:base,label:'Référence Play à compléter'};}
  }
  for(const id of ['ja-search','ja-scope'])$(id).addEventListener(id==='ja-search'?'input':'change',()=>{auditOffset=0;renderAudit();});
  $('ja-prev').onclick=()=>{auditOffset=Math.max(0,auditOffset-25);renderAudit();};$('ja-next').onclick=()=>{auditOffset+=25;renderAudit();};
  $('ja-scan').onclick=()=>{if(nativeBridge&&nativeBridge.auditSummary){nativeBridge.command('audit-scan');renderAudit();}};
  $('ja-export-full').onclick=()=>nativeBridge.command('export-audit-full');
  $('ja-import').onclick=()=>{if(nativeBridge&&nativeBridge.auditSummary)nativeBridge.command('import-audit');};$('ja-export').onclick=()=>{if(nativeBridge&&nativeBridge.auditSummary)nativeBridge.command('export-audit');};
