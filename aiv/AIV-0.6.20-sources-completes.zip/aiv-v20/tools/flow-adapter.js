  let flowBefore=0,flowSearchSeed='';
  function flowGroupLabel(id){return ({android:'Android · non attribuable',system:'Application système',user:'Application utilisateur'}[id]||'Attribution inconnue');}
  function flowTime(ms){return Number(ms)>0?new Date(Number(ms)).toLocaleString('fr-CA'):'Non observé';}
  function flowBytes(n){n=Number(n)||0;if(n<1024)return n+' o';if(n<1024*1024)return (n/1024).toFixed(1)+' Kio';return (n/1024/1024).toFixed(2)+' Mio';}
  function flowOpen(search=''){
    flowSearchSeed=search||'';flowBefore=0;if($('jf-search'))$('jf-search').value=flowSearchSeed;setTab('flows');renderFlows(false);
  }
  function renderFlows(append=false){
    if(!nativeBridge||typeof nativeBridge.flowPage!=='function'){if($('jf-status'))$('jf-status').textContent='La vue Flux nécessite le pont Android 0.6.13.';return;}
    const list=$('jf-list');if(!append)list.replaceChildren();
    try{
      const q=$('jf-search').value.trim(),result=JSON.parse(nativeBridge.flowPage(q,append?flowBefore:0,25));if(result.error)throw new Error(result.error);
      const rows=Array.isArray(result.flows)?result.flows:[];flowBefore=Number(result.next_before_id)||0;
      $('jf-status').textContent=`${rows.length} flux affiché(s) · ${result.scanned_events||0} événements réseau examinés dans cette page bornée. ${result.notice||''}`;
      if(!rows.length&&!append)list.append(element('p','Aucun flux ne correspond à ce filtre dans la fenêtre examinée.','jc-sub'));
      renderEndpointSeries(rows,list);
      for(const f of rows){
        const card=element('details',undefined,'jc-flow-card');card.dataset.attribution=f.attribution_status||'NON_ATTRIBUABLE';
        const title=element('summary',undefined,'jc-row jc-between');title.append(element('strong',f.actor||'Acteur non identifié'),element('span',flowGroupLabel(f.journal_group),'jc-flow-badge'));card.append(title);appIdentity(title,f);
        const uid=Number(f.uid)>=0?'UID '+f.uid:'UID non disponible',pkgs=Array.isArray(f.packages)?f.packages:[];
        title.append(element('p',`${uid} · ${f.protocol||'Protocole inconnu'} · ${f.destination||[f.remote_ip,f.remote_port].filter(Boolean).join(':')}`,'jc-sub'));
        if(f.attribution_status==='NON_ATTRIBUABLE')card.append(element('p',`${f.attribution||'Auteur applicatif non démontré.'}${pkgs.length?' · '+pkgs.length+' paquet(s) candidat(s), non traités comme preuve d’auteur.':''}`,'jc-note'));
        else if(pkgs.length===1)card.append(element('p','Package attribué : '+pkgs[0],'jc-sub'));
        const grid=element('div',undefined,'jc-flow-grid');
        for(const [k,v] of [['Premier sortant',flowTime(f.first_outbound_ms)],['Premier retour',flowTime(f.first_inbound_ms)],['Envoyé',`${flowBytes(f.tx_bytes)} · ${Number(f.tx_packets)||0} paquet(s)`],['Reçu',`${flowBytes(f.rx_bytes)} · ${Number(f.rx_packets)||0} paquet(s)`],['État',f.closed===true?'Fermé':f.closed===false?'Ouvert / observé':'État final non observé'],['Même flux',f.same_flow_return?'Oui · sortie et retour reliés':'Retour non observé dans les données disponibles']]){const d=element('div');d.append(element('span',k,'jc-sub'),element('strong',v));grid.append(d);}card.append(grid);
        if(Array.isArray(f.dns)&&f.dns.length)card.append(element('p','DNS observé : '+f.dns.join(', '),'jc-flow-evidence'));
        if(f.tls_sni)card.append(element('p','SNI TLS observé : '+f.tls_sni,'jc-flow-evidence'));
        if(f.tls_observation)card.append(element('p','TLS : '+f.tls_observation,'jc-sub'));
        card.append(element('p',f.limits||'Aucun contenu chiffré n’est lu.','jc-sub'),element('code',String(f.flow_correlation_id||''),'jc-flow-id'));
        list.append(card);
      }
      $('jf-more').hidden=!rows.length||!flowBefore;
    }catch(e){$('jf-status').textContent=e.message||String(e);}
  }
  $('jf-refresh').onclick=()=>{flowBefore=0;renderFlows(false);};
  $('jf-search').oninput=()=>{flowBefore=0;};$('jf-search').onchange=()=>renderFlows(false);
  $('jf-more').onclick=()=>renderFlows(true);

  function renderEndpointSeries(rows,list){
    const groups=new Map();
    for(const f of rows){
      const t=Number(f.first_outbound_ms||f.first_inbound_ms);if(!t)continue;
      const endpoints=[];
      if(f.remote_ip)endpoints.push('IP '+f.remote_ip+':'+f.remote_port+' '+f.protocol);
      if(f.tls_sni&&!f.ech_extension_present)endpoints.push('SNI '+f.tls_sni.toLowerCase());
      for(const dns of f.dns||[])endpoints.push('DNS '+String(dns).toLowerCase());
      for(const key of new Set(endpoints)){if(!groups.has(key))groups.set(key,[]);groups.get(key).push({f,t});}
    }
    for(const [key,items]of groups){
      items.sort((a,b)=>a.t-b.t);let chunk=[];
      const emit=()=>{if(chunk.length<2)return;const card=element('details',undefined,'jc-flow-card');card.append(element('summary',key+' · '+chunk.length+' flux rapprochés'));
        card.append(element('p','Corrélation temporelle : même destination observée sur cinq minutes. Applications conservées séparément.','jc-sub'));
        for(const {f,t}of chunk){const row=element('p',flowTime(t)+' · '+(f.actor||'Acteur inconnu'));appIdentity(row,f);row.append(element('code',f.flow_correlation_id||''));card.append(row);}list.append(card);};
      for(const item of items){if(chunk.length&&item.t-chunk[0].t>300000){emit();chunk=[];}chunk.push(item);}emit();
    }
  }
