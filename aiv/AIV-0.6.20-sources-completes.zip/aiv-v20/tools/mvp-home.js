  let mvpViewMode='user',coherencePollTimer=0;
  const mvpFleet={
    score:72,total:150,watch:3,critical:1,
    devices:[
      {name:'Téléphone — Direction 044',meta:'Android · vu il y a 2 min',score:61,state:'Action requise'},
      {name:'Portable — Finance 018',meta:'Windows · vu il y a 4 min',score:68,state:'Action requise'},
      {name:'Serveur — Fichiers 007',meta:'Linux · vu à l’instant',score:73,state:'À surveiller'},
      {name:'Téléphone — Ventes 031',meta:'Android · vu il y a 1 min',score:84,state:'Surveillance'},
      {name:'Portable — RH 012',meta:'Windows · vu il y a 3 min',score:91,state:'Cohérence élevée'}
    ]
  };
  function homeState(score){
    if(score===null)return {color:'#6d7f89',title:'Calcul en attente',sub:'Aucune couverture suffisante pour calculer un indice sans inventer de résultat.',alert:'Données insuffisantes'};
    if(score>=85)return {color:'#47d89f',title:'Cohérence élevée dans les applications évaluées',sub:'Peu d’incohérences sont relevées par les règles disponibles.',alert:'Cohérence élevée'};
    if(score>=70)return {color:'#e3c35b',title:'Quelques éléments méritent une vérification',sub:'Les applications au score le plus faible sont affichées en premier.',alert:'Surveillance recommandée'};
    if(score>=50)return {color:'#ef9a4d',title:'Plusieurs observations demandent une vérification',sub:'Examine les permissions et le contexte avant de conclure.',alert:'Cohérence réduite'};
    return {color:'#ff5964',title:'Indice sous 50 %',sub:'Le rouge indique une priorité de revue, jamais une preuve d’activité malveillante.',alert:'Priorité de revue'};
  }
  function coherenceRead(method,...args){
    if(!nativeBridge||typeof nativeBridge[method]!=='function')return null;
    const value=JSON.parse(nativeBridge[method](...args));if(value.error)throw new Error(value.error);return value;
  }
  function setMvpMode(mode){
    mvpViewMode=mode==='ti'?'ti':'user';root.dataset.viewMode=mvpViewMode;
    $('jc-mode-user').setAttribute('aria-pressed',String(mvpViewMode==='user'));
    $('jc-mode-ti').setAttribute('aria-pressed',String(mvpViewMode==='ti'));
    if(state.tab!=='home')setTab('home');else renderMvpHome();
  }
  function renderFleetDemo(){
    const score=mvpFleet.score,st=homeState(score),ring=$('jc-score-ring'),list=$('jc-home-app-list'),pane=$('jc-pane-home');
    pane.dataset.lowScore='false';$('jc-endpoint-config').hidden=true;$('jc-refresh-status').textContent='Mode TI de démonstration : Actualiser ne contacte aucun parc réel.';
    $('jc-mode-banner').innerHTML='<strong>Vue TI · simulation MVP.</strong> Les données de parc ci-dessous sont fictives et servent uniquement à montrer l’interface. Les onglets techniques inspectent ce téléphone.';
    $('jc-home-eyebrow').textContent='État global du parc · simulation';$('jc-score-label').textContent='score du parc · simulé';
    ring.style.setProperty('--score-color',st.color);ring.style.setProperty('--score-angle',`${score*3.6}deg`);ring.setAttribute('aria-label',`Simulation TI : score du parc ${score} pour cent`);$('jc-score-number').textContent=score+'%';
    $('jc-home-title').textContent='Attention, 3 appareils présentent des éléments à examiner.';$('jc-home-sub').textContent='Démonstration d’un parc de 150 appareils. Aucune donnée de parc réelle n’est utilisée.';
    $('jc-home-alert').style.setProperty('--score-color',st.color);$('jc-home-alert-title').innerHTML='<span class="jc-sim-tag">Simulation</span>';$('jc-home-alert-text').textContent='Cette vue illustre seulement le futur mode technicien; elle ne déclenche aucune action sur un appareil.';
    pane.style.background='';$('jc-home-total').textContent=mvpFleet.total.toLocaleString('fr-CA');$('jc-home-evaluated').textContent=mvpFleet.total.toLocaleString('fr-CA');$('jc-home-unknown').textContent='0';$('jc-home-findings').textContent=mvpFleet.watch.toLocaleString('fr-CA');$('jc-home-app-count').textContent='0';
    $('jc-home-counter-0').textContent='appareils simulés';$('jc-home-counter-1').textContent='évalués · simulé';$('jc-home-counter-u').textContent='non évalués · simulé';$('jc-home-counter-2').textContent='alertes · simulé';$('jc-home-counter-3').textContent='non attribuables · simulé';$('jc-home-list-title').textContent='Appareils à examiner · simulation';
    list.replaceChildren();for(const d of mvpFleet.devices){const row=element('div',undefined,'jc-home-app'),info=element('div');info.append(element('strong',d.name),element('p',d.meta+' · '+d.state,'jc-sub'));const impact=element('span',d.score+' %','jc-home-impact');impact.style.setProperty('--home-app-color',d.score<50?'#ff5964':d.score<70?'#ef9a4d':d.score<85?'#e3c35b':'#47d89f');row.append(info,impact);list.append(row);}
    $('jc-home-note').textContent='Mode TI de démonstration : les appareils, scores et alertes de parc sont simulés. Les données réelles de ce téléphone ne sont jamais présentées comme des données de parc.';
  }
  function renderLegacyUserHome(status){
    const ring=$('jc-score-ring'),number=$('jc-score-number'),list=$('jc-home-app-list'),pane=$('jc-pane-home');pane.dataset.lowScore='false';pane.style.background='';
    try{
      const s=aivRead('aivSummary');
      if(!s){number.textContent='--%';$('jc-home-title').textContent='Moteur de cohérence non encore relié';$('jc-home-sub').textContent='Actualiser peut déjà refaire l’inventaire local; relie ensuite le moteur HTTPS pour calculer l’indice.';list.replaceChildren();return;}
      const evaluated=Math.max(0,Number(s.stats_evaluated)||0),findings=Math.max(0,Number(s.findings)||0),apps=Array.isArray(s.apps)?s.apps:[];
      const score=evaluated?Math.max(0,Math.min(100,Math.round(100-(findings/evaluated*100)))):null,st=homeState(score);
      ring.style.setProperty('--score-color',st.color);ring.style.setProperty('--score-angle',`${score===null?0:score*3.6}deg`);number.textContent=score===null?'--%':score+'%';$('jc-home-title').textContent='Résultat de secours basé sur les décisions AIV locales';$('jc-home-sub').textContent='Le moteur de cohérence des permissions n’a pas encore produit de résultat. Cette valeur de secours n’est pas un verdict de sécurité.';
      $('jc-home-alert').style.setProperty('--score-color',st.color);$('jc-home-alert-title').textContent='Moteur de cohérence en attente';$('jc-home-alert-text').textContent=status&&status.message?status.message:'Relie une URL HTTPS puis appuie sur Actualiser.';
      $('jc-home-total').textContent=apps.length.toLocaleString('fr-CA');$('jc-home-evaluated').textContent=evaluated.toLocaleString('fr-CA');$('jc-home-unknown').textContent=Math.max(0,apps.length-evaluated).toLocaleString('fr-CA');$('jc-home-findings').textContent=findings.toLocaleString('fr-CA');$('jc-home-app-count').textContent='—';
      $('jc-home-counter-0').textContent='applications observées';$('jc-home-counter-1').textContent='décisions AIV';$('jc-home-counter-u').textContent='non évaluées';$('jc-home-counter-2').textContent='signalements AIV';$('jc-home-counter-3').textContent='attribution réseau';$('jc-home-list-title').textContent='Données AIV locales · secours';
      list.replaceChildren();const ranked=[...apps].filter(a=>Number(a.evaluated)>0).sort((a,b)=>(Number(b.ratio)||0)-(Number(a.ratio)||0)).slice(0,10);for(const a of ranked){const ratio=Math.max(0,Number(a.ratio)||0),pct=Math.min(100,Math.round(ratio*100)),row=element('div',undefined,'jc-home-app'),info=element('div');info.append(element('strong',a.app||'Application non identifiée'),element('p',`${Number(a.findings)||0} signalement(s) / ${Number(a.evaluated)||0} décision(s)`,'jc-sub'));const impact=element('span',pct+' % signalé','jc-home-impact');impact.style.setProperty('--home-app-color',pct>=50?'#ff5964':pct>=25?'#ef9a4d':pct>=10?'#e3c35b':'#47d89f');row.append(info,impact);list.append(row);}
      if(!ranked.length)list.append(element('p','Aucune décision AIV évaluée pour le moment.','jc-sub'));
    }catch(e){number.textContent='--%';$('jc-home-title').textContent='Indice temporairement indisponible';$('jc-home-sub').textContent=e.message||String(e);list.replaceChildren();}
  }
  function renderUserHome(){
    $('jc-mode-banner').innerHTML='<strong>Vue utilisateur.</strong> L’inventaire provient de ce téléphone. Le calcul distant ne reçoit que le nom du paquet et les permissions demandées/déclarées.';
    $('jc-home-eyebrow').textContent='Cohérence des permissions · trois groupes';$('jc-score-label').textContent='indice observé';
    let status=null,coherence=null;try{status=coherenceRead('coherenceStatus');coherence=coherenceRead('coherenceSummary');}catch(e){$('jc-refresh-status').textContent=e.message||String(e);}
    const config=$('jc-endpoint-config');config.hidden=!(nativeBridge&&nativeBridge.coherenceConfigureEndpoint&&(!status||!status.endpoint_configured));
    if(status&&status.endpoint_configured&&$('jc-coherence-endpoint'))$('jc-coherence-endpoint').value=status.endpoint||'';
    if(coherence&&Array.isArray(coherence.groups))renderGroupedHome(coherence,status);else renderLegacyUserHome(status);
    if(status&&status.message)$('jc-refresh-status').textContent=status.message;
    $('jc-home-refresh').disabled=Boolean(status&&status.running);
    $('jc-home-refresh').textContent=status&&status.running?'Actualisation…':'Actualiser';
  }
  function renderMvpHome(){if(mvpViewMode==='ti'){delete $('jc-score-ring').dataset.penaltyColor;renderFleetDemo();}else renderUserHome();}
  function stopCoherencePoll(){if(coherencePollTimer){clearInterval(coherencePollTimer);coherencePollTimer=0;}}
  function startCoherenceRefresh(){
    if(mvpViewMode==='ti'){renderFleetDemo();return;}
    try{
      const started=coherenceRead('coherenceRefresh');if(!started){$('jc-refresh-status').textContent='Cette version du lecteur ne possède pas encore le pont d’actualisation.';return;}
      renderUserHome();stopCoherencePoll();let ticks=0;
      coherencePollTimer=setInterval(()=>{ticks++;try{const s=coherenceRead('coherenceStatus');renderUserHome();if(!s||!s.running||ticks>=70)stopCoherencePoll();}catch(e){$('jc-refresh-status').textContent=e.message||String(e);stopCoherencePoll();}},1000);
    }catch(e){$('jc-refresh-status').textContent=e.message||String(e);}
  }
  $('jc-mode-user').onclick=()=>setMvpMode('user');$('jc-mode-ti').onclick=()=>setMvpMode('ti');$('jc-home-refresh').onclick=startCoherenceRefresh;$('jc-home-details-ti').onclick=()=>setMvpMode('ti');root.querySelectorAll('[data-home-target]').forEach(btn=>btn.onclick=()=>setTab(btn.dataset.homeTarget));root.querySelectorAll('[data-menu-target]').forEach(btn=>btn.onclick=()=>setTab(btn.dataset.menuTarget));
  $('jc-coherence-link').onclick=()=>{try{const result=coherenceRead('coherenceConfigureEndpoint',$('jc-coherence-endpoint').value);$('jc-refresh-status').textContent=result&&result.message?result.message:'Configuration enregistrée.';renderUserHome();}catch(e){$('jc-refresh-status').textContent=e.message||String(e);}};
  root.dataset.viewMode='user';
