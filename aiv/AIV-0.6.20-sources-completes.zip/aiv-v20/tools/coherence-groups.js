  const groupNames={android:'Android',system:'Système',user:'Utilisateur',all:'Toutes les applications'};
  const groupDescriptions={android:'UID réservé/partagé · auteur non unique',system:'Préinstallées · package unique',user:'Installées par l’utilisateur · package unique'};
  const categoryNames={email:'Courriel',messaging:'Messagerie',video:'Vidéo',contacts:'Contacts',weather:'Météo',browser:'Navigateur',photos:'Photos',social:'Réseau social',navigation:'Navigation',utility:'Utilitaire',secure_storage:'Stockage sécurisé',system:'Composant système',unknown:'Fonction inconnue'};
  let homeGroup='all',homeLimit=25,journalGroupTimer=0;
  function scoreValue(value){return typeof value!=='number'||!Number.isFinite(value)?null:Math.max(0,Math.min(100,value));}
  function appScoreColor(value){return value===null?'#6d7f89':value<50?'#ff5964':homeState(value).color;}
  function renderGroupRings(c){
    const holder=$('jc-group-rings');holder.replaceChildren();
    for(const id of ['android','system','user']){
      const g=(c.groups||[]).find(g=>g.id===id)||{},score=scoreValue(g.score),button=element('button',undefined,'jc-group-card');button.type='button';button.dataset.group=id;
      button.setAttribute('aria-pressed',String(homeGroup===id));button.setAttribute('aria-label',`${groupNames[id]} : ${score===null?'score indisponible':score+' pour cent'}. Voir les applications.`);
      const disc=element('span',undefined,'jc-group-disc');disc.style.setProperty('--score-color',appScoreColor(score));disc.style.setProperty('--score-angle',`${score===null?0:score*3.6}deg`);disc.append(element('span',score===null?'—':score+'%','jc-group-number'));
      button.append(element('strong',groupNames[id]),disc,element('span',groupDescriptions[id],'jc-group-meta'),element('span',`${Number(g.evaluated_count)||0} / ${Number(g.app_count)||0} évaluées`,'jc-group-meta'),element('span',`${Number(g.below_50)||0} sous 50 %`,Number(g.below_50)>0?'jc-group-low':'jc-group-meta'));
      button.onclick=()=>{homeGroup=id;homeLimit=25;renderUserHome();};holder.append(button);
    }
  }
  function renderGroupedHome(c,status){
    const list=$('jc-home-app-list'),pane=$('jc-pane-home'),ring=$('jc-score-ring');pane.dataset.lowScore='false';pane.style.background='';renderGroupRings(c);
    const globalScore=scoreValue(c.score),globalState=homeState(globalScore);ring.style.setProperty('--score-color',globalState.color);ring.style.setProperty('--score-angle',`${globalScore===null?0:globalScore*3.6}deg`);ring.setAttribute('aria-label',`Indice global ${globalScore===null?'indisponible':globalScore+' pour cent'}`);$('jc-score-number').textContent=globalScore===null?'—':globalScore+'%';
    const selected=homeGroup==='all'?c:(c.groups||[]).find(g=>g.id===homeGroup)||{};
    const score=scoreValue(selected.score),low=Number(selected.below_50)||0,total=Number(selected.app_count)||0,evaluated=Number(selected.evaluated_count)||0,unknown=Number(selected.unknown_count)||0;
    $('jc-home-title').textContent=low?`${low} application(s) sous 50 % · ${groupNames[homeGroup]}`:c.available?'Trois groupes, trois moyennes distinctes':'Les trois groupes attendent leur calcul';
    $('jc-home-sub').textContent='Le cercle principal est la moyenne des applications réellement évaluées. Les non-évaluées restent visibles mais ne modifient pas le dénominateur. Les trois cercles montrent les groupes exclusifs.';
    $('jc-home-alert').style.setProperty('--score-color',low?'#ff5964':appScoreColor(score));
    $('jc-home-alert-title').textContent=homeGroup==='all'?'Comment lire ces scores':groupNames[homeGroup]+' · détail du calcul';
    $('jc-home-alert-text').textContent=`${Number(selected.sum_scores)||0} points ÷ ${evaluated} évaluée(s) = ${score===null?'indisponible':score+' % (arrondi)'}. ${unknown} non évaluée(s) restent affichées mais exclues de la moyenne. Inconnu ne signifie ni sûr ni malveillant. `+(selected.minimum===null||selected.minimum===undefined?'':`Score le plus bas : ${selected.minimum} %.`);
    const transparency=c.transparency||{};$('jc-home-total').textContent=total.toLocaleString('fr-CA');$('jc-home-evaluated').textContent=evaluated.toLocaleString('fr-CA');$('jc-home-unknown').textContent=unknown.toLocaleString('fr-CA');$('jc-home-findings').textContent=(homeGroup==='all'?Number(c.anomalies)||0:Number(selected.incoherences)||0).toLocaleString('fr-CA');$('jc-home-app-count').textContent=(Number(transparency.non_attributable)||0).toLocaleString('fr-CA');
    $('jc-home-counter-0').textContent=homeGroup==='all'?'applications observées':'dans ce groupe';$('jc-home-counter-1').textContent='applications évaluées';$('jc-home-counter-u').textContent='non évaluées / inconnues';$('jc-home-counter-2').textContent=homeGroup==='all'?'anomalies locales':'écarts du groupe';$('jc-home-counter-3').textContent='événements réseau non attribuables';
    $('jc-home-list-title').textContent=groupNames[homeGroup]+' · scores croissants';
    const query=$('jc-home-search').value.trim().toLocaleLowerCase('fr');
    const apps=(Array.isArray(c.apps)?c.apps:[]).filter(a=>(homeGroup==='all'||a.group===homeGroup)&&(!query||[a.label,a.package,categoryNames[a.category]||a.category].join(' ').toLocaleLowerCase('fr').includes(query)));
    list.replaceChildren();if(!apps.length)list.append(element('p','Aucune application pour ce filtre.','jc-sub'));
    for(const a of apps.slice(0,homeLimit)){
      const value=scoreValue(a.score),row=element('button',undefined,'jc-home-app'),info=element('span');row.type='button';row.dataset.package=a.package;row.dataset.lowScore=String(value!==null&&value<50);
      info.append(element('strong',a.label||a.package),element('span',`${groupNames[a.group]} · UID ${a.uid>=0?a.uid:'non disponible'}`,'jc-sub'),element('span',a.group_reason||groupDescriptions[a.group],'jc-sub'),element('span',`${a.category==='unknown'?'Permissions à examiner':categoryNames[a.category]||a.category} · ${Number(a.incoherences)||0} écart(s)`,'jc-sub'),element('span','Voir les permissions et le calcul →','jc-app-detail-hint'));
      const impact=element('span',value===null?'Non évaluée':value+' %','jc-home-impact');impact.style.setProperty('--home-app-color',appScoreColor(value));row.append(info,impact);
      row.onclick=()=>{setTab('audit');renderAuditDetail(a.package);};list.append(row);
    }
    $('jc-home-more').hidden=apps.length<=homeLimit;$('jc-group-all').setAttribute('aria-pressed',String(homeGroup==='all'));
    const journal=c.journal||{},pending=journal.complete===false;
    const t=c.transparency||{};$('jc-home-note').textContent='Android : UID réservé, partagé ou identité non unique. Système : application préinstallée avec package unique. Utilisateur : application installée par l’utilisateur avec package unique. Une liste de paquets candidats n’est jamais une preuve d’auteur. '+(t.complete===false?'La mesure de transparence réseau est encore en indexation. ':'')+(journal.error?'Classement provisoire : '+journal.error:pending?'Index du journal en cours.':'Chaque paquet de l’inventaire apparaît dans un seul groupe.');
    if(journalGroupTimer){clearTimeout(journalGroupTimer);journalGroupTimer=0;}
    if(pending&&!journal.error)journalGroupTimer=setTimeout(()=>{journalGroupTimer=0;if(state.tab==='home'&&mvpViewMode==='user'&&document.visibilityState!=='hidden')renderUserHome();},1000);
    $('jc-refresh-status').textContent=status&&status.message?status.message:`Dernier calcul : ${c.generated_at_ms?new Date(c.generated_at_ms).toLocaleString('fr-CA'):'aucun'}.`;
  }
  function renderCoherenceDetail(pane,pkg){
    const box=element('section',undefined,'ja-card jc-verdict-detail');box.id='jc-verdict-detail';box.append(element('h3','Calcul de cohérence'));
    const back=element('button','Retour aux trois scores');back.type='button';back.onclick=()=>setTab('home');box.append(back);
    try{
      const data=coherenceRead('coherenceDetail',pkg);
      if(!data||!data.available){box.append(element('p',data&&data.message||'Aucun calcul enregistré. Actualise depuis l’accueil.','jc-sub'));pane.append(box);return;}
      const v=data.verdict,unknown=v.category==='unknown',score=unknown?null:scoreValue(v.score_local),issues=v.incoherences_local||[];
      box.dataset.lowScore=String(score!==null&&score<50);box.append(element('strong',(score===null?'Non évaluée':score+' %')+' · '+(unknown?'Fonction à préciser':(categoryNames[v.category]||v.category))),element('p','Une fonction totalement inconnue reste visible mais est exclue de la moyenne. Le groupe repose sur l’identité Android : UID réservé/partagé ou package unique. Une permission déclarée ne prouve pas son utilisation.','jc-sub'));const flows=element('button','Voir ses flux réseau');flows.type='button';flows.onclick=()=>flowOpen(pkg);box.append(flows);
      const complete=issues.every(i=>Number.isFinite(i.penalty));
      if(complete&&score!==null){const penalties=issues.reduce((sum,i)=>sum+i.penalty,0);box.append(element('p',`100 points − ${penalties} points de pénalité = ${Math.max(0,100-penalties)} % (minimum 0).`));}
      else if(!complete)box.append(element('p','Ancien résultat : appuie sur Actualiser pour obtenir le détail des points.','jc-sub'));
      for(const issue of issues){const item=element('article',undefined,'jc-verdict-issue');item.append(element('strong',(issue.permission==='*'?'Cumul ou volume':issue.permission)+(Number.isFinite(issue.penalty)?' · −'+issue.penalty+' points':'')),element('p',issue.reason));box.append(item);}
      if(!issues.length)box.append(element('p','Aucun écart relevé par les règles disponibles.'));
      box.append(element('p',`Moteur ${data.engine} · ${data.generated_at_ms?new Date(data.generated_at_ms).toLocaleString('fr-CA'):'date inconnue'}. Permissions déclarées; leur utilisation n’est pas établie par ce calcul.`,'jc-sub'));
    }catch(e){box.append(element('p',e.message,'jc-error'));}
    pane.append(box);
  }
  $('jc-group-all').onclick=()=>{homeGroup='all';homeLimit=25;renderUserHome();};
  $('jc-home-search').oninput=()=>{homeLimit=25;renderUserHome();};
  $('jc-home-more').onclick=()=>{homeLimit+=25;renderUserHome();};
