#!/usr/bin/env python3
"""Independent verifier: Python standard library + local OpenSSL; never uses the network.
Exit 0: valid and caller-pinned signing key. Exit 2: valid but unsigned/untrusted key.
Exit 1: malformed, corrupted, invalid signature or key mismatch.
"""
import argparse,base64,hashlib,json,pathlib,struct,subprocess,tempfile
GENESIS='0'*64

def strict_object(items):
 d={}
 for k,v in items:
  if k in d:raise ValueError('duplicate JSON key: '+k)
  d[k]=v
 return d

def parse(raw):return json.loads(raw,object_pairs_hook=strict_object)
def pack(*parts):return ''.join('-1:' if s is None else str(len(str(s).encode('utf-8')))+':'+str(s) for s in parts)
def unpack(text):
 data=text.encode('utf-8');parts=[];at=0
 while at<len(data):
  end=data.index(b':',at);n=int(data[at:end]);at=end+1
  if n==-1:parts.append(None);continue
  if n<0 or at+n>len(data):raise ValueError('invalid framed field')
  parts.append(data[at:at+n].decode('utf-8'));at+=n
 return parts

def chain_hash(prev,payload,ts,seq):
 if len(prev)!=64 or any(x not in '0123456789abcdef' for x in prev):raise ValueError('invalid previous hash')
 p=payload.encode('utf-8');return hashlib.sha256(b'AIV-CHAIN-1\0'+bytes.fromhex(prev)+struct.pack('>qqi',seq,ts,len(p))+p).hexdigest()

def check(path,key_pin=None):
 digest=hashlib.sha256();head=GENESIS;count=0;previous_event=0;pending=None;footer=None
 with open(path,'rb') as src:
  line=src.readline(64*1024*1024+1)
  if not line.endswith(b'\n'):raise ValueError('truncated header')
  header=parse(line)
  if header.get('type')!='HEADER' or header.get('format')!='AIV-EXPORT-1' or header.get('genesis')!=GENESIS:raise ValueError('bad header')
  digest.update(line)
  for raw in src:
   if len(raw)>64*1024*1024 or not raw.endswith(b'\n'):raise ValueError('truncated/oversized line')
   r=parse(raw)
   if r.get('type')=='FOOTER':
    footer=r
    if src.read(1):raise ValueError('data after footer')
    break
   if r.get('type')!='RECORD':raise ValueError('unexpected record')
   count+=1
   if r['id']!=count or r['hash_prev']!=head:raise ValueError('order/link mismatch')
   expected=chain_hash(head,r['payload'],r['timestamp_ms'],count)
   if expected!=r['hash_self']:raise ValueError('hash mismatch at '+str(count))
   f=unpack(r['payload'])
   if r['kind']=='EVENT':
    if pending is not None or len(f)!=10 or f[0]!='EVENT' or int(f[1])!=r['event_id'] or int(f[2])!=r['timestamp_ms'] or r['decision_id'] is not None:raise ValueError('event binding mismatch')
    if r['event_id']<=previous_event:raise ValueError('event order mismatch')
    previous_event=r['event_id'];pending=(r['event_id'],r['hash_self'])
   elif r['kind']=='DECISION':
    if pending is None or len(f)!=8 or f[0]!='DECISION' or int(f[1])!=r['decision_id'] or int(f[2])!=r['event_id'] or int(f[6])!=r['timestamp_ms'] or f[7]!='NOT_ENFORCED' or f[4] not in ['ALLOW','DENIED','WATCH']:raise ValueError('decision binding mismatch')
    if r['event_id']!=pending[0] or parse(f[5]).get('event_hash')!=pending[1]:raise ValueError('decision-source mismatch')
    pending=None
   else:raise ValueError('unknown record kind')
   head=expected;digest.update(raw)
 if not footer or pending or header['count']!=count or header['head']!=head or header['checkpoint']!=previous_event:raise ValueError('incomplete chain/export')
 global_hash=digest.hexdigest()
 if footer['sha256']!=global_hash:raise ValueError('export hash mismatch')
 signed=header['signature_status']=='SIGNED'
 if signed:
  if footer['algorithm']!='SHA256withECDSA' or not footer.get('signature'):raise ValueError('signature missing')
  public=base64.b64decode(header['public_key_spki'],validate=True);fingerprint=hashlib.sha256(public).hexdigest()
  if fingerprint!=header['key_id']:raise ValueError('key ID mismatch')
  if key_pin is not None and fingerprint!=key_pin:raise ValueError('key pin mismatch')
  with tempfile.TemporaryDirectory() as tmp:
   d=pathlib.Path(tmp);(d/'public.der').write_bytes(public);(d/'signature.der').write_bytes(base64.b64decode(footer['signature'],validate=True));(d/'message').write_bytes(('AIV-EXPORT-1\n'+global_hash).encode('ascii'))
   subprocess.run(['openssl','pkey','-pubin','-inform','DER','-in',str(d/'public.der'),'-out',str(d/'public.pem')],check=True,capture_output=True)
   subprocess.run(['openssl','dgst','-sha256','-verify',str(d/'public.pem'),'-signature',str(d/'signature.der'),str(d/'message')],check=True,capture_output=True)
 else:
  if header['signature_status']!='UNSIGNED_KEYSTORE_UNAVAILABLE' or footer['algorithm']!='NONE' or footer.get('signature') is not None or key_pin is not None:raise ValueError('unsigned status/key pin mismatch')
 return {'valid':True,'records':count,'head':head,'sha256':global_hash,'signature_valid':signed,'trusted_key':signed and key_pin is not None,'key_id':header.get('key_id'),'scope':'Snapshot integrity; compare earlier signed heads to detect deletion/rollback across exports.'}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('file',type=pathlib.Path);p.add_argument('--key-sha256',help='Trusted public-key SPKI hash obtained separately from the phone');a=p.parse_args()
 try:
  result=check(a.file,a.key_sha256);print(json.dumps(result,indent=2));raise SystemExit(0 if result['trusted_key'] else 2)
 except (ValueError,KeyError,TypeError,OSError,subprocess.CalledProcessError) as e:print(json.dumps({'valid':False,'error':str(e)}));raise SystemExit(1)
