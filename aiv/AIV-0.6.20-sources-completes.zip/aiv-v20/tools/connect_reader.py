from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'tools/reader-base.html').read_text()
s=s.replace('    <button type="button" data-jc-tab="permissions"', '    <button type="button" id="jc-analysis-tab" data-jc-tab="anomalies" aria-pressed="false" aria-controls="jc-pane-anomalies">Anomalies</button>\n    <button type="button" data-jc-tab="permissions"')
s=s.replace('  <section class="jc-pane" id="jc-pane-permissions"', (root/'tools/analysis-pane.html').read_text()+'\n  <section class="jc-pane" id="jc-pane-permissions"')
s=s.replace("['journal','permissions','sources']", "['journal','audit','anomalies','diagnostic','permissions','sources']")
s=s.replace("if(tab==='sources')renderSources(); }", "if(tab==='sources')renderSources(); if(tab==='audit')renderAudit(); if(tab==='anomalies')renderAnalysis(); if(tab==='diagnostic')renderDiagnostic(true); }")
s=s.replace("['Fichier importé',source?source.name:'Inconnu']", "[nativeBridge?'Stockage local':'Fichier importé',source?source.name:'Inconnu']")
s=s.replace("['Statut de lecture','Événement rapporté par le fichier; non vérifié sur le téléphone']", "['Statut de lecture',nativeBridge?(['trafic','dns'].includes(event.original.category)?'Métadonnées reçues du VPN local et enregistrées dans la base privée':'État communiqué par Android et enregistré dans la base privée'):'Événement rapporté par le fichier; non vérifié sur le téléphone']")
s=s.replace("element('span',event.destination,'jc-sub')", "element('span',(nativeBridge?(event.original.category==='trafic'?'Destination contactée : ':event.original.category==='dns'?'Nom recherché : ':'Ressource : '):'')+event.destination,'jc-sub')")
s=s.replace("pane.append(fields);", "pane.append(fields); if(nativeBridge&&event.original.source==='ConnectivityManager.onLinkPropertiesChanged')pane.append(element('p','Paramètres réseau reçus : premier relevé ou mise à jour. Un changement de DNS est signalé dans Anomalies seulement après comparaison de deux relevés du même réseau.','jc-note'));")
s=s.replace('    <button type="button" data-jc-tab="sources"', '    <button type="button" data-jc-tab="diagnostic" aria-pressed="false" aria-controls="jc-pane-diagnostic">Diagnostic</button>\n    <button type="button" data-jc-tab="sources"')
s=s.replace('  <section class="jc-pane" id="jc-pane-sources"', (root/'tools/diagnostic-pane.html').read_text()+'\n  <section class="jc-pane" id="jc-pane-sources"')
s=s.replace("pane.append(fields);", "pane.append(fields); nativeDetailExtras(pane,event);")
start=s.index("    const list=$('jc-events');list.replaceChildren();")
end=s.index("    $('jc-empty').hidden=filtered.length>0;",start)
block=s[start:end].replace('filtered.slice(state.page*PAGE_SIZE,(state.page+1)*PAGE_SIZE)','rows')
s=s[:start]+"    renderRows(filtered.slice(state.page*PAGE_SIZE,(state.page+1)*PAGE_SIZE));\n"+s[end:]
s=s.replace('  function renderJournal() {','  function renderRows(rows) {\n'+block+'  }\n  function renderJournal() {\n    if(nativeBridge){renderNative();return;}')
s=s.replace('  function renderSources() {','  function renderSources() {\n    if(nativeBridge){renderNativeSources();return;}')
s=s.replace('    <button type="button" data-jc-tab="permissions"', '    <button type="button" data-jc-tab="audit" aria-pressed="false" aria-controls="jc-pane-audit">Applications</button>\n    <button type="button" data-jc-tab="permissions"')
s=s.replace('  <section class="jc-pane" id="jc-pane-permissions"', (root/'tools/audit-pane.html').read_text()+'\n  <section class="jc-pane" id="jc-pane-permissions"')
s=s.replace('<script>', '<style>'+(root/'tools/audit-theme.css').read_text()+'</style><script>',1)
s=s.replace('<div class="jc-mark" aria-hidden="true">J</div>', '<div class="jc-mark" aria-hidden="true">AIV</div>')
marker='  renderJournal();renderPermissions();renderSources();\n})();'
assert s.count(marker)==1
s=s.replace(marker,(root/'tools/native-adapter.js').read_text()+'\n'+(root/'tools/flow-adapter.js').read_text()+'\n'+(root/'tools/analysis-adapter.js').read_text()+'\n'+(root/'tools/diagnostic-adapter.js').read_text()+'\n'+(root/'tools/audit-rules.js').read_text()+'\n'+(root/'tools/audit-adapter.js').read_text()+'\n'+marker)
# Add a restrictive CSP for frames: the JS bridge must remain reachable only by the bundled page.
s=s.replace("default-src 'none';", "default-src 'none'; frame-src 'none'; child-src 'none';")
s=s.replace("['journal','audit','anomalies','diagnostic','permissions','sources']", "['journal','audit','anomalies','diagnostic','permissions','sources','decisions','references']")
s=s.replace("if(tab==='diagnostic')renderDiagnostic(true); }", "if(tab==='diagnostic')renderDiagnostic(true); if(tab==='decisions')renderAiv(); if(tab==='references')renderAivStatus(); }")
s=s.replace('    <button type="button" data-jc-tab="sources"', '<button type="button" id="aiv-tab" data-jc-tab="decisions" aria-pressed="false" aria-controls="jc-pane-decisions">Décisions</button><button type="button" data-jc-tab="references" aria-pressed="false" aria-controls="jc-pane-references">Référentiels</button>\n    <button type="button" data-jc-tab="sources"')
s=s.replace('  <section class="jc-pane" id="jc-pane-sources"', (root/'tools/aiv-pane.html').read_text()+'\n  <section class="jc-pane" id="jc-pane-sources"')
s=s.replace("nativeDetailExtras(pane,event);", "nativeDetailExtras(pane,event); aivEventExtras(pane,event);")
s=s.replace("if(document.visibilityState==='hidden')return;if(state.tab", "if(document.visibilityState==='hidden')return;pollAiv(state.tab);if(state.tab")
s=s.replace(marker,(root/'tools/aiv-adapter.js').read_text()+'\n'+marker)
# MVP home: two demonstrable views. User view reads local phone data; TI view is explicitly simulated.
home_css=(root/'tools/mvp-home.css').read_text()
home_html=(root/'tools/mvp-home.html').read_text()
home_js=(root/'tools/coherence-groups.js').read_text()+'\n'+(root/'tools/mvp-home.js').read_text()
needle='<div id="jc-reader" lang="fr">'
assert s.count(needle)==1
s=s.replace(needle,'<style>'+home_css+'</style>\n'+needle)
needle='    <button type="button" data-jc-tab="journal" aria-pressed="true" aria-controls="jc-pane-journal">Journal</button>'
assert s.count(needle)==1
s=s.replace(needle,'    <button type="button" data-jc-tab="home" aria-pressed="true" aria-controls="jc-pane-home">Accueil</button>\n'+needle.replace('aria-pressed="true"','aria-pressed="false"')+'\n    <button type="button" data-jc-tab="flows" aria-pressed="false" aria-controls="jc-pane-flows">Flux</button>')
# User mode keeps a compact navigation while TI retains the full technical tab bar.
nav_end='  </nav>'
assert s.count(nav_end)==1
user_nav='''  <nav class="jc-user-nav" aria-label="Navigation utilisateur">\n    <button type="button" data-jc-tab="home" aria-pressed="true" aria-controls="jc-pane-home">Accueil</button>\n    <button type="button" data-jc-tab="menu" aria-pressed="false" aria-controls="jc-pane-menu">Menu</button>\n  </nav>'''
s=s.replace(nav_end,nav_end+'\n'+user_nav,1)
needle='  <section class="jc-pane" id="jc-pane-journal"'
assert s.count(needle)==1
s=s.replace(needle,home_html+'\n'+(root/'tools/menu-pane.html').read_text()+'\n'+(root/'tools/flow-pane.html').read_text()+'\n'+needle)
assert "tab:'journal'" in s
s=s.replace("tab:'journal'","tab:'home'",1)
old_tabs="['journal','audit','anomalies','diagnostic','permissions','sources','decisions','references']"
assert old_tabs in s
s=s.replace(old_tabs,"['home','menu','journal','flows','audit','anomalies','diagnostic','permissions','sources','decisions','references']",1)
needle="if(tab==='references')renderAivStatus(); }"
assert needle in s
s=s.replace(needle,"if(tab==='references')renderAivStatus(); if(tab==='home')renderMvpHome(); if(tab==='flows')renderFlows(false); }",1)
# Insert after the AIV adapter so renderMvpHome can use aivRead().
needle=(root/'tools/aiv-adapter.js').read_text()+'\n'+marker
assert s.count(needle)==1
s=s.replace(needle,(root/'tools/aiv-adapter.js').read_text()+'\n'+home_js+'\n'+marker)
# Ensure initial render occurs even though the technical tab bar is hidden in user mode.
needle='  renderJournal();renderPermissions();renderSources();\n})();'
assert s.count(needle)==1
s=s.replace(needle,'  renderJournal();renderPermissions();renderSources();renderMvpHome();\n})();')
# Local configurable penalty model. The generated reader remains the only bridge surface.
s=s.replace("'references']", "'references','penalty']")
s=s.replace('  <section class="jc-pane" id="jc-pane-sources"', (root/'tools/penalty-pane.html').read_text()+'\n  <section class="jc-pane" id="jc-pane-sources"')
needle='  renderJournal();renderPermissions();renderSources();renderMvpHome();\n})();'
assert s.count(needle)==1
s=s.replace(needle,(root/'tools/penalty-model.js').read_text()+'\n'+(root/'tools/penalty-ui.js').read_text()+'\n'+needle)

s=s.replace('  renderJournal();renderPermissions();renderSources();renderMvpHome();\n})();',(root/'tools/usability.js').read_text()+'\n})();')
(root/'app/src/main/assets/journal.html').write_text(s,encoding='utf-8')
print('Native reader connected:',len(s.encode()),'bytes')
