  // V17: stable navigation and one prepared startup snapshot.
  function appIdentity(node,raw={}){
    const d=raw.details||raw.facts||raw,pkgs=d.packages||[],pkg=raw.package_name||d.package_name||(pkgs.length===1?pkgs[0]:null);
    const uid=d.uid??raw.uid;
    const apps=penaltyCache?penaltyCache.result.apps:[];
    const matches=pkg?apps.filter(a=>a.package_name===pkg&&(uid==null||a.uid===Number(uid))):uid!=null?apps.filter(a=>a.uid===Number(uid)):[];
    const a=matches.length===1?matches[0]:null;
    node.append(element('span',(a?a.label+' · ':raw.app?raw.app+' · ':'')+'UID '+(uid==null||Number(uid)<0?'non attribué':uid),'jc-identity'));
    if(a){node.dataset.penaltyColor=a.color;node.style.setProperty('--identity-color',penaltyColors[a.color]);}
  }
  const stableRows=renderRows;
  renderRows=function(rows){stableRows(rows);[...$('jc-events').children].forEach((node,i)=>{if(rows[i])appIdentity(node,rows[i].original);});};
  const nav=root.querySelector('.jc-user-nav');nav.replaceChildren();
  for(const [tab,label] of [['home','Accueil'],['journal','Journal'],['anomalies','Anomalies'],['decisions','Décisions'],['audit','Applications'],['menu','Paramètres']]){
    const b=penaltyButton(label,()=>setTab(tab));b.dataset.jcTab=tab;b.setAttribute('aria-pressed',String(tab==='home'));nav.append(b);
  }
  const menu=$('jc-pane-menu');menu.replaceChildren(element('h2','Paramètres'));
  for(const [tab,label] of [['penalty','Barème et formules'],['references','Référentiels']]){
    const detail=element('details'),pane=$('jc-pane-'+tab);detail.append(element('summary',label),pane);menu.append(detail);
    detail.addEventListener('toggle',()=>{if(detail.open){pane.hidden=false;if(tab==='penalty')renderPenaltySettings();else renderAivStatus();}});
  }
  if(nativeBridge){
    const collection=element('section');collection.id='jc-continuous';collection.append(element('h3','Collecte continue'));
    const status=element('p','','jc-sub');status.id='jc-continuous-status';collection.append(status);
    for(const id of ['jc-start-native','jc-capture-native','jc-stop-native','jc-capture-note'])collection.append($(id));
    collection.querySelector('#jc-start-native').textContent='Reprendre la collecte';
    collection.append(element('p','La collecte autorisée et l’analyse progressive fonctionnent en arrière-plan. Une pause volontaire est conservée. Android peut interrompre les services; les données déjà enregistrées restent conservées.','jc-sub'));
    menu.prepend(collection);
  }
  function refreshContinuous(){if(!nativeBridge)return;try{const s=JSON.parse(nativeBridge.continuousStatus?nativeBridge.continuousStatus():nativeBridge.status());$('jc-start-native').disabled=Boolean(s.collector||s.running);$('jc-stop-native').disabled=s.enabled===false&&!s.collector&&!s.running&&!s.vpn&&!s.capture;$('jc-capture-native').textContent=s.vpn||s.capture?'Arrêter les connexions apps':'Activer connexions apps';$('jc-continuous-status').textContent=(s.enabled===false?'Pause demandée':'Collecte continue demandée')+' · collecteur '+(s.collector||s.running?'actif':'arrêté')+' · VPN '+(s.vpn||s.capture?'actif':'arrêté')+' · analyse '+(s.analysis?'active':'arrêtée')+(s.vpn_error?' · '+s.vpn_error:'');}catch(e){}}
  const rules=$('aiv-config').closest('details');menu.append(rules);
  rules.addEventListener('toggle',()=>{if(rules.open){renderAivStatus();renderPenaltyColors();}});
  menu.append($('jc-analysis-settings'));
  for(const [tab,label]of [['diagnostic','Diagnostics importés'],['sources','Collecte et sources']])menu.append(penaltyButton(label,()=>setTab(tab)));
  const oldUsabilityTab=setTab;
  setTab=function(tab){
    if(tab==='penalty'||tab==='references'){
      oldUsabilityTab('menu');for(const name of ['penalty','references'])$('jc-pane-'+name).hidden=false;
      const detail=$('jc-pane-'+tab).parentElement;detail.open=true;if(tab==='penalty')renderPenaltySettings();else renderAivStatus();return;
    }
    oldUsabilityTab(tab);
    if(tab==='menu')refreshContinuous();
    if(tab==='menu')for(const name of ['penalty','references'])$('jc-pane-'+name).hidden=false;
    if(tab==='journal')renderJournal();
    if(tab==='anomalies')renderFlows(false);
    nav.querySelectorAll('button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.jcTab===tab||(tab==='flows'&&b.dataset.jcTab==='anomalies'))));
  };
  // Both modes describe this phone; no simulated percentages mixed into real data.
  $('jc-mode-ti').textContent='TI · téléphone';$('jc-home-details-ti').textContent='Vue TI';
  renderMvpHome=function(){renderUserHome();if(mvpViewMode==='ti')$('jc-mode-banner').textContent='Vue TI · données de ce téléphone. Même moyenne et même multiplicateur; détails techniques dans les fiches.';};
  renderUserHome=function(){if(nativeBridge&&nativeBridge.penaltyData)renderPenaltyHome();else{
    $('jc-score-number').textContent='—';$('jc-home-title').textContent='Ouvrir AIV depuis son icône Android';$('jc-home-sub').textContent='Ce lecteur n’a pas accès au journal du téléphone. Aucune donnée locale n’est remplacée.';$('jc-total').textContent='Journal local non accessible dans ce lecteur';
  }};
  // Linked series are computed on entry, without a separate linking action.
  const flows=$('jc-pane-flows'),anomalies=$('jc-pane-anomalies');
  const series=element('div');series.id='jc-series';series.hidden=true;anomalies.append(series);series.append(flows);
  const singleNodes=[...anomalies.children].filter(n=>n!==series);
  const tabs=element('div',undefined,'jc-actions');
  const single=penaltyButton('Signalements',()=>{singleNodes.forEach(n=>n.hidden=false);series.hidden=true;single.setAttribute('aria-pressed','true');linked.setAttribute('aria-pressed','false');renderAnalysis();});
  const linked=penaltyButton('Séries liées',()=>{singleNodes.forEach(n=>n.hidden=true);series.hidden=false;flows.hidden=false;single.setAttribute('aria-pressed','false');linked.setAttribute('aria-pressed','true');});
  tabs.append(single,linked);anomalies.prepend(tabs);single.setAttribute('aria-pressed','true');
  const baseTab=setTab;setTab=function(tab){if(tab==='flows'){baseTab('anomalies');linked.click();return;}baseTab(tab);if(tab==='anomalies'){flows.hidden=false;if(!series.hidden)singleNodes.forEach(n=>n.hidden=true);}};
  $('jf-status').before(element('p','Rapprochements automatiques dans la fenêtre affichée. Une destination commune ne prouve ni transfert entre applications ni cause d’un plantage.','jc-sub'));
  const analysisRefresh=penaltyButton('Actualiser',()=>{renderAnalysis();renderFlows(false);});tabs.append(analysisRefresh);
  function finishStartup(input){
    if(input){
      const raw=penaltyRead('penaltyConfig');
      const settings=penaltyValidateSettings(JSON.parse(JSON.stringify(raw)));
      // Install/migrate the bundled rules automatically, preserving all personal settings.
      if(JSON.stringify(raw)!==JSON.stringify(settings))penaltyRead('penaltySave',JSON.stringify(settings));
      penaltyCache={input,settings,result:penaltySnapshot(input,settings)};
    }
    if(state.tab==='home')renderMvpHome();if(state.tab!=='journal')$('jc-total').textContent='Historique conservé · ouvrir Journal pour le consulter';if(nativeBridge){refreshAnalysisStatus();if(analysisConfig)$('jc-quiet').value=analysisConfig.quiet===false?'all':'quiet';}
    const overlay=document.getElementById('jc-startup');if(overlay)overlay.remove();root.inert=false;
  }
  function beginStartup(){
    if(!nativeBridge||!nativeBridge.startupStatus){finishStartup();return;}
    root.inert=true;const overlay=element('div');overlay.id='jc-startup';overlay.setAttribute('role','status');
    overlay.append(element('div',undefined,'jc-spinner'),element('h2','Initialisation'),element('p','Calcul en cours'));document.body.append(overlay);overlay.append(penaltyButton('Consulter le journal pendant le calcul',()=>{overlay.remove();root.inert=false;setTab('journal');}));
    const poll=()=>{try{const status=JSON.parse(nativeBridge.startupStatus());overlay.querySelector('p').textContent=status.state;
      if(status.ready){finishStartup(JSON.parse(nativeBridge.startupData()));return;}
      if(status.error)throw Error(status.error);setTimeout(poll,250);
    }catch(e){overlay.querySelector('p').textContent='Initialisation incomplète : '+e.message;overlay.append(penaltyButton('Réessayer',()=>{if(nativeBridge.startupRetry)nativeBridge.startupRetry();overlay.remove();beginStartup();}),penaltyButton('Consulter le dernier relevé',()=>finishStartup()));}};
    setTimeout(poll,50);
  }
  // Paint the pending state before configuration writes and synchronous recalculation.
  const recomputeLabels=new Set(['Enregistrer et recalculer','Enregistrer les couleurs','Appliquer le JSON','Enregistrer les observations et recalculer']);
  let replayingSave=false;
  root.addEventListener('click',event=>{
    const button=event.target.closest('button');if(replayingSave||!button||!recomputeLabels.has(button.textContent))return;
    event.preventDefault();event.stopImmediatePropagation();root.inert=true;
    const overlay=element('div');overlay.id='jc-recalculation';overlay.setAttribute('role','status');overlay.append(element('div',undefined,'jc-spinner'),element('h2','Recalcul en cours'),element('p','Application des paramètres et préparation des résultats'));document.body.append(overlay);
    setTimeout(()=>{try{replayingSave=true;button.click();penaltyLoad(true);renderMvpHome();overlay.remove();root.inert=false;}
      catch(e){penaltyCache=null;overlay.querySelector('p').textContent='Résultats indisponibles : '+e.message;overlay.append(penaltyButton('Revenir aux paramètres',()=>{overlay.remove();root.inert=false;setTab('menu');}));}
      finally{replayingSave=false;}},60);
  },true);
  beginStartup();
