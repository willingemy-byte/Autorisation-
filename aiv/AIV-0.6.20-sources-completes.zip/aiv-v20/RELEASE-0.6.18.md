# AIV 0.6.18 — détection automatique et multiplicateurs

Installer AIV-0.6.18-signed.apk comme mise à jour, sans désinstaller AIV. Ouvrir ensuite son icône et attendre « Initialisation ». L’inventaire des composants et le calcul démarrent automatiquement. Le journal, les règles et les références existantes restent conservés. La clé de signature et l’identifiant de l’application sont identiques.

## Calcul demandé

Le centre du cercle reste ΣH / nombre d’applications avec H > 0. H mesure l’écart à la référence de visibilité sélectionnée. Les références automatiques restent des estimations; aucune lecture automatique des écrans Google Play n’est prétendue.

Le multiplicateur séparé vaut F2 × F3 × F4 × F5 :

- F2 = max(1, 2 × nombre de capacités distinctes L2).
- F3 = max(1, 3 × nombre de capacités distinctes L3).
- F4 = max(1, somme des portées des capacités distinctes L4).
- F5 = max(1, nombre de paquets reliés par les sources d’installation Android), uniquement si un constat L5 confirme explicitement un accès spécial actif hors des permissions ordinaires. Mode fixe ou désactivé également disponible.

Exemple : 25 capacités L2 → 50; 25 capacités L3 → 75; 25 capacités L4 de portée 25 → 625. Multiplicateur total : 50 × 75 × 625 = 2 343 750. Cet exemple n’est pas une mesure du téléphone.

Une seule capacité L4 avec 25 clients donne une portée de 25, pas 625. Les répétitions de la même permission sont dédupliquées. Plusieurs niveaux peuvent qualifier la même permission, mais celle-ci n’est comptée qu’une fois par niveau. Pour L4, plusieurs composants protégés par la même permission forment une seule capacité; les paquets clients sont réunis sans doublons.

Les seuils de couleur restent basés sur le multiplicateur. Ils se modifient dans Paramètres, avec le barème et les règles R1 à R6. L’ancien produit des portées L4 reste sélectionnable; l’addition est le nouveau défaut demandé.

## Détection ajoutée

Un catalogue initial de 15 permissions documentées recherche les appels, les journaux d’appels, les contacts, les SMS, l’installation/suppression de paquets et certains pouvoirs privilégiés de gestion. Les permissions doivent être accordées dans l’inventaire pour déclencher ces règles. Ce catalogue est une classification AIV de possibilités documentées, pas une preuve d’utilisation ou de contournement d’Android.

Les descriptions de permissions définies par `android` peuvent aussi déclencher L2 si elles commencent par une formulation affirmative reconnue et comportent une mention explicite d’autonomie (« à votre insu », « sans votre intervention/confirmation », « without your knowledge/confirmation »). C’est une détection textuelle limitée; les formulations inconnues restent non classifiées. Les descriptions d’une autre application ne sont pas utilisées par ce détecteur textuel d’autonomie.

L3 nécessite une capacité L2 et un avertissement effectivement retourné dans la description de permission par Android, contenant « malveillant » ou « malicious ». La seule classe technique « dangerous » ne suffit pas. Les textes trouvés restent visibles dans la fiche. Un avertissement présent uniquement dans une capture de paramètres n’est pas automatiquement accessible par cet inventaire.

L’inventaire collecte maintenant les fournisseurs de données, services, activités et récepteurs : nom, état activé, exportation et permissions d’entrée. Les fournisseurs exposent aussi leurs protections de lecture/écriture et la présence de restrictions par chemin.

AIV rapproche les composants exportés et activés des autres paquets activés du même profil détenant la permission requise. Il affiche ces relations dans « Accès interapplications potentiels ». Les composants répétés, le paquet lui-même, les clients du même UID et les autres profils n’augmentent pas ce décompte.

Pour déclencher un facteur L4 automatique, la permission de passage doit aussi être détenue par le fournisseur et identifiée comme moins visible dans sa référence. Les liens détectés qui ne remplissent pas ces conditions restent consultables sans fabriquer un facteur.

Une interface accessible n’accorde pas toutes les permissions du fournisseur à son client. Les restrictions AppOps, les contrôles internes, les chemins, les rôles, les privilèges d’UID et l’exécution réelle ne sont pas vérifiés. Les interfaces sans permission d’entrée ne sont pas transformées automatiquement en autant de clients que d’applications installées. Aucun composant n’est invoqué pour le tester; aucun contact ou journal d’appels n’est lu ou modifié par cette analyse.

Les permissions privilégiées de gestion peuvent aussi utiliser la portée potentielle définie dans le barème L4 (tous les paquets du profil, valeur fixe ou désactivé). Cette pondération reste explicitement distinguée d’une liste de clients observés.

## Limites visibles plutôt qu’un faux vert

Les capacités inconnues sont listées dans les fiches. Une analyse partielle avec un multiplicateur neutre ×1 est grise. Un multiplicateur supérieur reste un résultat partiel lorsque des capacités ne sont pas couvertes. Le total de permissions moins visibles ne suffit pas à inventer une capacité d’appel ou une délégation.

Un simple compte manuel de permissions visibles ne permet pas de désigner automatiquement quelles permissions sont cachées. Les observations individuelles ou les noms de candidats de la référence estimée sont nécessaires au rattachement des niveaux.

L’accès « Installer des applis inconnues » d’une autre application ne peut pas être déduit du seul nom REQUEST_INSTALL_PACKAGES. Les anciens constats L5 sont désormais évalués lorsqu’ils ont la bonne version et confirment explicitement `active: true`, `outside_permissions: true` et le lien avec du moins visible. Aucune capture n’a été attribuée arbitrairement à un paquet Samsung.

## Réglages

Paramètres → Barème et formules : activer/désactiver les détecteurs, régler les niveaux, choisir addition ou produit L4, régler L5 et les couleurs. Dans le JSON, `automatic.catalog` contient les règles automatiques modifiables avec leurs sources; `rules` conserve les règles personnelles. Les réglages existants sont migrés en schéma /3 sans effacer les observations.

Correction supplémentaire : Android acceptait uniquement le schéma /1 alors que l’interface utilisait /2. L’enregistrement accepte maintenant /1, /2 et /3. Les réglages refusés dans une version précédente devront être saisis à nouveau s’ils n’avaient pas été enregistrés.

## Vérifications

Tests des formules, de 25 clients versus 25 capacités, des descriptions et avertissements, des autorisations refusées, des composants non exportés, des doublons, des profils, des confirmations L5 et de la migration. Tests d’interface simulée, du cache de démarrage et de stabilité du journal. Compilation et signature vérifiées. Pas de test sur un Samsung réel ou un émulateur dans cet environnement.

Sources techniques du catalogue : https://developer.android.com/reference/android/Manifest.permission
Métadonnées des fournisseurs : https://developer.android.com/reference/android/content/pm/ProviderInfo
