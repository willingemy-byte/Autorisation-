# AIV 0.6.13 — changements

- Ajout d'une vue **Flux** bâtie sur les événements VPN existants et `flow_correlation_id`; aucune seconde capture et aucun marqueur injecté dans Internet.
- Affichage du premier paquet sortant, premier retour entrant, identité du flux, protocole, destination, compteurs TX/RX, DNS/SNI visibles et limites TLS/QUIC/ECH.
- Navigation Application → Flux et Événement → Flux.
- Attribution prudente : UID réservé, partagé ou non unique reste **Android / non attribuable**; une liste de candidats n'est jamais traitée comme preuve d'auteur.
- Trois groupes exclusifs : Android, Système, Utilisateur; chaque package d'inventaire apparaît une seule fois.
- Les catégories totalement inconnues restent visibles mais sont exclues du dénominateur du score CB.
- Seuils du score CB : vert 85–100, jaune 70–84, orange 50–69, rouge <50.
- Compteurs distincts total / évalué / non évalué / anomalies / non attribuables.
- Référentiels renommés pour préciser l'import local; Bayton/Exodus ne sont pas présentés comme connectés automatiquement.
- Cache de 15 secondes sur la statistique de transparence réseau afin d'éviter un recalcul massif à chaque rafraîchissement UI.
- Version `0.6.13`, `versionCode 19`, package inchangé `fr.erick.journallocal`.
